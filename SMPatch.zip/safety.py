"""Who the agent must NEVER connect with, plus rules the team teaches it as it goes.
- Built-in: the SEC and every government agency/official (cannot be turned off).
- Learned rules (config/rules.json): 'block' terms and 'require' terms, for one client or all clients."""
import json, re
from pathlib import Path

RULES = Path(__file__).resolve().parent / "config" / "rules.json"

# case-insensitive phrases
_PHRASES = [
    r"securities and exchange commission", r"\bu\.?s\.? securities\b", r"\bfederal\b", r"\bgovernment\b", r"\bgovt\b",
    r"\bdepartments? of\b", r"\bdept\.? of\b", r"\bministry of\b", r"\bstate of\b", r"\bcity of\b", r"\bcounty of\b",
    r"\bnys\b", r"\bnyc (department|agency|office)\b", r"\bmunicipal", r"\bpublic servant\b", r"\bcivil servant\b", r"\bpublic sector\b",
    r"\bregulator(y)?\b", r"\battorney general\b", r"\bdistrict attorney\b", r"\bsenator\b", r"\bcongress", r"\bassembly ?(man|woman|member)\b",
    r"\bcouncil ?(man|woman|member)\b", r"\bmayor\b", r"\bgovernor\b", r"\bjudge\b", r"\bpolice\b", r"\bsheriff\b", r"\bmilitary\b",
    r"\bpentagon\b", r"\bwhite house\b", r"\bu\.?s\.? (army|navy|air force|marine|coast guard|treasury|postal|senate|house|congress|department)\b",
    r"\bveterans affairs\b", r"\bcenters for medicare\b", r"\bmedicaid (office|agency|inspector)\b", r"\binspector general\b", r"\bpublic health (department|agency)\b",
    r"\bhealth department\b", r"\bcommission(er)? of\b", r"\bbureau of\b", r"\boffice of the\b", r"\bstate (agency|senate|assembly|official)\b",
    r"\blocal government\b", r"\bfederal (agency|reserve)\b", r"\bcity hall\b", r"\btownship\b", r"\bparole\b", r"\bprosecutor\b",
]
# case-sensitive acronyms
_ACRONYMS = ["SEC", "FINRA", "CFTC", "FTC", "FDA", "CMS", "HHS", "DOH", "OIG", "DOL", "DOJ", "FBI", "CIA", "NSA", "DHS", "IRS", "EPA", "FCC",
             "FERC", "OCC", "FDIC", "CFPB", "SBA", "GSA", "USPS", "NIH", "CDC", "NASA", "USDA", "HUD", "ICE", "CBP", "ATF", "DEA", "USCIS",
             "OSHA", "NLRB", "EEOC", "FEMA", "FHFA", "SSA", "OPM", "DOD", "DoD", "AUSA", "OASAS", "OPWDD", "DFS", "NYSDOH", "NYSED", "DOE"]
_PH = re.compile("|".join(_PHRASES), re.I)
_AC = re.compile(r"(?<![A-Za-z])(" + "|".join(_ACRONYMS) + r")(?![A-Za-z])")

def gov_reason(text):
    m = _PH.search(text) or _AC.search(text)
    return f"Government / regulator ('{m.group(0).strip()}')" if m else None

def load_rules():
    try: r = json.loads(RULES.read_text(encoding="utf-8"))
    except Exception: r = {}
    return {"block": r.get("block", []), "require": r.get("require", [])}

def save_rules(r):
    RULES.parent.mkdir(exist_ok=True); RULES.write_text(json.dumps({"block": r["block"], "require": r["require"]}, indent=1), encoding="utf-8")

def add_rule(kind, term, client="*", note=""):
    term = re.sub(r"\s+", " ", term).strip()
    if kind not in ("block", "require") or not term: return False
    r = load_rules()
    if any(x["term"].lower() == term.lower() and x["client"] == client for x in r[kind]): return True
    import datetime
    r[kind].append({"term": term, "client": client, "note": note[:120], "added": datetime.date.today().isoformat()}); save_rules(r); return True

def remove_rule(kind, term, client):
    r = load_rules(); r[kind] = [x for x in r[kind] if not (x["term"].lower() == term.lower() and x["client"] == client)]; save_rules(r)

def check(text, client):
    """Reason to NOT connect with someone, or None. `text` = everything visible on their search card."""
    g = gov_reason(text)
    if g: return g
    rules = load_rules(); low = text.lower()
    for x in rules["block"]:
        if x["client"] in ("*", client) and x["term"].lower() in low: return f"You taught it to skip '{x['term']}'"
    req = [x["term"] for x in rules["require"] if x["client"] in ("*", client)]
    if req and not any(t.lower() in low for t in req): return "Does not match your 'must include' rules"
    return None

def suggest_term(headline):
    """A sensible term to offer when the user rejects someone: the company or title from the headline."""
    h = re.sub(r"\s+", " ", headline or "").strip()
    m = re.search(r"\b(?:at|@)\s+([^|·•,\-–]{3,40})", h)
    if m: return m.group(1).strip()
    return re.split(r"[|·•,\-–]", h)[0].strip()[:40]
