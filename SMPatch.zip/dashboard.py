#!/usr/bin/env python3
"""Bird's-eye numbers for the dashboard and the weekly tracking sheet. Everything is computed from the agents' own logs."""
import csv, json, re, random, collections, datetime as dt
import agent, growth

LOGS = agent.LOGS
MANUAL = LOGS / "tracker_manual.json"
STOP = set("and the of at in for to a an with on is or as by from at | - & de la senior sr jr the my our your i we you it that this are be was were their his her been has have not who all can about more most than into over also its".split())
DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

def _jl(f, default):
    try: return json.loads(f.read_text(encoding="utf-8"))
    except Exception: return default

def manual(): return _jl(MANUAL, {})
def save_manual(m): LOGS.mkdir(exist_ok=True); MANUAL.write_text(json.dumps(m, indent=1), encoding="utf-8")
def set_manual(profile, day, kind, note=""):
    m = manual(); key = f"{profile}|{day}"
    if not kind and not note: m.pop(key, None)
    else: m[key] = {"kind": kind, "note": note[:200]}
    save_manual(m)

# ---------- real data ----------
def real_bundle():
    d, clients = agent.load_cfg()
    ev, rows, decisions = [], [], []
    f = LOGS / "connections_log.csv"
    if f.exists():
        by_name = {c["name"]: c["profile"] for c in clients}
        for r in csv.DictReader(f.open(encoding="utf-8")):
            try: t = dt.datetime.fromisoformat(r["timestamp"])
            except Exception: continue
            prof = by_name.get(r["client"], r["client"]); rows.append(dict(r, t=t, profile=prof))
            if r["result"] == "sent": ev.append({"t": t, "profile": prof, "kind": "connection", "headline": r.get("headline", ""), "kw": r.get("keyword", "")})
    pdir = LOGS / "post_learning"
    for c in clients:
        pf = pdir / f"{c['profile']}.jsonl"
        if pf.exists():
            for l in pf.read_text(encoding="utf-8").splitlines():
                try: x = json.loads(l); t = dt.datetime.fromisoformat(x["ts"])
                except Exception: continue
                decisions.append(dict(x, t=t, profile=c["profile"]))
                if x["decision"] == "approved": ev.append({"t": t, "profile": c["profile"], "kind": "post"})
    for k, v in manual().items():
        p, day = k.split("|")
        if v.get("kind") in ("sent sugg", "posted"): ev.append({"t": dt.datetime.fromisoformat(day + "T09:00"), "profile": p, "kind": "manual"})
    queue = _jl(agent.LOGS / "queue.json", []); posts = _jl(LOGS / "posts.json", [])
    rules = _jl(agent.ROOT / "config" / "rules.json", {"block": [], "require": []})
    return {"clients": [c for c in clients if not c.get("paused")], "events": ev, "rows": rows, "decisions": decisions, "queue": queue, "posts": posts, "rules": rules, "demo": False, "growth": growth.load()}

# ---------- demo data (clearly labelled on screen) ----------
def demo_bundle():
    rnd = random.Random(7); now = dt.datetime.now(); names = ["Acme Capital", "Brightway Home Care", "Clarity Law", "Delta Dental Group", "Evergreen Advisors", "Fulton Insurance", "Granite Wealth", "Harbor Health", "Ironwood Consulting", "Juniper Realty", "Keystone Staffing", "Lumen Med Spa"]
    clients = [{"name": n, "profile": re.sub(r"\W+", "-", n.lower()), "keywords": ["x"]} for n in names]
    heads = ["Owner at {c} Home Care", "Director of Operations, Healthcare", "Administrator at Senior Living", "Founder & CEO, Staffing", "Discharge Planner, Hospital", "VP Business Development, Insurance", "Compliance Officer - FINRA", "Enforcement Attorney, SEC", "Managing Partner, Law Firm", "Case Manager, Social Services"]
    ev, rows, dec = [], [], []
    for i, c in enumerate(clients):
        quiet = i in (3, 8, 10)                                    # a few clients go quiet so the "not worked" list has content
        for back in range(60):
            day = now - dt.timedelta(days=back)
            if quiet and back < (11 if i != 10 else 16): continue
            if i == 11 and back > 20: continue
            if day.weekday() >= 5 or rnd.random() < 0.18: continue
            for _ in range(rnd.randint(7, 10) if rnd.random() < .85 else 0):
                t = day.replace(hour=rnd.randint(8, 16), minute=rnd.randint(0, 59), second=0, microsecond=0); h = rnd.choice(heads).format(c=c["name"].split()[0])
                kw = rnd.choice(["Home care agency owner", "Hospital discharge planner", "Family office", "Insurance broker"])
                gov = "SEC" in h or "FINRA" in h
                rows.append({"t": t, "profile": c["profile"], "client": c["name"], "keyword": kw, "headline": h, "result": "SKIPPED: Government / regulator" if gov else "sent"})
                if not gov: ev.append({"t": t, "profile": c["profile"], "kind": "connection", "headline": h, "kw": kw})
            if rnd.random() < .4:
                t = day.replace(hour=11, minute=5, second=0, microsecond=0); okp = rnd.random() < .82
                dec.append({"t": t, "profile": c["profile"], "decision": "approved" if okp else "rejected", "edited": okp and rnd.random() < .45, "note": "" if okp else rnd.choice(["Too salesy", "Wrong tone", "Off topic", "Too long"]), "when": t.isoformat(), "final": "x #a #b #c"})
                if okp: ev.append({"t": t, "profile": c["profile"], "kind": "post"})
    return {"clients": clients, "events": ev, "rows": rows, "decisions": dec, "queue": [], "posts": [], "rules": {"block": [{}, {}, {}], "require": []}, "demo": True, "growth": growth.demo(clients, rnd, dt.date.today())}

# ---------- computation ----------
def monday(d): return d - dt.timedelta(days=d.weekday())

def periods(kind, now):
    today = now.date()
    if kind == "day": return [(today - dt.timedelta(days=i), today - dt.timedelta(days=i)) for i in range(13, -1, -1)], lambda a, b: f"{DAYS[a.weekday()][0]}{a.day}"
    if kind == "week":
        m = monday(today); return [(m - dt.timedelta(weeks=i), m - dt.timedelta(weeks=i) + dt.timedelta(days=6)) for i in range(7, -1, -1)], lambda a, b: f"{a.strftime('%b')} {a.day}"
    out = []; y, mo = today.year, today.month
    for i in range(5, -1, -1):
        yy, mm = y, mo - i
        while mm < 1: mm += 12; yy -= 1
        a = dt.date(yy, mm, 1); b = (dt.date(yy + (mm == 12), mm % 12 + 1, 1) - dt.timedelta(days=1)); out.append((a, b))
    return out, lambda a, b: a.strftime("%b")

def compute(b):
    now = dt.datetime.now(); today = now.date(); clients = b["clients"]; ev = b["events"]
    name = {c["profile"]: c["name"] for c in clients}
    ev = [e for e in ev if e["profile"] in name]
    last = {}
    for e in ev: last[e["profile"]] = max(last.get(e["profile"], e["t"]), e["t"])
    lastc = {}; lastp = {}
    for e in ev:
        (lastc if e["kind"] == "connection" else lastp)[e["profile"]] = max((lastc if e["kind"] == "connection" else lastp).get(e["profile"], e["t"]), e["t"])
    def days_since(p): return (today - last[p].date()).days if p in last else None
    series = {}
    for kind in ("day", "week", "month"):
        ps, lab = periods(kind, now); s = {"labels": [], "clients": [], "connections": [], "posts": [], "tips": []}
        for a, z in ps:
            inside = [e for e in ev if a <= e["t"].date() <= z]
            s["labels"].append(lab(a, z)); s["clients"].append(len({e["profile"] for e in inside}))
            s["connections"].append(sum(e["kind"] == "connection" for e in inside)); s["posts"].append(sum(e["kind"] in ("post", "manual") for e in inside))
            s["tips"].append(f"{a.strftime('%b')} {a.day}" + (f" – {z.strftime('%b')} {z.day}" if a != z else ""))
        series[kind] = s
    stale = sorted([{"client": name[c["profile"]], "profile": c["profile"], "days": days_since(c["profile"]),
                     "last": last[c["profile"]].date().isoformat() if c["profile"] in last else "",
                     "connections": lastc[c["profile"]].date().isoformat() if c["profile"] in lastc else "", "posts": lastp[c["profile"]].date().isoformat() if c["profile"] in lastp else ""}
                    for c in clients if days_since(c["profile"]) is None or days_since(c["profile"]) > 7], key=lambda x: (x["days"] is None, -(x["days"] or 0)))
    active = [c for c in clients if days_since(c["profile"]) is not None and days_since(c["profile"]) <= 7]
    wk = monday(today); lw = wk - dt.timedelta(weeks=1)
    def cnt(kind, a, z): return sum(1 for e in ev if e["kind"] in kind and a <= e["t"].date() <= z)
    this_c, last_c = cnt(("connection",), wk, today), cnt(("connection",), lw, wk - dt.timedelta(days=1))
    this_p, last_p = cnt(("post", "manual"), wk, today), cnt(("post", "manual"), lw, wk - dt.timedelta(days=1))
    kpis = {"clients": len(clients), "active": len(active), "inactive": len(clients) - len(active), "stale": len(stale), "today": len({e["profile"] for e in ev if e["t"].date() == today}),
            "week_connections": this_c, "week_posts": this_p}
    ins = []
    def add(icon, title, text): ins.append({"icon": icon, "title": title, "text": text})
    if last_c or this_c:
        if last_c: ch = round((this_c - last_c) * 100 / last_c); add("📈" if ch >= 0 else "📉", "Connections vs last week", f"{this_c} sent so far this week against {last_c} all of last week ({'+' if ch >= 0 else ''}{ch}% so far, the week is not over).")
        else: add("📈", "Connections this week", f"{this_c} sent so far this week.")
    bydow = collections.Counter(e["t"].weekday() for e in ev if e["kind"] == "connection")
    if sum(bydow.values()) >= 20: dw, n = bydow.most_common(1)[0]; add("📅", "Busiest day", f"{['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'][dw]} is when the most connections go out ({n} so far, {round(n * 100 / sum(bydow.values()))}% of all).")
    gov = [r for r in b["rows"] if str(r["result"]).startswith("SKIPPED: Government")]
    if gov: add("🛡️", "Kept out of the wrong crowd", f"{len(gov)} government / regulator profiles were found in the searches and skipped automatically. Searches for these keywords surface them regularly, which is worth knowing when picking keywords.")
    words = collections.Counter(w for e in ev if e["kind"] == "connection" for w in re.findall(r"[A-Za-z]{4,}", e.get("headline", "")) if w.lower() not in STOP)
    if sum(words.values()) >= 15: add("🧭", "Who you are really reaching", "The most common words in the people connected with: " + ", ".join(f"{w.lower()} ({n})" for w, n in words.most_common(5)) + ".")
    kwc = collections.Counter(e["kw"] for e in ev if e["kind"] == "connection" and e.get("kw"))
    if len(kwc) >= 2:
        top, n = kwc.most_common(1)[0]; low, m = kwc.most_common()[-1]
        add("🔑", "Keywords that deliver", f"“{top}” has produced the most connections ({n}). “{low}” the fewest ({m}) - consider swapping or reworking it.")
    q = b["queue"]; qr = sum(1 for i in q if i.get("status") == "rejected"); qa = sum(1 for i in q if i.get("status") in ("approved", "sent"))
    if qr + qa >= 10: add("✅", "How picky the team is", f"Of the people suggested for review, {qa} were approved and {qr} rejected ({round(qr * 100 / (qa + qr))}% rejected). A high rate means the keywords are bringing in the wrong people.")
    dec = b["decisions"]
    if len(dec) >= 5:
        ap = [x for x in dec if x["decision"] == "approved"]; ed = [x for x in ap if x.get("edited")]
        add("✍️", "How good the drafts are", f"{round(len(ap) * 100 / len(dec))}% of suggested posts were approved and {round(len(ed) * 100 / max(1, len(ap)))}% of those needed edits. Both numbers should improve as it learns.")
        notes = collections.Counter(x["note"].lower() for x in dec if x["decision"] == "rejected" and x.get("note"))
        if notes: add("💬", "Why posts get rejected", "Most common reasons: " + ", ".join(f"{k} ({n})" for k, n in notes.most_common(3)) + ".")
        rej = collections.Counter(name.get(x["profile"], x["profile"]) for x in dec if x["decision"] == "rejected")
        if rej: k, n = rej.most_common(1)[0]; add("🎯", "Needs the most tuning", f"{k} has the most rejected posts ({n}). Its style is the one to teach first.")
        tags = [len(re.findall(r"#\w+", x.get("final", ""))) for x in ap]
        if tags: add("#️⃣", "Hashtag habit", f"Approved posts carry {round(sum(tags) / len(tags), 1)} hashtags on average.")
    if b["rules"]["block"]: add("🧠", "What it has learned about people", f"{len(b['rules']['block'])} 'never connect' rules taught so far, on top of the built-in government block.")
    drop = [name[p] for p in name if p in last and (today - last[p].date()).days > 7 and any(e["profile"] == p and (today - e["t"].date()).days <= 21 for e in ev)]
    if drop: add("⚠️", "Recently went quiet", f"{len(drop)} client{'s' if len(drop) != 1 else ''} had activity in the last 3 weeks but none in the last 7 days: {', '.join(drop[:4])}{'…' if len(drop) > 4 else ''}.")
    if not ins: add("🌱", "Insights appear as work happens", "Once the agents have a few days of activity, trends and surprises will show up here.")
    return {"demo": b["demo"], "growth": growth.build(clients, ev, today, b.get("growth")), "kpis": kpis, "series": series, "stale": stale, "insights": ins, "generated": now.isoformat(timespec="minutes")}

def dashboard(demo=False): return compute(demo_bundle() if demo else real_bundle())

# ---------- tracking sheet ----------
def tracker(week=None, demo=False):
    b = demo_bundle() if demo else real_bundle(); today = dt.date.today()
    try: ws = monday(dt.date.fromisoformat(week)) if week else monday(today)
    except Exception: ws = monday(today)
    days = [ws + dt.timedelta(days=i) for i in range(7)]; man = manual() if not demo else {}
    ev = b["events"]; posts = b["posts"]
    last = {}
    for e in ev: last[e["profile"]] = max(last.get(e["profile"], e["t"]), e["t"])
    rows = []
    for c in b["clients"]:
        p = c["profile"]; cells = []
        for d in days:
            iso = d.isoformat(); items = []
            n = sum(1 for e in ev if e["profile"] == p and e["kind"] == "connection" and e["t"].date() == d)
            for x in posts:
                if x["profile"] == p and x["when"][:10] == iso and x["status"] in ("pending", "approved", "scheduled"):
                    st = "posted" if x["status"] == "scheduled" and dt.datetime.fromisoformat(x["when"]) < dt.datetime.now() else x["status"]
                    items.append({"state": st, "time": x["when"][11:16], "subject": x["subject"]})
            if demo:
                for e in ev:
                    if e["profile"] == p and e["kind"] == "post" and e["t"].date() == d: items.append({"state": "posted" if d <= today else "scheduled", "time": "08:30", "subject": "Post"})
            m = man.get(f"{p}|{iso}")
            cells.append({"date": iso, "connections": n, "posts": items, "manual": m})
        ds = (today - last[p].date()).days if p in last else None
        rows.append({"client": c["name"], "profile": p, "days_since": ds, "stale": ds is None or ds > 7, "cells": cells})
    rows.sort(key=lambda r: (not r["stale"], r["client"].lower()))
    return {"week": ws.isoformat(), "label": f"{ws.strftime('%b')} {ws.day} – {(ws + dt.timedelta(days=6)).strftime('%b')} {(ws + dt.timedelta(days=6)).day}", "days": [{"name": DAYS[i], "date": d.isoformat(), "num": d.day, "today": d == today} for i, d in enumerate(days)], "rows": rows, "demo": demo}
