"""Pause alerts by email, sent from the dedicated ShareMedia alerts Gmail (through the agent's own Chrome). AFDV is always a recipient;
ShareMedia adds anyone else under 'extra'. Everyone is on the To line, so a reply-all reaches all of them."""
import json, re, sys, time
from pathlib import Path

SENDER = "sharemediaalerts@gmail.com"   # sending account (sign in once in the panel)
ALWAYS = "afdv0613@gmail.com"           # always a recipient
F = Path(__file__).resolve().parent / "config" / "alerts.json"

def load():
    c = {"enabled": True, "extra": None}
    try: c.update(json.loads(F.read_text()))
    except Exception: pass
    extra = c["extra"] if c["extra"] is not None else c.get("to", [])      # older config files stored the full list in "to"
    seen, out = {SENDER.lower(), ALWAYS.lower()}, []
    for x in extra:
        if x.lower() not in seen: seen.add(x.lower()); out.append(x)
    return {"enabled": bool(c["enabled"]), "sender": SENDER, "extra": out, "to": [ALWAYS] + out}

def save(enabled=None, extra=None):
    c = load(); F.parent.mkdir(exist_ok=True)
    extra = c["extra"] if extra is None else [x for x in extra if x.lower() not in (SENDER.lower(), ALWAYS.lower())]
    F.write_text(json.dumps({"enabled": c["enabled"] if enabled is None else bool(enabled), "extra": extra}, indent=1))
    return load()

def configured(): return gmail_signed_in()

def parse_to(s): return [x.strip() for x in str(s).replace(";", ",").replace("\n", ",").split(",") if "@" in x]

# ---- Gmail through the agent's own Chrome window: sign in once, no app password, no 2-Step Verification ----
ROOT = Path(__file__).resolve().parent
PROFILE = ROOT / "browser-profiles" / "_alerts-gmail-sm"
STATEF = ROOT / "logs" / "state.json"
NOWIN = 0x08000000 if sys.platform == "win32" else 0

def gmail_signed_in():
    try: return bool(json.loads(STATEF.read_text()).get("alert_login_sm"))
    except Exception: return False

def _ctx(pw, headless=False):
    kw = dict(user_data_dir=str(PROFILE), headless=headless, viewport={"width": 1100, "height": 800}, chromium_sandbox=True,
              ignore_default_args=["--enable-automation"], args=["--disable-blink-features=AutomationControlled"])
    try: return pw.chromium.launch_persistent_context(channel="chrome", **kw)
    except Exception: return pw.chromium.launch_persistent_context(**kw)

def _find_chrome():
    import os, shutil
    c = []
    if sys.platform == "win32":
        for base in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
            v = os.environ.get(base)
            if v: c += [Path(v) / "Google/Chrome/Application/chrome.exe", Path(v) / "Microsoft/Edge/Application/msedge.exe"]
    elif sys.platform == "darwin":
        c = [Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome")]
    else:
        c = [Path(x) for x in (shutil.which("google-chrome"), shutil.which("chromium")) if x]
    return next((str(x) for x in c if x.exists()), None)

def gmail_login():
    """Opens a normal Chrome window (not automated - Google refuses sign-in in automated browsers).
    Returns True when the Gmail inbox is reached. The saved sign-in is then reused by the agent."""
    import subprocess, urllib.request
    exe = _find_chrome()
    if not exe: return False
    import shutil
    if not gmail_signed_in(): shutil.rmtree(PROFILE, ignore_errors=True)   # start clean only when not signed in; a working sign-in is never deleted
    PROFILE.mkdir(parents=True, exist_ok=True); port = 9333
    proc = subprocess.Popen([exe, f"--user-data-dir={PROFILE}", f"--remote-debugging-port={port}", "--no-first-run",
                             "--no-default-browser-check", "https://mail.google.com/"])
    ok = False; end = time.time() + 900
    while time.time() < end and proc.poll() is None:
        try:
            tabs = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{port}/json", timeout=3).read())
            if any(re.match(r"https://mail\.google\.com/mail/u/\d+/", t.get("url", "")) for t in tabs): ok = True; break
        except Exception: pass
        time.sleep(2)
    if ok:
        time.sleep(6)   # let Chrome write the sign-in to disk, then close it gently
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as pw:
                b = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{port}")
                try: b.new_browser_cdp_session().send("Browser.close")   # graceful: Chrome saves the sign-in, then quits
                except Exception: pass
        except Exception: pass
        for _ in range(10):
            if proc.poll() is not None: break
            time.sleep(1)
    if proc.poll() is None: proc.terminate()
    return ok

def _gmail_send_now(to, subject, body):
    from playwright.sync_api import sync_playwright
    from urllib.parse import quote
    url = f"https://mail.google.com/mail/?view=cm&fs=1&to={quote(','.join(to))}&su={quote(subject)}&body={quote(body)}"
    with sync_playwright() as pw:
        ctx = _ctx(pw); p = ctx.pages[0] if ctx.pages else ctx.new_page()
        try:
            p.goto(url, wait_until="domcontentloaded", timeout=60000)
            time.sleep(3)
            if not re.match(r"https://mail\.google\.com/mail/", p.url):
                try:
                    st = json.loads(STATEF.read_text()); st["alert_login_sm"] = False; STATEF.write_text(json.dumps(st, indent=1))
                except Exception: pass
                return False, "Gmail is signed out. Open Settings > Pause alerts and click Sign in to Gmail"
            send = p.locator('div[role="button"][aria-label^="Send"], div[role="button"][data-tooltip^="Send"], div[role="button"]:text-is("Send")').first
            send.wait_for(state="visible", timeout=60000)
            time.sleep(2)
            try: send.click(timeout=10000)
            except Exception: p.keyboard.press("Control+Enter")      # pressed once only - never retried, to avoid duplicate emails
            sent = False
            for _ in range(45):
                time.sleep(1)
                try:
                    if "view=cm" not in p.url or send.count() == 0 or p.locator("text=/Message sent/").count(): sent = True; break
                except Exception: sent = True; break                 # page navigated away = sent
            if not sent:   # Gmail greys the Send button while it is sending; an enabled button means nothing happened
                try: sent = send.get_attribute("aria-disabled", timeout=3000) == "true"
                except Exception: sent = False
            if not sent: raise RuntimeError("Gmail did not send the message")
            time.sleep(3)
            return True, "Sent to " + ", ".join(to)
        except Exception as ex:
            try: p.screenshot(path=str(ROOT / "logs" / "alert_failed.png"))
            except Exception: pass
            return False, "Could not send through Gmail (" + str(ex).splitlines()[0][:90] + "). A screenshot was saved to logs/alert_failed.png"
        finally:
            try: ctx.close()
            except Exception: pass

def send_gmail(c, subject, text):
    import subprocess, tempfile
    f = Path(tempfile.mkdtemp()) / "mail.json"
    f.write_text(json.dumps({"to": c["to"], "subject": subject, "body": text}))
    try: subprocess.run([sys.executable, str(Path(__file__).resolve()), "_send", str(f)], timeout=240, creationflags=NOWIN, cwd=str(ROOT))
    except Exception as ex: return False, "Could not send through Gmail (" + str(ex)[:90] + ")"
    try: r = json.loads(f.with_suffix(".out").read_text()); return bool(r["ok"]), r["msg"]
    except Exception: return False, "Could not send through Gmail (no result)"

def send(subject, text, html=None, only_to=None):
    c = load()
    if only_to: c["to"] = list(only_to)   # e.g. test emails go only to the person testing
    if not gmail_signed_in(): return False, "Click Sign in to Gmail first (one time), then send the test again"
    return send_gmail(c, subject, text)

def html_wrap(title, rows, steps):
    r = "".join(f"<tr><td style='padding:4px 16px 4px 0;color:#6e6e73'>{k}</td><td style='padding:4px 0'><b>{v}</b></td></tr>" for k, v in rows)
    s = "".join(f"<li style='margin:4px 0'>{x}</li>" for x in steps)
    return (f"<div style='font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;max-width:560px;color:#1d1d1f'>"
            f"<div style='background:linear-gradient(135deg,#1250d0,#2b7bff);color:#fff;border-radius:14px;padding:18px 22px;font-size:19px;font-weight:600'>{title}</div>"
            f"<table style='margin:16px 0;font-size:14.5px'>{r}</table><div style='font-size:14.5px'><b>What to do (about 1 minute)</b><ol>{s}</ol>"
            f"<p style='color:#6e6e73'>You can reply to this email - your reply goes to everyone on this alert.</p></div></div>")

if __name__ == "__main__" and len(sys.argv) > 2 and sys.argv[1] == "_send":
    out = Path(sys.argv[2]).with_suffix(".out")
    try:
        d = json.loads(Path(sys.argv[2]).read_text()); ok, msg = _gmail_send_now(d["to"], d["subject"], d["body"])
    except BaseException as ex: ok, msg = False, "Gmail helper crashed: " + str(ex)[:120]
    out.write_text(json.dumps({"ok": ok, "msg": msg}))
