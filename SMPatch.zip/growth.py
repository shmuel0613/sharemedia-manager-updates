#!/usr/bin/env python3
"""Growth tracker: every client's total LinkedIn connections and followers over time, measured from the day the app started being used.
A reading is taken automatically once a day (start of the daily run, or 'Check now' on the dashboard); numbers can also be typed in by hand."""
import json, re, time, datetime as dt
import agent

FILE = agent.LOGS / "growth.json"

def load():
    try: return json.loads(FILE.read_text(encoding="utf-8"))
    except Exception: return {}

def save(g): agent.LOGS.mkdir(exist_ok=True); FILE.write_text(json.dumps(g, indent=1), encoding="utf-8")

def record(profile, connections=None, followers=None, src="auto", when=None):
    """Add one reading. At most one automatic reading per day (the newest replaces an earlier one); manual readings always count."""
    if connections is None and followers is None: return False
    g = load(); L = g.setdefault(profile, []); now = when or dt.datetime.now().isoformat(timespec="minutes")
    if src == "auto": L[:] = [x for x in L if not (x.get("src") == "auto" and x["t"][:10] == now[:10])]
    L.append({"t": now, "connections": connections, "followers": followers, "src": src}); L.sort(key=lambda x: x["t"]); save(g); return True

def checked_today(profile): return any(x["t"][:10] == str(dt.date.today()) for x in load().get(profile, []))

def _num(text, word):
    """'1,234 followers' -> 1234, '12.5K followers' -> 12500. Takes the first match."""
    m = re.search(r"([\d][\d,\.]*)\s*([KkMm])?\+?\s+" + word + r"\b", text, re.I)
    if not m: return None
    s = m.group(1).replace(",", "")
    try: v = float(s)
    except ValueError: return None
    v *= {"k": 1e3, "m": 1e6}.get((m.group(2) or "").lower(), 1)
    return int(round(v))

def read_counts(page, c):
    """Open the pages that show the totals and read them. Returns (connections, followers); either may be None if LinkedIn did not show it."""
    conns = fol = None
    try:
        page.goto("https://www.linkedin.com/mynetwork/invite-connect/connections/", wait_until="domcontentloaded"); time.sleep(4)
        if agent.blocked(page): return "blocked", None
        conns = _num(page.inner_text("body")[:4000], "connections?")
    except Exception as e: print("  connections page:", str(e)[:100])
    try:
        url = (c.get("page_url") or "").strip()
        if url:
            m = re.search(r"(https?://[^/]*linkedin\.com/company/[^/?#]+)", url)
            page.goto((m.group(1) if m else url), wait_until="domcontentloaded")
        else: page.goto("https://www.linkedin.com/in/me/", wait_until="domcontentloaded")
        time.sleep(4); fol = _num(page.inner_text("body")[:8000], "followers?")
    except Exception as e: print("  followers page:", str(e)[:100])
    return conns, fol

def snapshot(pw, c, headless=True):
    """One automatic reading for one client. Needs the client to be logged in; never raises."""
    if c.get("paused") or not agent.load_state().get("login_" + c["profile"]): return False
    ctx = None
    try:
        ctx = agent.launch(pw, c, headless); page = ctx.pages[0] if ctx.pages else ctx.new_page()
        conns, fol = read_counts(page, c)
        if conns == "blocked": print(f"[{c['name']}] growth reading skipped - LinkedIn asked for a login"); return False
        ok = record(c["profile"], conns, fol)
        print(f"[{c['name']}] growth reading: {conns} connections, {fol} followers" if ok else f"[{c['name']}] growth reading: LinkedIn did not show the numbers (type them in on the dashboard)")
        return ok
    except Exception as e: print(f"[{c['name']}] growth reading failed:", str(e)[:120]); return False
    finally:
        try: ctx and ctx.close()
        except Exception: pass

# ---------- numbers for the dashboard ----------
def _metric(pts, key, today):
    v = [(dt.datetime.fromisoformat(x["t"]), x[key]) for x in pts if x.get(key) is not None]
    if not v: return None
    base_t, base = v[0]; now_t, now = v[-1]; days = max(1, (now_t - base_t).days) if len(v) > 1 else 0
    return {"base": base, "now": now, "delta": now - base, "pct": round((now - base) * 100 / base, 1) if base else None, "days": days,
            "per_week": round((now - base) * 7 / days, 1) if days >= 3 else None, "base_date": base_t.date().isoformat(),
            "series": [{"d": t.date().isoformat(), "v": x - base, "abs": x} for t, x in v]}

def _fd(s): d = dt.date.fromisoformat(s); return d.strftime('%b ') + str(d.day)

def build(clients, events, today, g=None):
    g = load() if g is None else g; out = []; ins = []
    for c in clients:
        pts = g.get(c["profile"], [])
        row = {"client": c["name"], "profile": c["profile"], "readings": len(pts), "last": pts[-1]["t"] if pts else "",
               "connections": _metric(pts, "connections", today), "followers": _metric(pts, "followers", today), "sent": 0}
        if pts:
            b = dt.datetime.fromisoformat(pts[0]["t"]).date()
            row["sent"] = sum(1 for e in events if e["profile"] == c["profile"] and e["kind"] == "connection" and e["t"].date() >= b)
        out.append(row)
    def add(icon, title, text): ins.append({"icon": icon, "title": title, "text": text})
    measured = [r for r in out if r["readings"] >= 2]
    if not any(r["readings"] for r in out): add("🌱", "Baselines are set on the first reading", "The first reading for each client becomes its starting line. Use “Check now”, or type the numbers in; trends and comparisons appear as readings come in.")
    elif not measured: add("🌱", "Starting lines recorded", "Each client's first reading is its baseline. The trend and the comparisons appear after the next reading (it happens by itself every day).")
    for key, label in (("connections", "connections"), ("followers", "followers")):
        rs = [(r, r[key]) for r in measured if r[key] and r[key]["days"] >= 1 and r[key]["base"]]
        if len(rs) >= 2:
            top = max(rs, key=lambda x: x[1]["pct"]); low = min(rs, key=lambda x: x[1]["pct"]); avg = sum(x[1]["pct"] for x in rs) / len(rs)
            if top[1]["pct"] > max(avg * 1.5, avg + 1): add("🚀", f"{top[0]['client']} stands out on {label}", f"Up {top[1]['delta']:+,} ({top[1]['pct']:+.1f}%) since {_fd(top[1]['base_date'])}, against an average of {avg:+.1f}% across clients.")
            if low[0] is not top[0] and low[1]["pct"] < avg * 0.4 and avg > 0.5: add("🐢", f"{low[0]['client']} is the slowest on {label}", f"{low[1]['delta']:+,} ({low[1]['pct']:+.1f}%) since {_fd(low[1]['base_date'])} while the average is {avg:+.1f}%.")
        elif len(rs) == 1: r, m = rs[0]; add("📈", f"{r['client']} {label}", f"{m['delta']:+,} since {_fd(m['base_date'])} ({m['pct']:+.1f}%).")
    yl, fl = [], []
    for r in measured:
        m = r["connections"]
        if m and r["sent"] >= 15 and m["delta"] >= 0: yl.append((r, round(m["delta"] * 100 / r["sent"])))
        if m and m["days"] >= 7 and r["sent"] >= 10 and m["series"][-1]["v"] - m["series"][max(0, len(m["series"]) - 4)]["v"] <= 0:
            add("⚠️", f"{r['client']}'s network stopped growing", "No new connections in the last few readings even though requests are going out. Worth checking the keywords or the LinkedIn account.")
        f = r["followers"]
        if f and m and f["delta"] > 0 and m["delta"] > 0: fl.append((r, f["delta"] / m["delta"]))
    if len(yl) >= 2:
        hi, lo = max(yl, key=lambda x: x[1]), min(yl, key=lambda x: x[1])
        add("🤝", "Requests that turn into growth", f"{hi[0]['client']} gains the most per request sent ({hi[1]} new connections per 100 requests sent); {lo[0]['client']} the least ({lo[1]} per 100). People also connect on their own, so treat this as a comparison, not an exact acceptance rate.")
    elif yl: add("🤝", f"{yl[0][0]['client']}: requests vs growth", f"{yl[0][0]['sent']} requests sent since the baseline; the network grew by {yl[0][0]['connections']['delta']:,}.")
    if len(fl) >= 2:
        hi = max(fl, key=lambda x: x[1]); add("👥", "Most followers per new connection", f"{hi[0]['client']} picks up {hi[1]:.2f} followers for every new connection, the best of any client. Their content is pulling its weight.")
    tot_c = sum(r["connections"]["delta"] for r in out if r["connections"]); tot_f = sum(r["followers"]["delta"] for r in out if r["followers"])
    if measured: add("🌐", "All clients together", f"{tot_c:+,} connections and {tot_f:+,} followers since the baselines.")
    return {"clients": out, "insights": ins[:10], "totals": {"connections": tot_c, "followers": tot_f}, "has_data": bool(measured)}

def demo(clients, rnd, today):
    """Sample readings for the sample dashboard: different clients grow at different speeds."""
    g = {}
    for i, c in enumerate(clients):
        pace = [1.2, 3.5, 0.2, 2.0, 5.5, 0.8, 1.7, 2.6, 0.0, 3.1, 1.0, 2.2][i % 12]; fpace = pace * rnd.uniform(.4, 1.4)
        con, fol = rnd.randint(420, 2600), rnd.randint(150, 1800); L = []
        for back in range(45, -1, -3):
            t = dt.datetime.combine(today - dt.timedelta(days=back), dt.time(5, 40)); k = (45 - back) / 3
            L.append({"t": t.isoformat(timespec="minutes"), "connections": int(con + pace * 3 * k + rnd.randint(-2, 3)), "followers": int(fol + fpace * 3 * k + rnd.randint(-2, 3)), "src": "auto"})
        g[c["profile"]] = L
    return g
