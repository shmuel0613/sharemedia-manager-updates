#!/usr/bin/env python3
"""
ShareMedia Manager - engine (v2)
Normally you never run this directly: START.vbs / START.command opens the control panel.

Commands (used by the control panel and the daily schedule):
  run [--client NAME] [--dry-run] [--max N]   run now
  daily                                        what the daily schedule runs (skips if paused)
  login --client NAME                          open LinkedIn once so the client can log in
  prepare                                      one-time computer prep (turn sleep off)
  schedule | unschedule                        daily automation on / off
"""
import urllib.parse, argparse, csv, json, os, platform, random, re, subprocess, sys, time, datetime as dt
from pathlib import Path
from urllib.parse import quote

ROOT = Path(__file__).resolve().parent
CFG = ROOT / "config" / "clients.json"
LOGS = ROOT / "logs"
PROFILES = ROOT / "browser-profiles"      # saved LinkedIn logins - stay on THIS computer
STATE = LOGS / "state.json"
TASK_NAME = "ShareMedia Connections Agent"
DEFAULT_POSTS_TIME = "10:00"
US_GEO = "103644278"
NETWORK = {"1st": "F", "2nd": "S", "3rd": "O"}
WIN, MAC = platform.system() == "Windows", platform.system() == "Darwin"
NOWIN = 0x08000000 if WIN else 0
RESULT = {"sent": 0, "stopped": False, "reason": ""}
DEFAULTS = {"daily_min": 7, "daily_max": 10, "pause_between_connects_sec": [5, 14], "pause_between_pages_sec": [8, 20],
            "max_pages_per_keyword": 10, "degree": "2nd", "daily_run_time": "09:30"}

# ---------- state / config ----------
def load_state():
    try: return json.loads(STATE.read_text())
    except Exception: return {}

def save_state(**kw):
    LOGS.mkdir(exist_ok=True)
    s = load_state(); s.update(kw); STATE.write_text(json.dumps(s, indent=1)); return s

def load_cfg():
    c = json.loads(CFG.read_text()) if CFG.exists() else {}
    d = {**DEFAULTS, **c.get("defaults", {})}; d.pop("daily_cap", None)
    return d, c.get("clients", [])

def save_cfg(defaults, clients):
    CFG.parent.mkdir(exist_ok=True)
    CFG.write_text(json.dumps({"defaults": defaults, "clients": clients}, indent=2))

def uses(c):
    """What a client is used for: 'connections', 'posts' or both (clients saved before this existed count as both)."""
    u = c.get("uses"); return set(u) if u else {"connections", "posts"}

def fix_root():
    """If this folder was moved, re-point the Desktop icon and the daily schedule at the new place."""
    try:
        if load_state().get("install_root") == str(ROOT): return
        was = load_state().get("install_root"); save_state(install_root=str(ROOT))
        if was is None and not load_state().get("automation"): return
        make_shortcut()
        if load_state().get("automation"): schedule_daily()
        if load_state().get("posts_automation"): schedule_posts()
    except Exception as e: print("fix_root skipped:", e)

def build_id():
    """Short fingerprint of the program files. A background server that is older than the files on disk gets replaced."""
    import hashlib
    h = hashlib.md5()
    for n in ("agent.py", "ui.py", "poster.py", "ui.html", "updater.py", "version.txt"):
        try: h.update((ROOT / n).read_bytes())
        except Exception: pass
    return h.hexdigest()[:8]

KEEP = ["config", "logs", "posting"]       # everything the user created: clients, keywords, rules, alerts, phone PIN, logs, post drafts

def backup_settings():
    """Daily zip of all clients and settings (kept 14 days). If the client list ever goes missing it is restored from here."""
    try:
        import zipfile
        bdir = ROOT / "backups"; bdir.mkdir(exist_ok=True)
        z = bdir / f"settings-{dt.date.today()}.zip"
        with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
            for k in ("config", "posting"):
                for f in (ROOT / k).rglob("*"):
                    if f.is_file(): zf.write(f, f.relative_to(ROOT))
            for n in ("state.json", "posts.json", "queue.json", "seen.json", "connections_log.csv"):
                if (LOGS / n).exists(): zf.write(LOGS / n, f"logs/{n}")
        for old in sorted(bdir.glob("settings-*.zip"))[:-14]: old.unlink()
    except Exception as e: print("backup skipped:", e)

def restore_if_empty():
    """New install over a wiped/blank folder: bring clients and settings back from the newest backup."""
    try:
        import zipfile
        bs = sorted((ROOT / "backups").glob("settings-*.zip"))
        if not bs: return
        d, clients = load_cfg()
        if clients: return
        with zipfile.ZipFile(bs[-1]) as zf: zf.extractall(ROOT)
        print("Restored clients and settings from", bs[-1].name)
    except Exception as e: print("restore skipped:", e)

def ensure_defaults():
    """Settings the user never touched get the agreed defaults (error sound ON, posting time, ...). Never overwrites a choice."""
    s = load_state(); add = {}
    if "sound_off" not in s: add["sound_off"] = False
    if "posts_time" not in s: add["posts_time"] = DEFAULT_POSTS_TIME
    if add: save_state(**add)

def keywords_of(c):
    f = c.get("keywords_file")
    if f and (ROOT / f).exists():
        return [l.strip() for l in (ROOT / f).read_text(encoding="utf-8").splitlines() if l.strip() and not l.strip().startswith("#")]
    return c.get("keywords", [])

def sent_today(c):
    f = LOGS / f"count_{c['profile']}_{dt.date.today()}.txt"
    return int(f.read_text()) if f.exists() else 0

def bump(c):
    LOGS.mkdir(exist_ok=True)
    (LOGS / f"count_{c['profile']}_{dt.date.today()}.txt").write_text(str(sent_today(c) + 1))

def target_for(c, d):
    """Random 7-10 (configurable) per client per day; fixed once chosen for the day."""
    today = str(dt.date.today()); key = f"{today}|{c['profile']}"
    t = load_state().get("targets", {})
    if key not in t:
        t = {k: v for k, v in t.items() if k.startswith(today)}
        lo = int(c.get("daily_min") or d["daily_min"]); hi = max(lo, int(c.get("daily_max") or d["daily_max"])); t[key] = random.randint(lo, hi)      # a client can have its own range
        save_state(targets=t)
    return t[key]

def log_row(c, kw, page, person, headline, result):
    LOGS.mkdir(exist_ok=True)
    f = LOGS / "connections_log.csv"; new = not f.exists()
    with f.open("a", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        if new: w.writerow(["timestamp", "client", "keyword", "page", "person", "headline", "result"])
        w.writerow([dt.datetime.now().isoformat(timespec="seconds"), c["name"], kw, page, person, headline, result])

def nap(rng): time.sleep(random.uniform(*rng))

def halt(reason):
    RESULT["stopped"] = True; RESULT["reason"] = reason; print("STOP:", reason)

# ---------- browser ----------
def launch(pw, c, headless):
    PROFILES.mkdir(exist_ok=True)
    kw = dict(user_data_dir=str(PROFILES / c["profile"]), headless=headless, viewport={"width": 1280, "height": 900},
              ignore_default_args=["--enable-automation", "--no-sandbox"])
    try: return pw.chromium.launch_persistent_context(channel="chrome", **kw)
    except Exception: return pw.chromium.launch_persistent_context(**kw)

def search_url(keyword, degree, page):
    return ("https://www.linkedin.com/search/results/people/?keywords=" + quote(keyword)
            + f'&network=%5B%22{NETWORK[degree]}%22%5D&geoUrn=%5B%22{US_GEO}%22%5D&origin=FACETED_SEARCH&page={page}')

def blocked(page):
    u = page.url
    if any(x in u for x in ("checkpoint", "authwall", "/login", "/uas/")): return "LinkedIn is asking for a login or verification"
    body = page.inner_text("body")[:6000].lower()
    for s in ("weekly invitation limit", "reached the weekly", "unusual activity", "verify you're a human", "temporarily restricted"):
        if s in body: return f"LinkedIn warning: \"{s}\""
    return None

def close_popups(page):
    for sel in ('button[aria-label="Dismiss"]', 'button:has-text("Got it")'):
        try:
            b = page.locator(sel).first
            if b.is_visible(): b.click()
        except Exception: pass

def handle_invite_dialog(page):
    """Wait for 'Add a note?', click 'Send without a note'; True once that dialog is gone."""
    btn = page.get_by_role("button", name=re.compile(r"send without a note", re.I)).first
    try:
        btn.wait_for(state="visible", timeout=6000); btn.click()
    except Exception:
        try:
            s = page.get_by_role("dialog").get_by_role("button", name=re.compile(r"^send", re.I)).first
            s.wait_for(state="visible", timeout=1500); s.click()
        except Exception: pass
    try: btn.wait_for(state="hidden", timeout=6000)
    except Exception:
        try: page.keyboard.press("Escape")
        except Exception: pass
        return False
    page.wait_for_timeout(800); return True

# ---------- approval queue ----------
QUEUE = LOGS / "queue.json"; SEEN = LOGS / "seen.json"
CARD_JS = """el => { let best = ''; let n = el;
  for (let i = 0; i < 9 && n.parentElement; i++) { n = n.parentElement;
    if (n.querySelectorAll('a[aria-label^="Invite"],button[aria-label^="Invite"]').length > 1) break;
    const t = (n.innerText || '').trim(); if (t.length > best.length) best = t; }
  return best; }"""
NOISE = re.compile(r"mutual connection|followers?$|^connect$|^message$|^follow$|^pending$|^•|^view |^status is|^1st$|^2nd$|^3rd\+?$", re.I)

def _jload(f, default):
    try: return json.loads(f.read_text(encoding="utf-8"))
    except Exception: return default

def load_queue():
    q = _jload(QUEUE, []); now = dt.datetime.now(); keep = []
    for i in q:
        age = (now - dt.datetime.fromisoformat(i["added"])).total_seconds() / 86400
        if i["status"] in ("pending", "approved") and age > 3: i["status"] = "expired"; unsee(i["profile"], i["person"])
        if age > (3 if i["status"] == "skipped" else 7): continue
        keep.append(i)
    return keep

def save_queue(q): LOGS.mkdir(exist_ok=True); QUEUE.write_text(json.dumps(q, indent=1), encoding="utf-8")

def _seen(): return _jload(SEEN, {})
def seen_names(profile): return set(_seen().get(profile, []))
def mark_seen(profile, person):
    s = _seen(); s.setdefault(profile, [])
    if person.lower() not in s[profile]: s[profile].append(person.lower())
    LOGS.mkdir(exist_ok=True); SEEN.write_text(json.dumps(s), encoding="utf-8")
def unsee(profile, person):
    s = _seen()
    if person.lower() in s.get(profile, []): s[profile].remove(person.lower()); SEEN.write_text(json.dumps(s), encoding="utf-8")

def qid(profile, person): import hashlib; return hashlib.md5(f"{profile}|{person.lower()}".encode()).hexdigest()[:10]
def open_count(profile): return sum(1 for i in load_queue() if i["profile"] == profile and i["status"] in ("pending", "approved"))
def approval_required(): return load_state().get("approval_required", True)

def card_info(btn):
    """(person, headline, full_text) for one Connect button, read from its whole search-result card."""
    label = btn.get_attribute("aria-label", timeout=5000) or ""
    person = label.replace("Invite", "").replace("to connect", "").strip()
    try: text = btn.evaluate(CARD_JS)
    except Exception: text = ""
    lines = [l.strip() for l in text.splitlines() if l.strip() and not NOISE.search(l.strip()) and l.strip().lower() != person.lower()]
    return person, " | ".join(lines)[:300], " ".join(lines)

CARDS = 'a[aria-label^="Invite"][aria-label*="to connect"], button[aria-label^="Invite"][aria-label*="to connect"]'

def open_search(page, kw, degree, pg):
    page.goto(search_url(kw, degree, pg)); page.wait_for_timeout(3500)
    why = blocked(page)
    if why: return why
    close_popups(page)
    for _ in range(6): page.mouse.wheel(0, 900); page.wait_for_timeout(700)
    return None

def scan_client(page, c, d, want, save=True):
    """Find people to offer for approval. Nothing is clicked. Government/regulator people and anything the team taught it to skip are filtered out."""
    import safety
    seen = seen_names(c["profile"]); queue = load_queue() if save else []; added = buttons = 0
    for kw in keywords_of(c):
        for pg in range(1, int(d["max_pages_per_keyword"]) + 1):
            if added >= want or RESULT["stopped"]: break
            why = open_search(page, kw, d["degree"], pg)
            if why: halt(f"{c['name']}: {why}"); break
            cards = page.locator(CARDS); n = cards.count(); buttons += n
            print(f"  '{kw}' page {pg}: {n} Connect buttons")
            if n == 0 and pg > 1: break
            for i in range(n):
                if added >= want: break
                try: person, headline, text = card_info(cards.nth(i))
                except Exception: break
                if not person or person.lower() in seen: continue
                reason = safety.check(person + " " + text, c["profile"]) if text else ("Could not read their details to check" if not save or not approval_required() else None)
                item = {"id": qid(c["profile"], person), "profile": c["profile"], "client": c["name"], "person": person, "headline": headline,
                        "kw": kw, "page": pg, "status": "skipped" if reason else "pending", "reason": reason or "", "added": dt.datetime.now().isoformat(timespec="seconds")}
                seen.add(person.lower())
                if reason: log_row(c, kw, pg, person, headline, "SKIPPED: " + reason)
                else: added += 1
                if save: queue.append(item); mark_seen(c["profile"], person)
                elif not reason: log_row(c, kw, pg, person, headline, "DRY-RUN (would offer for approval)")
            nap(d["pause_between_pages_sec"])
        if added >= want or RESULT["stopped"]: break
    if save: save_queue(queue)
    return added, buttons

def send_approved(page, c, d):
    """Click Connect ONLY for people who were approved. Checks them against the safety rules once more on the live page."""
    import safety
    errors = 0
    def items(): return sorted([i for i in load_queue() if i["profile"] == c["profile"] and i["status"] == "approved"], key=lambda i: (i["kw"], i["page"]))
    def mark(item, status, reason=""):
        q = load_queue()
        for i in q:
            if i["id"] == item["id"]: i["status"] = status; i["reason"] = reason
        save_queue(q)
        if status in ("failed", "skipped") and status == "failed": unsee(c["profile"], item["person"])
    last = None
    for item in items():
        if RESULT["stopped"]: break
        if (item["kw"], item["page"]) != last:
            why = open_search(page, item["kw"], d["degree"], item["page"])
            if why: halt(f"{c['name']}: {why}"); break
            last = (item["kw"], item["page"])
        cards = page.locator(CARDS); btn = None; info = None
        try:
            for i in range(cards.count()):
                info = card_info(cards.nth(i))
                if info[0].lower() == item["person"].lower(): btn = cards.nth(i); break
        except Exception: pass
        if btn is None:
            mark(item, "failed", "Not on the page any more - will be offered again if still relevant"); log_row(c, item["kw"], item["page"], item["person"], item["headline"], "not found on page"); continue
        reason = safety.check(item["person"] + " " + info[2], c["profile"]) if info[2] else "Could not read their details to check"
        if reason: mark(item, "skipped", reason); log_row(c, item["kw"], item["page"], item["person"], info[1], "SKIPPED: " + reason); continue
        try:
            btn.scroll_into_view_if_needed(timeout=5000); nap((0.8, 2.0)); btn.click(timeout=8000)
            if not handle_invite_dialog(page):
                log_row(c, item["kw"], item["page"], item["person"], info[1], "STOPPED: invite dialog could not be completed")
                halt(f"{c['name']}: LinkedIn changed the invite screen - agent paused for safety"); break
            why = blocked(page)
            bump(c); RESULT["sent"] += 1; errors = 0; mark(item, "sent"); log_row(c, item["kw"], item["page"], item["person"], info[1], "sent")
            print(f"    sent -> {item['person']} ({sent_today(c)} today)")
            if why: halt(f"{c['name']}: {why}"); break
        except Exception as e:
            log_row(c, item["kw"], item["page"], item["person"], info[1], f"error: {str(e)[:80]}"); errors += 1; mark(item, "failed", "Could not click")
            if errors >= 5: halt(f"{c['name']}: 5 connection attempts failed in a row - LinkedIn may have changed"); break
        nap(d["pause_between_connects_sec"])

def profile_slug(c):
    """LinkedIn slug of the person this client's account belongs to, from the saved profile address (linkedin.com/in/...). A profile address saved in the old page field still counts."""
    for k in ("profile_url", "page_url"):
        raw = (c.get(k) or "").strip()
        if re.match(r"^(www\.)?linkedin\.com/", raw, re.I): raw = "https://" + raw
        m = re.match(r"^https?://([a-z]{2,3}\.)?linkedin\.com/in/([^/?#\s]+)", raw, re.I)
        if m: return urllib.parse.unquote(m.group(2)).lower()
    return ""

NEEDS_PROFILE = "This client has no LinkedIn profile address yet. Click Log in for this client (it fills the address in automatically) or type it in Edit client. Nothing is sent without it."

def verify_person(page, c):
    """Before any connection request or post: the logged-in LinkedIn account must be the person saved for this client. None = correct, else the reason."""
    want = profile_slug(c)
    if not want: return NEEDS_PROFILE
    page.goto("https://www.linkedin.com/in/me/"); page.wait_for_timeout(3500)      # LinkedIn sends this to the logged-in person's own profile
    m = re.search(r"/in/([^/?#]+)", page.url); mine = urllib.parse.unquote(m.group(1)).lower() if m else ""
    if not mine: return "Could not tell which LinkedIn account is logged in. Click Re-login for this client"
    if mine != want: return f"Wrong LinkedIn account: logged in as {mine}, but this client's profile is {want}. Click Re-login and sign in as the client"
    return None

def is_paused(c, what):
    """True when this client is on hold for 'connections' or 'posts' (whole-client pause counts for both)."""
    return bool(c.get("paused") or c.get("pause_" + ("conn" if what == "connections" else "posts")))


def run_client(pw, c, d, dry, max_n, headless, mode="run"):
    if is_paused(c, "connections"): print(f"[{c['name']}] skipped - paused (contract on hold)"); return
    if "connections" not in uses(c): print(f"[{c['name']}] skipped - this client is only for posting"); return
    """mode 'send' = only send what was approved. mode 'run' = send anything already approved, then look for new people
    (they wait for approval, or are sent straight away if 'Ask me before connecting' is off)."""
    approval = approval_required()
    approved_waiting = sum(1 for i in load_queue() if i["profile"] == c["profile"] and i["status"] == "approved")
    want = 0
    if mode == "run":
        want = max_n if max_n else target_for(c, d) - sent_today(c) - open_count(c["profile"])
        if want <= 0 and not approved_waiting: print(f"[{c['name']}] nothing to do (target reached or people already waiting for approval)"); return
    elif not approved_waiting: return
    if mode == "run" and not keywords_of(c) and not approved_waiting: print(f"[{c['name']}] skipped - no keywords yet"); return
    if not profile_slug(c): halt(f"{c['name']}: {NEEDS_PROFILE}"); return
    ctx = launch(pw, c, headless); page = ctx.pages[0] if ctx.pages else ctx.new_page()
    try:
        page.goto("https://www.linkedin.com/feed/"); page.wait_for_timeout(3500)
        why = blocked(page)
        if why: halt(f"{c['name']}: {why} - log in again"); return
        wrong = verify_person(page, c)          # right account before anything is sent
        if wrong: halt(f"{c['name']}: {wrong}"); return
        print(f"[{c['name']}] starting: {sent_today(c)} sent today")
        if approved_waiting and not dry: send_approved(page, c, d)
        if want > 0 and not RESULT["stopped"] and keywords_of(c):
            added, buttons = scan_client(page, c, d, want, save=not dry)
            RESULT["offered"] = RESULT.get("offered", 0) + added
            if buttons == 0 and not RESULT["stopped"]:
                halt(f"{c['name']}: no Connect buttons found for any keyword - check the keywords or LinkedIn")
            elif added and not dry and not approval:     # 'Ask me first' is off: approve them and send now
                q = load_queue()
                for i in q:
                    if i["profile"] == c["profile"] and i["status"] == "pending": i["status"] = "approved"
                save_queue(q); send_approved(page, c, d)
    finally:
        try: ctx.close()
        except Exception: pass
    print(f"[{c['name']}] done: {sent_today(c)} sent today")

def _login_identity(c, slug_raw):
    """First login: the client's profile address is filled in from the account that just logged in. Later logins: it must be the same person (never overwritten). Returns (ok, note)."""
    mine = urllib.parse.unquote(slug_raw).lower(); d, cl = load_cfg()
    cur = next((x for x in cl if x["profile"] == c["profile"]), None)
    if cur is None: return True, ""
    want = profile_slug(cur)
    if not want:
        cur["profile_url"] = f"https://www.linkedin.com/in/{slug_raw}/"; save_cfg(d, cl)
        return True, f"Profile address filled in automatically: linkedin.com/in/{mine}. Check that this is the right person"
    if want != mine:
        save_state(**{"login_pending_" + c["profile"]: mine})      # lets the app offer a one-click "Use this account"
        return False, f"Wrong LinkedIn account: you signed in as {mine}, but this client's profile is {want}. Click \"Use this account\" if {mine} is the right person, or log out of LinkedIn in that window and sign in as the client"
    return True, ""

def _has_session(ctx):
    try: return any(ck.get("name") == "li_at" and "linkedin" in ck.get("domain", "") for ck in ctx.cookies())
    except Exception: return False

def _finish_identity(p, c, learn):
    """Who is signed in? LinkedIn sends /in/me/ to the logged-in person's own profile. Returns (ok, note)."""
    ok, note = True, ""
    p.goto("https://www.linkedin.com/in/me/"); p.wait_for_timeout(3500)
    m = re.search(r"/in/([^/?#]+)", p.url)
    if m and m.group(1).lower() != "me":
        ok, note = _login_identity(c, m.group(1))
        if ok and learn and "posts" in uses(c):      # new client: read its last 10 posts now to learn its style
            try:
                import poster; cur = next((x for x in load_cfg()[1] if x["profile"] == c["profile"]), c)
                if poster.target(cur): note = (note + ". " if note else "") + poster.learn_existing(p, cur)
            except Exception: pass
    return ok, note

def do_login(pw, c):
    ctx = launch(pw, c, False); p = ctx.pages[0] if ctx.pages else ctx.new_page()
    ok = False; note = ""; key = "login_" + c["profile"]
    save_state(**{key: False, "login_note_" + c["profile"]: "", "login_pending_" + c["profile"]: ""})
    try:
        p.goto("https://www.linkedin.com/login"); end = time.time() + 900; calm = 0
        while time.time() < end:
            u = p.url; busy = re.search(r"checkpoint|authwall|/login|/uas/", u)
            if re.search(r"linkedin\.com/(feed|in/|mynetwork|search|jobs|messaging|notifications)", u) or (_has_session(ctx) and not busy): calm += 1
            else: calm = 0
            if calm >= 2: ok = True; break      # signed in (page or session cookie), stable for 2 seconds
            time.sleep(1)
        if ok:
            save_state(**{key: True})      # recorded at once: closing the window early no longer loses the login
            time.sleep(2)
            ok, note = _finish_identity(p, c, True)
    except Exception: pass
    try: ctx.close()
    except Exception: pass
    save_state(**{key: ok, "login_note_" + c["profile"]: note}); print("Login saved" if ok else "Login not completed", note)

def check_login(pw, c):
    """For a client that is already signed in inside its own browser profile but the app does not know it yet: look, without asking the person to sign in again."""
    key = "login_" + c["profile"]; ok = False; note = "No saved LinkedIn sign-in found for this client. Click Log in"
    try:
        ctx = launch(pw, c, True)
    except Exception as e:
        save_state(**{"login_note_" + c["profile"]: "Could not check: close the LinkedIn window for this client first"}); print("Could not open the browser profile", e); return
    try:
        p = ctx.pages[0] if ctx.pages else ctx.new_page(); p.goto("https://www.linkedin.com/feed/"); p.wait_for_timeout(3500)
        if _has_session(ctx) and not re.search(r"checkpoint|authwall|/login|/uas/", p.url):
            ok, note = _finish_identity(p, c, False)
    except Exception as e: note = "Could not check the sign-in: " + str(e)[:80]
    try: ctx.close()
    except Exception: pass
    save_state(**{key: ok, "login_note_" + c["profile"]: note}); print("Signed in" if ok else "Not signed in", note)

# ---------- computer prep & schedule ----------
def sleep_off():
    """Stop the computer sleeping so the daily run always happens."""
    ok = False
    if WIN:
        run = lambda a: subprocess.run(a, capture_output=True, creationflags=NOWIN).returncode == 0
        ok = all([run(["powercfg", "/change", "standby-timeout-ac", "0"]), run(["powercfg", "/change", "standby-timeout-dc", "0"])])
        run(["powercfg", "/change", "hibernate-timeout-ac", "0"]); run(["powercfg", "/change", "hibernate-timeout-dc", "0"])
        run(["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "SUB_BUTTONS", "LIDACTION", "0"])
        run(["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", "SUB_BUTTONS", "LIDACTION", "0"])
        run(["powercfg", "/setactive", "SCHEME_CURRENT"])
    elif MAC:
        r = subprocess.run(["osascript", "-e", 'do shell script "pmset -a sleep 0; pmset -a disablesleep 1" with administrator privileges'], capture_output=True)
        ok = r.returncode == 0
    save_state(sleep_off=ok); print("Sleep turned off" if ok else "Could not change sleep setting"); return ok

def _pyexe():
    if WIN:
        p = ROOT / ".venv" / "Scripts" / "pythonw.exe"
        return str(p) if p.exists() else sys.executable
    p = ROOT / ".venv" / "bin" / "python"
    return str(p) if p.exists() else sys.executable

def pin_taskbar():
    """Windows: adds a Start Menu entry and tries the taskbar-pin verb (newer Windows versions block it, so the UI also shows the one right-click step)."""
    if not WIN: return {"ok": True, "how": "mac"}
    make_shortcut()
    ps = ("$d=[Environment]::GetFolderPath('Desktop');$p=[Environment]::GetFolderPath('Programs');$n='ShareMedia Manager.lnk';Copy-Item (Join-Path $d $n) (Join-Path $p $n) -Force;"
          "$ok=$false;try{$i=(New-Object -ComObject Shell.Application).Namespace($p).ParseName($n);foreach($v in $i.Verbs()){if($v.Name.Replace('&','') -match 'taskbar' -and $v.Name -notmatch 'Unpin'){$v.DoIt();$ok=$true}}}catch{};if($ok){'pinned'}else{'manual'}")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=30, creationflags=NOWIN)
        return {"ok": True, "how": "pinned" if "pinned" in r.stdout else "manual"}
    except Exception as e: return {"ok": True, "how": "manual"}

def make_shortcut():
    """Desktop shortcut 'ShareMedia Manager' with the brand icon (Windows)."""
    try:
        import brand
        cfgd = ROOT / "config"; ico = cfgd / "app.ico"
        if not any((cfgd / f"logo.{e}").exists() for e in ("png", "jpg", "jpeg", "webp", "svg", "gif")):
            ico.write_bytes(brand.default_ico())      # default brand icon, multi-size so it is sharp on the taskbar too
        elif not ico.exists(): ico.write_bytes(brand.default_ico())
        if not WIN: return
        name = "ShareMedia Manager"; lnk = "$d\\" + name + ".lnk"
        ps = ("$d=[Environment]::GetFolderPath('Desktop');Remove-Item \"$d\\ShareMedia Connections.lnk\",\"$d\\ShareMedia Posts.lnk\" -ErrorAction SilentlyContinue;$s=(New-Object -ComObject WScript.Shell).CreateShortcut(\"" + lnk + "\");"
              f"$s.TargetPath='{_pyexe()}';$s.Arguments='ui.py';$s.WorkingDirectory='{ROOT}';$s.IconLocation='{ico}';$s.Description='{name}';$s.Save()")
        subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, creationflags=NOWIN)
    except Exception as e: print("shortcut skipped:", e)

POSTS_TASK = "ShareMedia Posting Agent"
SCHEDULES = {   # one independent schedule per agent: Windows task name, command, Mac launchd label
    "connections": {"task": TASK_NAME, "cmd": "daily", "label": "com.sharemedia.connections"},
    "posts": {"task": POSTS_TASK, "cmd": "posts-daily", "label": "com.sharemedia.posts"}}

def _tname(kind, profile=None): return SCHEDULES[kind]["task"] + (f" - {profile}" if profile else "")
def _plist(kind, profile=None): return Path.home() / "Library/LaunchAgents" / (SCHEDULES[kind]["label"] + (f".{profile}" if profile else "") + ".plist")

def schedule(kind, run_time, profile=None):
    """Create/replace one scheduled task. profile=None -> one task for all clients; profile=<client> -> that client's own task."""
    sc = SCHEDULES[kind]; ok, msg = False, ""; extra = f" --client {profile}" if profile else ""
    if WIN:
        py = _pyexe()
        ps = (f"$a=New-ScheduledTaskAction -Execute '{py}' -Argument 'agent.py {sc['cmd']}{extra}' -WorkingDirectory '{ROOT}';"
              f"$t=New-ScheduledTaskTrigger -Daily -At '{run_time}';"
              "$s=New-ScheduledTaskSettingsSet -StartWhenAvailable -WakeToRun -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Hours 5);"
              f"Register-ScheduledTask -TaskName '{_tname(kind, profile)}' -Action $a -Trigger $t -Settings $s -Force | Out-Null")
        r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, creationflags=NOWIN)
        ok, msg = r.returncode == 0, (r.stdout + r.stderr).strip()
        if not ok:   # simple fallback
            r = subprocess.run(["schtasks", "/Create", "/F", "/SC", "DAILY", "/ST", run_time, "/TN", _tname(kind, profile),
                                "/TR", f'cmd /c "cd /d "{ROOT}" && "{py}" agent.py {sc["cmd"]}{extra}"'], capture_output=True, text=True, creationflags=NOWIN)
            ok, msg = r.returncode == 0, (r.stdout + r.stderr).strip()
    elif MAC:
        h, m = run_time.split(":"); pl = _plist(kind, profile); pl.parent.mkdir(exist_ok=True)
        args = "".join(f"<string>{x}</string>" for x in ["agent.py", sc["cmd"]] + (["--client", profile] if profile else []))
        pl.write_text(f'''<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict><key>Label</key><string>{sc["label"]}{"." + profile if profile else ""}</string>
<key>WorkingDirectory</key><string>{ROOT}</string>
<key>ProgramArguments</key><array><string>{_pyexe()}</string>{args}</array>
<key>StartCalendarInterval</key><dict><key>Hour</key><integer>{int(h)}</integer><key>Minute</key><integer>{int(m)}</integer></dict></dict></plist>''')
        subprocess.run(["launchctl", "unload", str(pl)], capture_output=True)
        r = subprocess.run(["launchctl", "load", "-w", str(pl)], capture_output=True, text=True)
        ok, msg = r.returncode == 0, (r.stdout + r.stderr).strip()
    else: msg = "Scheduling supports Windows and Mac only"
    return ok, msg

def existing_tasks(kind):
    """Names of every scheduled task of this kind that exists now (the all-clients one and any per-client ones)."""
    base = SCHEDULES[kind]["task"]; out = []
    if WIN:
        r = subprocess.run(["schtasks", "/Query", "/FO", "CSV", "/NH"], capture_output=True, text=True, creationflags=NOWIN)
        for line in r.stdout.splitlines():
            n = line.split('","')[0].strip('"').lstrip("\\")
            if n == base or n.startswith(base + " - "): out.append(n)
    elif MAC:
        for f in (Path.home() / "Library/LaunchAgents").glob(SCHEDULES[kind]["label"] + "*.plist"): out.append(f.name[:-6])
    return out

def _delete_task(name):
    if WIN: subprocess.run(["schtasks", "/Delete", "/F", "/TN", name], capture_output=True, creationflags=NOWIN)
    elif MAC:
        pl = Path.home() / "Library/LaunchAgents" / (name + ".plist"); subprocess.run(["launchctl", "unload", "-w", str(pl)], capture_output=True)
        if pl.exists(): pl.unlink()

def same_schedule(): return load_state().get("same_schedule", True)

def client_time(c, kind, d=None):
    """When this client's task runs: its own time if the schedules are separate and it has one, otherwise the shared default."""
    d = d or load_cfg()[0]
    default = d["daily_run_time"] if kind == "connections" else load_state().get("posts_time", DEFAULT_POSTS_TIME)
    return (c.get("run_time" if kind == "connections" else "posts_time") or default) if not same_schedule() else default

def sync_schedules():
    """Make the computer's scheduled tasks match the settings: one shared task per agent, or one task per active client when each client has its own schedule.
    Safe to call any time (after a time change, pause/resume, add/remove client, or switching the 'same schedule' option)."""
    d, clients = load_cfg(); s = load_state(); same = same_schedule(); all_ok = True; msgs = []
    for kind, flag, need in (("connections", "automation", "connections"), ("posts", "posts_automation", "posts")):
        want = {}
        if s.get(flag):
            if same: want[_tname(kind)] = (None, d["daily_run_time"] if kind == "connections" else s.get("posts_time", DEFAULT_POSTS_TIME))
            else:
                for c in clients:
                    if is_paused(c, need) or need not in uses(c): continue
                    want[_tname(kind, c["profile"])] = (c["profile"], client_time(c, kind, d))
        for name, (prof, t) in want.items():
            ok, msg = schedule(kind, t, prof); all_ok &= ok; msgs.append(msg) if not ok else None
        for name in existing_tasks(kind):
            if name not in want: _delete_task(name)
    return all_ok, "; ".join(m for m in msgs if m)

def schedule_daily(run_time=None):
    if run_time:
        d, c = load_cfg(); d["daily_run_time"] = run_time; save_cfg(d, c)
    d, _ = load_cfg(); save_state(automation=True, run_time=d["daily_run_time"])
    ok, msg = sync_schedules(); save_state(automation=ok)
    print(f"Daily automation ON at {d['daily_run_time']}" if ok else "Could not schedule: " + msg); return ok

def schedule_posts(run_time=None):
    save_state(posts_automation=True, posts_time=run_time or load_state().get("posts_time", DEFAULT_POSTS_TIME))
    ok, msg = sync_schedules(); save_state(posts_automation=ok)
    print(f"Daily posting ON at {load_state()['posts_time']}" if ok else "Could not schedule posting: " + msg); return ok

def unschedule():
    save_state(automation=False); sync_schedules(); print("Daily automation OFF")

def unschedule_posts():
    save_state(posts_automation=False); sync_schedules(); print("Daily posting OFF")

def task_exists(): return bool(existing_tasks("connections"))
def posts_task_exists(): return bool(existing_tasks("posts"))

# ---------- alerts ----------
def error_sound(times=3):
    """Audible error tone on this computer when the agent pauses (can be turned off in Settings)."""
    if load_state().get("sound_off"): return
    try:
        for _ in range(times):
            if WIN:
                import winsound; winsound.MessageBeep(winsound.MB_ICONHAND); time.sleep(0.9)
            elif MAC: subprocess.run(["afplay", "/System/Library/Sounds/Basso.aiff"], capture_output=True)
            else: print("\a", end="", flush=True); time.sleep(0.6)
    except Exception: pass

def notify_pause(reason, reminder=False):
    import alerts, socket
    error_sound()
    c = alerts.load()
    if not c.get("enabled"): return
    d, clients = load_cfg()
    sent = sum(sent_today(x) for x in clients); when = dt.datetime.now().strftime("%a %b %d, %I:%M %p")
    comp = socket.gethostname()
    steps = ['Open <b>ShareMedia Manager</b> (the icon on the Desktop of ' + comp + ').',
             'If it says LinkedIn needs a login, click <b>Log in</b> next to the client and sign in once.',
             'Click <b>Fix &amp; resume</b>. The daily runs continue by themselves.']
    plain_steps = [s.replace("<b>", "").replace("</b>", "").replace("&amp;", "&") for s in steps]
    head = "Still paused" if reminder else "Paused"
    subject = f"{'Reminder: ' if reminder else ''}ShareMedia Manager paused - {reason[:60]}"
    text = (f"The ShareMedia Manager agent on {comp} is {head.lower()} (since {when}).\n\nWhy: {reason}\nConnections sent today: {sent}\n\n"
            "What to do (about 1 minute):\n" + "\n".join(f"{i+1}. {s}" for i, s in enumerate(plain_steps)) +
            "\n\nIt will not run again until this is done. You can reply to this email - your reply goes to everyone on this alert.")
    html = alerts.html_wrap(f"{head}: needs a quick look", [("Why", reason), ("Computer", comp), ("When", when), ("Sent today", str(sent))], steps)
    ok, msg = alerts.send(subject, text, html)
    save_state(alert_at=dt.datetime.now().isoformat(timespec="seconds") if ok else load_state().get("alert_at"), alert_error="" if ok else msg)
    print("Alert email sent" if ok else "Alert email NOT sent: " + msg)

def notify_waiting(n):
    """Tell the team (email, same recipients as pause alerts) that people are waiting for approval."""
    try:
        import alerts, socket
        if not alerts.load().get("enabled") or not alerts.gmail_signed_in(): return
        comp = socket.gethostname()
        alerts.send(f"ShareMedia Manager: {n} people waiting for your approval",
                    f"{n} LinkedIn connections are lined up on {comp} and will NOT be sent until someone approves them.\n\nOpen ShareMedia Manager, review the list, and click Approve & send.")
    except Exception as e: print("waiting notice failed:", e)

# ---------- main ----------
def find_client(clients, name):
    for c in clients:
        if name.lower() in (c["name"].lower(), c["profile"].lower()): return c
    sys.exit(f"No client '{name}'")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["run", "send", "posts-scan", "posts-daily", "posts-send", "posts-learn", "client-both", "growth", "daily", "login", "login-check", "alertlogin", "maillogin", "prepare", "schedule", "unschedule"])
    ap.add_argument("--client"); ap.add_argument("--dry-run", action="store_true"); ap.add_argument("--max", type=int)
    ap.add_argument("--headless", action="store_true")
    a = ap.parse_args(); LOGS.mkdir(exist_ok=True)
    if a.cmd in ("daily", "posts-daily") or sys.stdout is None:
        sys.stdout = sys.stderr = open(LOGS / ("daily_run.log" if a.cmd == "daily" else "posts_run.log" if a.cmd == "posts-daily" else os.devnull), "a", buffering=1, encoding="utf-8")
        print("\n=====", dt.datetime.now().isoformat(timespec="seconds"))
    d, clients = load_cfg()
    if a.cmd == "prepare":
        try: import openpyxl
        except ImportError: subprocess.run([sys.executable, "-m", "pip", "install", "-q", "openpyxl"], creationflags=NOWIN)
        if not load_state().get("sleep_off"): sleep_off()
        restore_if_empty(); ensure_defaults(); make_shortcut(); fix_root(); backup_settings()
        return
    if a.cmd == "schedule": sleep_off(); schedule_daily(); return
    if a.cmd == "unschedule": unschedule(); return
    if a.cmd == "maillogin":      # sign in to Outlook on the web once (the person types the password); the Posting Agent then reads the approval emails from it
        import poster; ok = poster.mail_login()
        if ok or not poster.mail_signed_in(): save_state(mail_login=ok)
        print("Outlook sign-in saved" if ok else "Outlook sign-in not completed"); return
    if a.cmd == "alertlogin":
        import alerts; ok = alerts.gmail_login()
        if ok or not alerts.gmail_signed_in(): save_state(alert_login_sm=ok)      # an abandoned re-sign-in never marks a working sign-in as lost
        print("Gmail sign-in saved" if ok else "Gmail sign-in not completed"); return
    from playwright.sync_api import sync_playwright
    if a.cmd == "login":
        with sync_playwright() as pw: do_login(pw, find_client(clients, a.client))
        return
    if a.cmd == "login-check":
        with sync_playwright() as pw: check_login(pw, find_client(clients, a.client))
        return
    if a.cmd in ("posts-scan", "posts-daily"):
        import poster
        pcl = [find_client(clients, a.client)] if a.client else clients      # --client = just this client (the Run now button / its own schedule)
        if a.cmd == "posts-daily":
            if load_state().get("paused"): print("Paused after an error:", load_state().get("pause_reason")); return
            time.sleep(random.uniform(0, 600))
        try: n = poster.scan(pcl); print(f"{n} new posts are waiting for review"); save_state(posts_checked=dt.datetime.now().isoformat(timespec="seconds"))
        except Exception as e: print("Could not check for posts:", e); sys.exit(1)
        if not poster.approval_required():       # 'Ask me before posting' is off: approve and schedule right away
            for p_ in [p_ for p_ in poster.load_posts() if p_["status"] == "pending" and not p_.get("hold") and poster.fresh_for_auto(p_) and p_["profile"] != "_unassigned" and (not a.client or p_["profile"] == pcl[0]["profile"])]: poster.decide(p_["id"], "approve", p_["text"], p_["when"])
        if any(p_["status"] == "approved" and (not a.client or p_["profile"] == pcl[0]["profile"]) for p_ in poster.load_posts()):     # approved by hand earlier or just now -> schedule them on LinkedIn
            try:
                with sync_playwright() as pw: poster.send_approved(pw, pcl, d, False)
            except Exception as e: halt(f"Unexpected error: {str(e)[:150]}")
            if RESULT["stopped"]: save_state(paused=True, pause_reason=RESULT["reason"], paused_at=dt.datetime.now().isoformat(timespec="seconds")); notify_pause(RESULT["reason"])
        return
    if a.cmd == "client-both":      # one client: connections first, then posts (the "Both" button)
        for step in ("run", "posts-scan"):
            subprocess.call([sys.executable, str(Path(__file__).resolve()), step, "--client", a.client], creationflags=NOWIN)
        return
    if a.cmd == "posts-learn":      # read each client's last 10 LinkedIn posts to learn the style they like (only after the right account is confirmed)
        import poster
        with sync_playwright() as pw:
            for c in ([find_client(clients, a.client)] if a.client else [c for c in clients if "posts" in uses(c) and not is_paused(c, "posts")]):
                if not poster.target(c): print(f"[{c['name']}] skipped - no LinkedIn address yet"); continue
                ctx = launch(pw, c, False); pg = ctx.pages[0] if ctx.pages else ctx.new_page()
                try:
                    why = blocked((pg.goto("https://www.linkedin.com/feed/"), pg.wait_for_timeout(3000), pg)[2]) or poster.verify_account(pg, c)
                    print(f"[{c['name']}]", why or poster.learn_existing(pg, c))
                except Exception as e: print(f"[{c['name']}] could not learn:", str(e)[:120])
                finally:
                    try: ctx.close()
                    except Exception: pass
        return
    if a.cmd == "growth":      # read every client's total connections and followers (dashboard "Check now")
        import growth
        with sync_playwright() as pw:
            for c in ([find_client(clients, a.client)] if a.client else clients): growth.snapshot(pw, c, a.headless)
        return
    if a.cmd == "posts-send":
        import poster
        try:
            with sync_playwright() as pw: poster.send_approved(pw, [find_client(clients, a.client)] if a.client else clients, d, a.dry_run)
        except Exception as e: halt(f"Unexpected error: {str(e)[:150]}")
        if RESULT["stopped"] and not a.dry_run:
            save_state(paused=True, pause_reason=RESULT["reason"], paused_at=dt.datetime.now().isoformat(timespec="seconds")); notify_pause(RESULT["reason"])
        return
    s = load_state()
    if a.cmd == "daily":
        if s.get("paused"):
            print("Paused after an error:", s.get("pause_reason"))
            last = s.get("alert_at")   # reminder email about once a day while still paused
            if not last or (dt.datetime.now() - dt.datetime.fromisoformat(last)).total_seconds() > 20 * 3600:
                notify_pause(s.get("pause_reason", "paused"), reminder=True)
            return
        time.sleep(random.uniform(0, 900))        # random start delay so it is not robotic
    targets = [find_client(clients, a.client)] if a.client else clients
    try:
        with sync_playwright() as pw:
            for i, c in enumerate(targets):
                if a.cmd == "daily":      # one growth reading per client per day, before the work starts
                    try:
                        import growth
                        if not growth.checked_today(c["profile"]): growth.snapshot(pw, c, a.headless)
                    except Exception as e: print("growth reading skipped:", str(e)[:100])
                run_client(pw, c, d, a.dry_run, a.max, a.headless, "send" if a.cmd == "send" else "run")
                if RESULT["stopped"]: break
                if i < len(targets) - 1: time.sleep(random.uniform(30, 90))
    except Exception as e:
        halt(f"Unexpected error: {str(e)[:150]}")
    if a.dry_run: return
    if RESULT["stopped"]:
        save_state(paused=True, pause_reason=RESULT["reason"], paused_at=dt.datetime.now().isoformat(timespec="seconds"))
        notify_pause(RESULT["reason"])
    elif RESULT.get("offered") and approval_required():
        n = sum(1 for i in load_queue() if i["status"] == "pending")
        save_state(waiting=n); print(f"{n} people are waiting for approval"); notify_waiting(n)
    if not RESULT["stopped"] and RESULT["sent"] > 0:
        save_state(paused=False, pause_reason="", setup_done=True)   # first clean run: setup guide is hidden for good
        if not load_state().get("automation"):
            print("First clean run - turning on daily automation"); sleep_off(); schedule_daily()

if __name__ == "__main__":
    main()
