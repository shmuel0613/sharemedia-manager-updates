#!/usr/bin/env python3
"""ShareMedia Posting Agent: picks up suggested posts, formats them, waits for approval, schedules them on LinkedIn,
and learns from every approval / edit / rejection - per client, plus ShareMedia-wide habits."""
import urllib.parse, difflib, hashlib, html, json, re, collections, datetime as dt
from pathlib import Path
import agent

ROOT, LOGS = agent.ROOT, agent.LOGS
POSTS = LOGS / "posts.json"; LEARN = LOGS / "post_learning"
INBOX = ROOT / "posting" / "inbox"; TAGS = ROOT / "config" / "hashtags"; CFGF = ROOT / "config" / "posting.json"
DEFAULT_TIME = "08:30"; DEFAULT_TAGS = 5
SCHED_DEFAULT = {"days": [0, 1, 2], "time": "08:30"}      # ShareMedia's own habit from the training video: Mon/Tue/Wed at 8:30 AM, one post per client per day

# ---------- posting schedule (any days, any time; ShareMedia-wide default plus an optional override per client) ----------
def _cfg():
    try: return json.loads(CFGF.read_text())
    except Exception: return {}

def default_sched():
    c = _cfg().get("schedule", {})
    return {"days": sorted({int(x) for x in c.get("days", [])} & set(range(7))) or list(SCHED_DEFAULT["days"]), "time": c.get("time") or SCHED_DEFAULT["time"]}

def sched_for(c):
    d = default_sched(); days = sorted({int(x) for x in (c.get("post_days") or [])} & set(range(7)))
    return {"days": days or d["days"], "time": c.get("post_time") or d["time"], "custom": bool(days or c.get("post_time"))}

def save_default_sched(days, time):
    cfg = _cfg(); cfg["schedule"] = {"days": sorted({int(x) for x in days} & set(range(7))) or list(SCHED_DEFAULT["days"]), "time": time or SCHED_DEFAULT["time"]}
    CFGF.parent.mkdir(exist_ok=True); CFGF.write_text(json.dumps(cfg, indent=1))

def _client(profile):
    for c in agent.load_cfg()[1]:
        if c["profile"] == profile: return c
    return {"profile": profile}

# ---------- source (swap this block for Outlook / Google Sheet when real access exists) ----------
def source_name(): return json.loads(CFGF.read_text()).get("source", "folder") if CFGF.exists() else "folder"

def fetch_drafts(profile):
    """Yield dicts {source_id, subject, raw, image(path or None)} for one client that have not been picked up yet.
    Folder source: posting/inbox/<client-profile>/*.txt  (first line 'Subject: ...', optional 'Image: file.png', blank line, then the post)."""
    if source_name() != "folder": raise RuntimeError("Outlook / Sheet source is not connected yet")
    d = INBOX / profile
    for f in sorted(d.glob("*.txt")) if d.exists() else []:
        txt = f.read_text(encoding="utf-8", errors="ignore"); head, _, body = txt.partition("\n\n")
        subj = re.search(r"^subject:\s*(.+)$", head, re.I | re.M); img = re.search(r"^image:\s*(.+)$", head, re.I | re.M)
        if not subj and not img: body = txt
        p = (d / img.group(1).strip()) if img else None
        yield {"source_id": f"{profile}/{f.name}", "subject": subj.group(1).strip() if subj else f.stem, "raw": body.strip(),
               "image": str(p) if p and p.exists() else None}

def client_tags(profile):
    f = TAGS / f"{profile}.txt"
    own = [t for t in re.findall(r"#\w+", f.read_text(encoding="utf-8", errors="ignore"))] if f.exists() else []
    for t in existing(profile).get("traits", {}).get("top_hashtags", []):      # hashtags the client already uses on LinkedIn
        if t.lower() not in [o.lower() for o in own]: own.append(t)
    return own

# ---------- storage ----------
def jload(f, default):
    try: return json.loads(Path(f).read_text(encoding="utf-8"))
    except Exception: return default
def load_posts(): return jload(POSTS, [])
def save_posts(p): LOGS.mkdir(exist_ok=True); POSTS.write_text(json.dumps(p, indent=1), encoding="utf-8")
def approval_required(): return agent.load_state().get("post_approval_required", True)

# ---------- learning ----------
def _lf(profile): LEARN.mkdir(parents=True, exist_ok=True); return LEARN / f"{profile}.jsonl"
def history(profile):
    f = _lf(profile)
    return [json.loads(l) for l in f.read_text(encoding="utf-8").splitlines() if l.strip()] if f.exists() else []

def learn(item, decision, final_text, note=""):
    """Save the draft, what we proposed and what the human did with it. This is the corpus the agent learns from."""
    rec = {"ts": dt.datetime.now().isoformat(timespec="seconds"), "decision": decision, "subject": item["subject"], "raw": item["raw"],
           "proposed": item["proposed"], "final": final_text, "when": item["when"], "note": note,
           "edited": final_text.strip() != item["proposed"].strip()}
    with _lf(item["profile"]).open("a", encoding="utf-8") as fh: fh.write(json.dumps(rec) + "\n")
    with _lf("_sharemedia").open("a", encoding="utf-8") as fh: fh.write(json.dumps(dict(rec, client=item["profile"])) + "\n")

def _words(t): return re.findall(r"\S+", t)
def replacements(profile):
    """Wording the team changed the same way 2+ times (e.g. 'utilize' -> 'use'): applied automatically next time."""
    cnt = collections.Counter()
    for h in history(profile):
        if h["decision"] != "approved" or not h["edited"]: continue
        a, b = _words(h["proposed"]), _words(h["final"])
        for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b).get_opcodes():
            if op == "replace" and i2 - i1 <= 3 and j2 - j1 <= 3: cnt[(" ".join(a[i1:i2]), " ".join(b[j1:j2]))] += 1
    return {k: v for k, v in cnt.items() if v >= 2}

def style(profile):
    """What it has learned for this client (falls back to ShareMedia-wide habits, then defaults)."""
    def stats(rows):
        ok = [r for r in rows if r["decision"] == "approved"]
        tags = [len(re.findall(r"#\w+", r["final"])) for r in ok]; times = [r["when"][11:16] for r in ok if r.get("when")]
        days = [dt.datetime.fromisoformat(r["when"]).weekday() for r in ok if r.get("when")]
        return ok, tags, times, days
    own = history(profile); ok, tags, times, days = stats(own)
    if len(ok) < 3: ok2, tags2, times2, days2 = stats(history("_sharemedia")); tags, times, days = (tags or tags2), (times or times2), (days or days2)
    ex = existing(profile).get("traits", {})
    if len(ok) < 3 and ex.get("posts"): tags = [ex["hashtags"]]      # own approvals first, then what the client already posts, then ShareMedia-wide habits
    med = sorted(tags)[len(tags) // 2] if tags else DEFAULT_TAGS
    return {"approved": sum(1 for r in own if r["decision"] == "approved"), "rejected": sum(1 for r in own if r["decision"] == "rejected"),
            "edited": sum(1 for r in own if r["decision"] == "approved" and r["edited"]),
            "hashtags": med, "time": collections.Counter(times).most_common(1)[0][0] if times else DEFAULT_TIME,
            "days": sorted({d for d, _ in collections.Counter(days).most_common(3)}) if days else [0, 1, 2],
            "replacements": [{"from": a, "to": b, "times": n} for (a, b), n in replacements(profile).items()],
            "reject_notes": [r["note"] for r in own if r["decision"] == "rejected" and r["note"]][-5:],
            "existing": dict(ex, read_at=existing(profile).get("read_at", ""), source=existing(profile).get("source", ""))}

# ---------- learning from the client's own recent LinkedIn posts ----------
EXISTING = LEARN / "existing"
EMOJI = re.compile("[\U0001F300-\U0001FAFF\u2600-\u27BF]")

def existing(profile):
    """The last posts read from the client's own LinkedIn (company page or profile) + the style traits taken from them."""
    return jload(EXISTING / f"{profile}.json", {})

def _traits(posts):
    texts = [p["text"] for p in posts if p.get("text")]
    if not texts: return {}
    words = sorted(len(t.split()) for t in texts); tags = [re.findall(r"#\w+", t) for t in texts]; counts = sorted(len(x) for x in tags)
    paras = sorted(len([x for x in re.split(r"\n\s*\n", t) if x.strip()]) for t in texts)
    freq = collections.Counter(t.lower() for x in tags for t in set(x))
    last = collections.Counter(re.sub(r"\s+", " ", [l for l in t.strip().split("\n") if l.strip() and not l.strip().startswith("#")][-1]).strip().lower() for t in texts if [l for l in t.split("\n") if l.strip() and not l.strip().startswith("#")])
    sig = next((l for l, n in last.most_common(1) if n >= 3 and len(texts) >= 5), "")
    m = len(texts) // 2
    return {"posts": len(texts), "words": words[m], "paragraphs": paras[m], "hashtags": counts[m], "emoji_share": round(sum(1 for t in texts if EMOJI.search(t)) / len(texts), 2),
            "question_share": round(sum(1 for t in texts if "?" in t) / len(texts), 2), "top_hashtags": [t for t, n in freq.most_common(8) if n >= 2], "signature_line": sig}

EXTRACT_JS = r"""async () => {
  for (let i = 0; i < 6; i++) { window.scrollTo(0, document.body.scrollHeight); await new Promise(r => setTimeout(r, 1200)); }
  for (const b of document.querySelectorAll('button, span[role=button], a')) { if (/^(…|\.\.\.)?\s*(show|see)?\s*more$/i.test((b.innerText || '').trim())) { try { b.click() } catch (e) {} } }
  await new Promise(r => setTimeout(r, 1200));
  const parts = document.body.innerText.split(/\nFeed post(?: number \d+)?\n/).slice(1), out = [];
  for (const raw of parts) {
    const lines = raw.split('\n').map(l => l.trim());
    if (/reposted this|commented on|likes this|celebrates this|supports this|loves this|insightful/i.test(lines.slice(0, 6).join(' '))) continue;
    let a = lines.findIndex(l => /^\d+\s?(s|m|h|d|w|mo|yr)\b/i.test(l)); if (a < 0) continue;
    const age = lines[a].split(/[ •]/)[0]; let body = [];
    for (let i = a + 1; i < lines.length; i++) {
      const l = lines[i];
      if (/^(\d[\d,]*\s+(reactions?|comments?|reposts?|likes?|views?|impressions?)|like|comment|repost|send|boost|promoted|…\s?more|…\s?show more|get up to)/i.test(l)) break;
      body.push(l);
    }
    const text = body.join('\n').replace(/\n{3,}/g, '\n\n').trim(); if (text.length > 20) out.push({ text, age });
  }
  return out;
}"""

def learn_existing(page, c, n=10):
    """Read the client's last n posts from their own LinkedIn and keep them (with style traits) as what this client's posts usually look like. Returns a note."""
    t = target(c)
    if not t: return NEEDS_ADDRESS
    kind, ident, url = t
    page.goto(url if kind == "company" else f"https://www.linkedin.com/in/{ident}/recent-activity/shares/"); page.wait_for_timeout(4500)
    try: rows = page.evaluate(EXTRACT_JS)
    except Exception as e: return f"Could not read recent posts ({str(e).splitlines()[0][:100]})"
    rows = (rows or [])[:n]
    EXISTING.mkdir(parents=True, exist_ok=True)
    (EXISTING / f"{c['profile']}.json").write_text(json.dumps({"read_at": dt.datetime.now().isoformat(timespec="seconds"), "source": "company page" if kind == "company" else "profile", "posts": rows, "traits": _traits(rows)}, indent=1), encoding="utf-8")
    return f"Learned from {len(rows)} recent posts" if rows else "No posts found yet (a new page has none to learn from)"

# ---------- formatting ----------
JUNK = re.compile(r"^(sent from my .*|approved\.?|excellent\.?|it will be uploaded.*|from:.*|date:.*|to:.*|cc:.*|subject:.*|-+ ?forwarded message ?-+)$", re.I)

def clean_text(raw):
    t = raw
    for _ in range(3): t = html.unescape(t)                       # &amp; -> &   (fixes "D&O" arriving as "Damp;O")
    t = re.sub(r"(?<=\w)amp;(?=\w)", "&", t)
    t = t.replace("\r\n", "\n").replace("\r", "\n").replace(" ", " ")
    lines = [l.rstrip() for l in t.split("\n") if not JUNK.match(l.strip())]
    t = "\n".join(lines).strip()
    t = re.sub(r"\n{3,}", "\n\n", t)
    if "\n" not in t and len(t) > 280:                              # one giant block: put paragraph breaks back (2 sentences each)
        s = re.split(r"(?<=[.!?])\s+(?=[A-Z])", t); t = "\n\n".join(" ".join(s[i:i + 2]) for i in range(0, len(s), 2))
    elif "\n\n" not in t and t.count("\n") >= 2: t = t.replace("\n", "\n\n")
    return t

def pick_tags(text, profile, n):
    have = re.findall(r"#\w+", text)
    if have: return []
    words = set(w.lower() for w in re.findall(r"[A-Za-z]{4,}", text)); tags = client_tags(profile)
    rel = [t for t in tags if t[1:].lower() in words or any(w.startswith(t[1:].lower()[:6]) for w in words if len(t) > 6)]
    out = []
    for t in rel + tags:
        if t.lower() not in [o.lower() for o in out]: out.append(t)
    return out[:n]

def format_post(raw, profile):
    s = style(profile); t = clean_text(raw)
    for (a, b), _ in replacements(profile).items(): t = re.sub(r"\b" + re.escape(a) + r"\b", b, t)
    tags = pick_tags(t, profile, s["hashtags"])
    return t + ("\n\n" + " ".join(tags) if tags else "")

def next_slot(profile, taken=None):
    """First chosen weekday from tomorrow that has no post for this client yet, at the chosen time (explicit schedule; the video habit Mon-Wed 8:30 AM unless changed)."""
    sc = sched_for(_client(profile)); taken = taken or {i["when"][:10] for i in load_posts() if i["profile"] == profile and i["status"] in ("pending", "approved", "scheduled")}
    hh, mm = map(int, sc["time"].split(":")); d = dt.date.today() + dt.timedelta(days=1)
    for _ in range(60):
        if d.weekday() in sc["days"] and d.isoformat() not in taken: return dt.datetime(d.year, d.month, d.day, hh, mm).isoformat(timespec="minutes")
        d += dt.timedelta(days=1)
    return dt.datetime(d.year, d.month, d.day, hh, mm).isoformat(timespec="minutes")

def reslot():
    """After the schedule changes: give every post that is still waiting for review a new date/time on the new schedule."""
    posts = load_posts(); changed = False
    for prof in {p["profile"] for p in posts if p["status"] == "pending"}:
        taken = {p["when"][:10] for p in posts if p["profile"] == prof and p["status"] in ("approved", "scheduled")}
        for p in sorted([p for p in posts if p["profile"] == prof and p["status"] == "pending"], key=lambda p: p.get("added", "")):
            w = next_slot(prof, taken); taken.add(w[:10]); changed |= (w != p["when"]); p["when"] = w
    if changed: save_posts(posts)

def pid(src): return hashlib.md5(src.encode()).hexdigest()[:10]

def scan(clients):
    """Collect new suggested posts into the review list. Nothing is posted."""
    posts = load_posts(); known = {p["source_id"] for p in posts}; added = 0
    for c in [c for c in clients if "posts" in agent.uses(c) and not agent.is_paused(c, "posts")]:
        for dr in fetch_drafts(c["profile"]):
            if dr["source_id"] in known: continue
            when = next_slot(c["profile"], {p["when"][:10] for p in posts if p["profile"] == c["profile"] and p["status"] in ("pending", "approved", "scheduled")})
            posts.append({"id": pid(dr["source_id"]), "profile": c["profile"], "client": c["name"], "source_id": dr["source_id"], "subject": dr["subject"],
                          "raw": dr["raw"], "proposed": format_post(dr["raw"], c["profile"]), "text": format_post(dr["raw"], c["profile"]), "image": dr["image"],
                          "when": when, "status": "pending", "note": "", "added": dt.datetime.now().isoformat(timespec="seconds")}); added += 1
    save_posts(posts); return added

LI_ADDR = re.compile(r"^https?://([a-z]{2,3}\.)?linkedin\.com/(company|in)/([^/?#\s]+)", re.I)

def target(c):
    """Where this client's posts go: ('company'|'personal', id_or_slug, url) or None when no valid address is saved.
    A saved company page address wins; otherwise the person's saved profile address. No address = None = nothing is ever posted
    (it used to fall back to the feed of whoever was logged in)."""
    raw = (c.get("page_url") or "").strip()
    if re.match(r"^(www\.)?linkedin\.com/", raw, re.I): raw = "https://" + raw
    m = LI_ADDR.match(raw)
    if m and m.group(2).lower() == "company":
        return "company", urllib.parse.unquote(m.group(3)).lower(), f"https://www.linkedin.com/company/{m.group(3)}/admin/page-posts/published/"
    if c.get("company_only"): return None          # "never post to a personal profile" switch - the profile address is then used for Connections only
    slug = agent.profile_slug(c)
    if slug: return "personal", slug, f"https://www.linkedin.com/in/{slug}/"
    return None

NEEDS_ADDRESS = "This client has no LinkedIn address yet. Click Log in for this client (it fills in the profile address automatically), or add the company page address in Edit client. Posts are never scheduled without it."

def decide(pid_, action, text=None, when=None, note=""):
    posts = load_posts()
    for p in posts:
        if p["id"] != pid_ or p["status"] != "pending": continue
        if text is not None: p["text"] = text
        if when: p["when"] = when
        if action == "approve":
            if not target(_client(p["profile"])): return NEEDS_ADDRESS       # nothing is approved (or later scheduled) for a client without a saved LinkedIn address
            p["status"] = "approved"; learn(p, "approved", p["text"])
        else: p["status"] = "rejected"; p["note"] = note; learn(p, "rejected", p["text"], note)
    save_posts(posts)
    return None

# ---------- LinkedIn ----------
def _first(page, *locs, timeout=6000):
    last = None
    for n, loc in enumerate(locs):
        try: loc.first.wait_for(state="visible", timeout=timeout if n == len(locs) - 1 else min(timeout, 2500)); return loc.first      # earlier choices fail fast so the layout that exists is found quickly
        except Exception as e: last = e
    raise last or RuntimeError("not found")

def _slug(url):
    m = re.search(r"/in/([^/?#]+)", url or ""); return urllib.parse.unquote(m.group(1)).lower() if m else ""

def verify_account(page, c):
    """Runs before ANY post for a client: confirms the logged-in LinkedIn account is the one this client's posts belong to. Returns None when correct, else the reason."""
    t = target(c)
    if not t: return NEEDS_ADDRESS
    kind, ident, url = t
    if agent.profile_slug(c):
        wrong = agent.verify_person(page, c)          # the logged-in person must be the saved profile (also for company pages: that person is the page admin)
        if wrong: return wrong
    if kind == "company":
        page.goto(url); page.wait_for_timeout(3500)
        if "/company/" not in page.url or "/admin" not in page.url: return "The logged-in LinkedIn account is not an admin of this client's company page (or the page address is wrong). Click Re-login and sign in with the admin account"
    return None

def schedule_on_linkedin(page, p, stop_before_final=False):
    """Open the composer, type the post, attach the image, pick the date/time, schedule it. Returns None or an error text."""
    t = target(p)                # the saved client address decides the account; there is no "whoever is logged in" fallback
    if not t: return NEEDS_ADDRESS
    pu = t[2] if t[0] == "company" else None      # a company page is posted from its admin view; a personal profile from the feed (only after verify_account proved it is the right person)
    page.goto(pu or "https://www.linkedin.com/feed/"); page.wait_for_timeout(3500)
    why = agent.blocked(page)
    if why: return why
    if pu and ("/company/" not in page.url or "/admin" not in page.url): return "Not on the client's company page admin view: refusing to post"
    comp_name = re.sub(r"^\(\d+\)\s*", "", page.title()).split(": Company Page Admin")[0].strip() if pu else ""
    agent.close_popups(page)
    if pu:
        _first(page, page.get_by_role("button", name=re.compile(r"^create$|start a post", re.I)), page.locator("[aria-label='Start a post']"), page.locator("button:has-text('Create')")).click(); page.wait_for_timeout(800)
        try: page.get_by_role("menuitem", name=re.compile(r"start a post", re.I)).first.click(timeout=4000)
        except Exception: pass
    else:
        # LinkedIn's 2026 feed: "Start a post" is a plain div with aria-label (not a button); older layouts used a button
        _first(page, page.locator("[aria-label='Start a post']"), page.get_by_role("button", name=re.compile(r"start a post", re.I)), page.locator("button:has-text('Start a post')"), page.get_by_text(re.compile(r"^start a post$", re.I))).click()
    ed = _first(page, page.locator("dialog [role='textbox']"), page.get_by_role("textbox", name=re.compile(r"text editor|share your thoughts|what do you want", re.I)), page.locator("div.ql-editor[contenteditable='true']"), page.locator("[contenteditable='true']"), timeout=12000)
    if pu and comp_name:
        who = page.locator("[role='dialog'] button").filter(has_text=re.compile(re.escape(comp_name[:12]), re.I))
        if not who.count(): return f"The composer is not set to post as {comp_name}: refusing to post"
    ed.click(); paras = p["text"].split("\n\n")
    for i, para in enumerate(paras):
        for j, line in enumerate(para.split("\n")):
            if j: page.keyboard.press("Shift+Enter")
            page.keyboard.insert_text(line)
        if i < len(paras) - 1: page.keyboard.press("Enter"); page.keyboard.press("Enter")
    page.keyboard.press("Escape") if page.locator("[role='listbox']").count() else None   # close a hashtag suggestion list
    page.wait_for_timeout(600)
    if p.get("image"):
        with page.expect_file_chooser(timeout=10000) as fc:
            _first(page, page.locator("dialog button[aria-label='Media']"), page.get_by_role("button", name=re.compile(r"add (a )?(photo|media)|^media$", re.I)), page.locator("button[aria-label*='photo' i]")).click()
        fc.value.set_files(p["image"]); page.wait_for_timeout(2500)
        _first(page, page.get_by_role("button", name=re.compile(r"^next$", re.I))).click(); page.wait_for_timeout(1000)
    # the clock next to Post is a link with aria-label "Scheduled" (it opens the date/time screen)
    _first(page, page.locator("dialog a[aria-label='Scheduled']"), page.get_by_role("button", name=re.compile(r"schedule post", re.I)), page.locator("[aria-label*='Schedule' i]")).click()
    when = dt.datetime.fromisoformat(p["when"])
    d = _first(page, page.locator("dialog input[placeholder*='mm/dd' i]"), page.get_by_label(re.compile(r"^date", re.I)), page.locator("input[type='date'], input[placeholder*='date' i]"))
    DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]; MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    want = f"{DAYS[when.weekday()]}, {MONTHS[when.month - 1]} {when.day}, {when.year}."
    d.click(); picked = False
    for _ in range(14):      # the company page opens a calendar that covers the time box: choose the day in it (this also closes it)
        day = page.get_by_role("button", name=want)
        if day.count():
            day.first.click(); picked = True; break
        nxt = page.get_by_role("button", name=re.compile(r"^next month$", re.I))
        if not nxt.count(): break
        nxt.first.click(); page.wait_for_timeout(250)
    if not picked:
        d.fill(when.strftime("%m/%d/%Y")); page.keyboard.press("Tab")
    page.wait_for_timeout(500)
    t = _first(page, page.locator("#share-post__scheduled-time"), page.locator("dialog input[type='text']").nth(1), page.get_by_label(re.compile(r"^time", re.I)), page.locator("input[type='time'], input[placeholder*='time' i]"))
    tt = when.strftime("%I:%M %p").lstrip("0")
    t.click(); t.fill(tt); page.keyboard.press("Tab"); page.wait_for_timeout(500)
    _first(page, page.get_by_role("button", name=re.compile(r"^(confirm|next)$", re.I))).click(); page.wait_for_timeout(1500)
    if tt not in page.inner_text("body"):      # the chosen time must show on screen before the final click, otherwise it would go out at the wrong time
        return f"LinkedIn did not accept the time {tt}"
    if stop_before_final:
        page.keyboard.press("Escape"); return None
    _first(page, page.get_by_role("button", name=re.compile(r"^schedule$", re.I))).click()
    page.wait_for_timeout(1500)
    try: page.screenshot(path=str(LOGS / "last_schedule_result.png"))       # proof of what LinkedIn showed right after Schedule was clicked
    except Exception: pass
    try: page.get_by_text(re.compile(r"post scheduled|scheduled for", re.I)).first.wait_for(state="visible", timeout=15000)
    except Exception: return "LinkedIn did not confirm that the post was scheduled"      # LinkedIn shows the banner \"Post scheduled\" (seen 2026-10-26); no banner = not scheduled
    return None

def send_approved(pw, clients, d, dry=False):
    posts = load_posts(); todo = [p for p in posts if p["status"] == "approved"]
    for c in [c for c in clients if "posts" in agent.uses(c) and not agent.is_paused(c, "posts")]:
        mine = [p for p in todo if p["profile"] == c["profile"]]
        if not mine or agent.RESULT["stopped"]: continue
        if not target(c):
            agent.halt(f"{c['name']}: {NEEDS_ADDRESS}"); continue
        ctx = agent.launch(pw, c, False); page = ctx.pages[0] if ctx.pages else ctx.new_page()
        try:
            wrong = verify_account(page, c)          # check the account BEFORE touching any post
            if wrong:
                agent.halt(f"{c['name']}: {wrong}"); continue
            try:
                if (dt.datetime.now() - dt.datetime.fromisoformat(existing(c["profile"]).get("read_at", "2000-01-01T00:00:00"))).days >= 7: learn_existing(page, c)     # keep the style fresh
            except Exception: pass
            for p in mine:
                try: err = schedule_on_linkedin(page, dict(p, page_url=c.get("page_url", "")), stop_before_final=dry)
                except Exception as e: err = f"Could not use the LinkedIn composer ({str(e).splitlines()[0][:140]})"
                if err:
                    try: page.screenshot(path=str(LOGS / "last_post_error.png"))      # what LinkedIn showed at the moment it failed, so a changed layout can be fixed fast
                    except Exception: pass
                    p["status"] = "approved"; agent.halt(f"{c['name']}: {err}"); break
                if not dry: p["status"] = "scheduled"; p["done"] = dt.datetime.now().isoformat(timespec="seconds")
                print(f"  {'previewed' if dry else 'scheduled'} -> {p['subject']}"); agent.RESULT["sent"] += 0 if dry else 1
                agent.nap((6, 14))
        finally:
            try: ctx.close()
            except Exception: pass
            save_posts(posts)
    save_posts(posts)
