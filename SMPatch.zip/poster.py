#!/usr/bin/env python3
"""ShareMedia Posting Agent: picks up suggested posts, formats them, waits for approval, schedules them on LinkedIn,
and learns from every approval / edit / rejection - per client, plus ShareMedia-wide habits."""
import urllib.parse, difflib, hashlib, html, json, re, collections, datetime as dt
from pathlib import Path
import agent

ROOT, LOGS = agent.ROOT, agent.LOGS
POSTS = LOGS / "posts.json"; LEARN = LOGS / "post_learning"
INBOX = ROOT / "posting" / "inbox"; TAGS = ROOT / "config" / "hashtags"; CFGF = ROOT / "config" / "posting.json"
DEFAULT_TIME = "08:30"; DEFAULT_TAGS = 5
SCHED_DEFAULT = {"days": [0, 1, 2], "time": "08:30"}      # ShareMedia's own habit from the training video: Mon/Tue/Wed at 8:30 AM, one post per client per day

# ---------- posting schedule (any days, any time; ShareMedia-wide default plus an optional override per client) ----------
def _cfg():
    try: return json.loads(CFGF.read_text())
    except Exception: return {}

def default_sched():
    c = _cfg().get("schedule", {})
    return {"days": sorted({int(x) for x in c.get("days", [])} & set(range(7))) or list(SCHED_DEFAULT["days"]), "time": c.get("time") or SCHED_DEFAULT["time"]}

def sched_for(c):
    d = default_sched(); days = sorted({int(x) for x in (c.get("post_days") or [])} & set(range(7)))
    return {"days": days or d["days"], "time": c.get("post_time") or d["time"], "custom": bool(days or c.get("post_time"))}

def save_default_sched(days, time):
    cfg = _cfg(); cfg["schedule"] = {"days": sorted({int(x) for x in days} & set(range(7))) or list(SCHED_DEFAULT["days"]), "time": time or SCHED_DEFAULT["time"]}
    CFGF.parent.mkdir(exist_ok=True); CFGF.write_text(json.dumps(cfg, indent=1))

def _client(profile):
    for c in agent.load_cfg()[1]:
        if c["profile"] == profile: return c
    return {"profile": profile}

# ---------- source (swap this block for Outlook / Google Sheet when real access exists) ----------
def source_name(): return json.loads(CFGF.read_text()).get("source", "folder") if CFGF.exists() else "folder"

def fetch_drafts(profile):
    """Yield dicts {source_id, subject, raw, image(path or None)} for one client that have not been picked up yet.
    Folder source: posting/inbox/<client-profile>/*.txt  (first line 'Subject: ...', optional 'Image: file.png', blank line, then the post)."""
    d = INBOX / profile
    for f in sorted(d.glob("*.txt")) if d.exists() else []:
        txt = f.read_text(encoding="utf-8", errors="ignore"); head, _, body = txt.partition("\n\n")
        subj = re.search(r"^subject:\s*(.+)$", head, re.I | re.M); img = re.search(r"^image:\s*(.+)$", head, re.I | re.M)
        if not subj and not img: body = txt
        p = (d / img.group(1).strip()) if img else None
        yield {"source_id": f"{profile}/{f.name}", "subject": subj.group(1).strip() if subj else f.stem, "raw": body.strip(),
               "image": str(p) if p and p.exists() else None}

# ---------- approval emails: the way ShareMedia works today ----------
# content@ sends "Suggested post #N" to the client, the client replies "approved" / "love this one" (some arrive forwarded as "FW:"), and the rep
# posts it on the client's LinkedIn. The agent now reads those emails itself: it keeps only clearly approved replies, takes the suggested post from
# the quoted original, matches the sender to the right client and puts the post on that client's page. Read-only: it never replies, moves or deletes mail.
EMAILS = ROOT / "posting" / "emails"; MAILIMG = INBOX / "_mail"; MAILPROFILE = "_mail-outlook"
MAIL_DEFAULT = {"url": "https://outlook.office.com/mail/", "content_senders": ["content@sharemedia.co"], "internal_domains": ["sharemedia.co"], "days": 7, "max": 60}
FREE_MAIL = {"gmail", "yahoo", "outlook", "hotmail", "icloud", "aol", "comcast", "msn", "live", "me", "protonmail", "verizon", "att"}
STOPW = {"llc", "inc", "corp", "co", "the", "and", "of", "group", "partners", "company", "ltd", "mr", "mrs", "ms", "dr", "media", "capital"}

def mail_cfg():
    m = dict(MAIL_DEFAULT); m.update({k: v for k, v in _cfg().get("mail", {}).items() if v not in (None, "", [])}); return m

def save_mail_cfg(**kw):
    cfg = _cfg(); cfg.setdefault("mail", {}).update({k: v for k, v in kw.items() if v is not None}); CFGF.parent.mkdir(exist_ok=True); CFGF.write_text(json.dumps(cfg, indent=1))

def set_source(name):
    cfg = _cfg(); cfg["source"] = name; CFGF.parent.mkdir(exist_ok=True); CFGF.write_text(json.dumps(cfg, indent=1))
    if name in ("outlook", "emails") and not agent.load_state().get("mail_start"): agent.save_state(mail_start=dt.datetime.now().isoformat(timespec="seconds"))     # emails older than this are only ever offered for review, never posted automatically

HDR = re.compile(r"(?:^|\n)[ \t]*From:[ \t]*(?P<from>[^\n]+)\n(?P<rest>(?:[ \t]*(?:Sent|Date|To|Cc|Bcc|Subject|Reply-To):[^\n]*\n?)+)", re.I)
POS = re.compile(r"\b(approved?|approve|looks? (?:good|great)|love (?:it|this|that)(?: one)?|great|perfect|go ahead|good to go|yes|yep|yup|ok(?:ay)?|excellent|fine|all set|sounds good|post it|good)\b|\U0001F44D", re.I)
NEG = re.compile(r"\b(not|don'?t|do not|never|change|changes|edit|revise|rewrite|fix|replace|instead|remove|delete|add|swap|shorten|shorter|longer|wrong|hold|wait|but|however|rather|different|redo|no)\b|\?", re.I)
IMGREF = re.compile(r"<[^<>\n]{1,80}\.(?:png|jpe?g|gif|heic|webp)>|\[cid:[^\]\n]+\]|\[image[^\]\n]*\]|\[[^\]\n]{1,80}\.(?:png|jpe?g|gif|heic|webp)\]", re.I)

def _addr(s):
    m = re.search(r"([^<>\n]*?)\s*<([^<>\s]+@[^<>\s]+)>", s)
    if m: return m.group(1).strip(" \"'"), m.group(2).lower()
    m = re.search(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+", s)
    return ("", m.group(0).lower()) if m else (s.strip(" \"'"), "")

def parse_email(text, sender="", subject=""):
    """One email -> {post, reply, verdict, why, hints[(name,email)], has_image} or None when it does not contain a quoted suggested post."""
    cfg = mail_cfg(); cs = [x.lower() for x in cfg["content_senders"]]; internal = [d.lower() for d in cfg["internal_domains"]]
    is_content = lambda x: any(c in x.lower() for c in cs) or bool(re.search(r"\bcontent\s*<", x, re.I))
    is_internal = lambda e: bool(e) and e.split("@")[-1] in internal
    t = text.replace("\r\n", "\n").replace("\r", "\n").replace(" ", " ")
    t = "\n".join(re.sub(r"^(?:>[ \t]?)+", "", l) for l in t.split("\n"))
    start = end = None
    for m in re.finditer(r"wrote:", t):                                        # "On Oct 1, 2026, at 4:48 PM, Content <content@...> wrote:"
        seg = t[max(0, m.start() - 320):m.end()]; k = list(re.finditer(r"(?:^|\n)[ \t]*On\b", seg))
        if not k: continue
        s0 = m.end() - len(seg) + k[-1].start(); head = t[s0:m.end()]
        if is_content(head): start, end = s0, m.end(); break
    if start is None:                                                          # Outlook style header block "From: Content <content@...> / Sent: ... / Subject: ..."
        for m in HDR.finditer(t):
            if is_content(m.group("from")): start, end = m.start(), m.end(); break
    if start is None: return None
    post = t[end:]
    cut = re.search(r"(?:^|\n)[ \t]*(?:On\b[^\n]{0,220}wrote:|-{2,}[ \t]*(?:Original Message|Forwarded message)|From:[ \t]|Sent from my |_{5,}|-{8,})", post, re.I)
    if cut: post = post[:cut.start()]
    has_image = bool(IMGREF.search(post)); post = IMGREF.sub("", post).strip()
    post = re.sub(r"^(?:subject:[^\n]*\n|\s*\n)+", "", post, flags=re.I).strip()
    if len(post) < 25: return None
    pre = t[:start]; last = 0; hints = []
    for m in HDR.finditer(pre):
        last = m.end(); n, e = _addr(m.group("from"))
        if not is_content(m.group("from")) and not is_internal(e) and (n or e): hints.append((n, e))
    if sender:
        n, e = _addr(sender)
        if not is_content(sender) and not is_internal(e) and (n or e): hints.insert(0, (n, e))
    lines = [l.strip() for l in pre[last:].split("\n")]
    lines = [l for l in lines if l and not re.match(r"^(begin forwarded message:?|-+ ?(?:forwarded message|original message) ?-+|_{3,}|sent from my .*|get outlook for .*)$", l, re.I)]
    core = []
    for l in lines:
        if re.match(r"^sent from my ", l, re.I): break
        core.append(l)
    stmt = " ".join(core[:2])
    if len(core) >= 2 and re.match(r"^[A-Z][A-Za-z.'-]+(?: [A-Z][A-Za-z.'-]*){1,3}$", core[1]): hints.append((core[1], "")); stmt = core[0]      # signature line "John D. Farris"
    elif core and re.match(r"^[A-Z][A-Za-z.'-]+(?: [A-Z][A-Za-z.'-]*){1,3}$", core[-1]) and len(core) > 1: hints.append((core[-1], ""))
    pos, neg = POS.search(stmt), NEG.search(stmt)
    if not stmt.strip(): verdict, why = "unclear", "The email has no reply text above the suggested post."
    elif len(stmt) > 220: verdict, why = "changes", "The reply is long, so it may contain edits or comments."
    elif pos and not neg: verdict, why = "approved", "Client wrote: “" + stmt[:120] + "”"
    elif neg: verdict, why = "changes", "The reply may ask for changes: “" + stmt[:120] + "”"
    else: verdict, why = "unclear", "Could not tell if this is an approval: “" + stmt[:120] + "”"
    return {"post": post, "reply": stmt[:200], "verdict": verdict, "why": why, "hints": hints, "has_image": has_image}

def _toks(s): return [w for w in re.findall(r"[a-z]{2,}", s.lower()) if w not in STOPW]

def match_client(clients, hints):
    """Which client is this approval email from? Sender address/name against the client's name and its 'also known as' list. Returns (profile or None, why)."""
    scores = []
    for c in clients:
        al = [c["name"]] + [a.strip() for a in re.split(r"[,;\n]", c.get("aliases", "") or "") if a.strip()]; best = 0
        for n, e in hints:
            nt = set(_toks(n)); dom = e.split("@")[-1].split(".")[0] if e else ""
            for a in al:
                if "@" in a:
                    if e and a.lower() == e: best = max(best, 100)
                    continue
                at = set(_toks(a))
                if not at: continue
                if nt and len(nt) >= 2 and (nt <= at or at <= nt) and len(at) >= 2: best = max(best, 85)
                elif nt and nt == at: best = max(best, 60)
                elif len(nt & at) >= 2: best = max(best, 70)
                elif len(nt & at) == 1: best = max(best, 40)
                if dom and dom not in FREE_MAIL and dom in at: best = max(best, 60)
        scores.append((best, c))
    scores.sort(key=lambda x: -x[0])
    if not scores or scores[0][0] < 60: return None, "no client name or address matches" + (": " + ", ".join(n or e for n, e in hints[:2]) if hints else "")
    if len(scores) > 1 and scores[1][0] >= scores[0][0] - 10: return None, f"it could be {scores[0][1]['name']} or {scores[1][1]['name']}"
    return scores[0][1]["profile"], ""

def _eml_messages():
    import email, email.policy
    EMAILS.mkdir(parents=True, exist_ok=True); MAILIMG.mkdir(parents=True, exist_ok=True); out = []
    for f in sorted(EMAILS.glob("*")):
        if f.suffix.lower() == ".txt":
            out.append({"subject": f.stem, "sender": "", "date": dt.datetime.fromtimestamp(f.stat().st_mtime), "text": f.read_text(encoding="utf-8", errors="ignore"), "images": [], "key": f.name})
        elif f.suffix.lower() == ".eml":
            try: m = email.message_from_bytes(f.read_bytes(), policy=email.policy.default)
            except Exception: continue
            body = m.get_body(preferencelist=("plain", "html")); txt = body.get_content() if body else ""
            if body and body.get_content_type() == "text/html": txt = html.unescape(re.sub(r"<[^>]+>", "\n", re.sub(r"<(?:br|/p|/div)[^>]*>", "\n", txt)))
            imgs = []
            for i, part in enumerate(m.iter_attachments()):
                if part.get_content_maintype() == "image":
                    p = MAILIMG / f"{hashlib.md5(f.name.encode()).hexdigest()[:8]}-{i}{Path(part.get_filename() or 'x.png').suffix or '.png'}"; p.write_bytes(part.get_payload(decode=True)); imgs.append(str(p))
            try: d = email.utils.parsedate_to_datetime(m["Date"]).replace(tzinfo=None)
            except Exception: d = dt.datetime.fromtimestamp(f.stat().st_mtime)
            out.append({"subject": str(m["Subject"] or f.stem), "sender": str(m["From"] or ""), "date": d, "text": txt, "images": imgs, "key": f.name, "has_attachment": bool(imgs)})
    return out

# ---------- Outlook on the web, read through the agent's own browser profile (sign in once) ----------
def _mailstate(): return agent.load_state()
def mail_signed_in(): return bool(_mailstate().get("mail_login"))
MONTHS = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}

def _pane_date(txt):
    m = re.search(r"\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.? (\d{1,2}),? (\d{4})(?:,? at (\d{1,2}):(\d{2}) ?([AP]M))?", txt)
    if not m: return None
    h = int(m.group(4) or 0) % 12 + (12 if (m.group(6) or "").upper() == "PM" else 0)
    try: return dt.datetime(int(m.group(3)), MONTHS[m.group(1).lower()], int(m.group(2)), h, int(m.group(5) or 0))
    except Exception: return None

def _body_after_header(txt):
    """The reading pane starts with subject, sender, date and 'To:' lines; the email itself begins after the date line."""
    lines = txt.split("\n")
    for i, l in enumerate(lines[:14]):
        if _pane_date(l):
            j = i + 1
            while j < len(lines) and (not lines[j].strip() or re.match(r"^\s*(To|Cc|Bcc)\b", lines[j])): j += 1
            return "\n".join(lines[j:])
    return txt

def read_outlook(pw, cfg=None, headless=True):
    """Search the signed-in Outlook mailbox for 'Suggested post' emails and return their text (+ pictures). Read-only."""
    cfg = cfg or mail_cfg(); (agent.PROFILES).mkdir(exist_ok=True); MAILIMG.mkdir(parents=True, exist_ok=True)
    kw = dict(user_data_dir=str(agent.PROFILES / MAILPROFILE), headless=headless, viewport={"width": 1400, "height": 950}, ignore_default_args=["--enable-automation"])
    try: ctx = pw.chromium.launch_persistent_context(channel="chrome", **kw)
    except Exception: ctx = pw.chromium.launch_persistent_context(**kw)
    out = []
    try:
        pg = ctx.pages[0] if ctx.pages else ctx.new_page(); pg.goto(cfg["url"]); pg.wait_for_timeout(6000)
        if re.search(r"login\.(microsoftonline|live)\.com|/login|signin", pg.url, re.I) or pg.locator('input[name="loginfmt"], input[type="password"]').count():
            raise RuntimeError("Outlook is not signed in on this computer. Open Settings > Posts and click “Sign in to Outlook”.")
        box = pg.locator('input[aria-label^="Search"], input[placeholder^="Search"], #topSearchInput').first
        box.click(); box.fill('subject:"Suggested post"'); box.press("Enter"); pg.wait_for_timeout(5000)
        rows = pg.locator('[role="option"][data-convid], [role="listbox"] [role="option"]'); n = min(rows.count(), int(cfg["max"]))
        for i in range(n):
            try:
                row = rows.nth(i); rtxt = row.inner_text(); row.click(); pg.wait_for_timeout(1800)
                pane = next((pg.locator(sel).first for sel in ('[aria-label="Reading Pane"]', '#ReadingPaneContainerId', '[role="main"]') if pg.locator(sel).count()), None)
                if pane is None: continue
                txt = pane.inner_text(); d = _pane_date(txt)
                m = re.search(r"([^\n<]{2,60})<([^<>\s]+@[^<>\s]+)>", txt); key = hashlib.md5((rtxt + txt[:300]).encode()).hexdigest()[:10]; imgs = []
                for j, img in enumerate(pane.locator('[aria-label="Message body"] img, [id*="MessageBody" i] img, [aria-label*="message body" i] img').all()[:4]):
                    try:
                        bb = img.bounding_box()
                        if bb and bb["width"] >= 200 and bb["height"] >= 120: p = MAILIMG / f"{key}-{j}.png"; img.screenshot(path=str(p)); imgs.append(str(p))
                    except Exception: pass
                out.append({"subject": (rtxt.split("\n")[1] if rtxt.count("\n") else rtxt)[:100], "sender": (m.group(1).strip() + " <" + m.group(2) + ">") if m else "", "date": d, "text": _body_after_header(txt), "images": imgs, "key": key,
                            "has_attachment": bool(pane.locator('[aria-label*="ttachment" i]').count())})
            except Exception as e: print("  could not read one email:", str(e).splitlines()[0][:100])
    finally:
        try: ctx.close()
        except Exception: pass
    return out

def mail_login():
    """Opens a normal Chrome window on Outlook; returns True once the mailbox is reached. The saved sign-in is reused by the agent. The person types the password, never the agent."""
    import subprocess, urllib.request, shutil, time, alerts
    exe = alerts._find_chrome()
    if not exe: return False
    prof = agent.PROFILES / MAILPROFILE; prof.mkdir(parents=True, exist_ok=True); port = 9334
    proc = subprocess.Popen([exe, f"--user-data-dir={prof}", f"--remote-debugging-port={port}", "--no-first-run", "--no-default-browser-check", mail_cfg()["url"]])
    ok = False; end = time.time() + 900
    while time.time() < end and proc.poll() is None:
        try:
            tabs = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{port}/json", timeout=3).read())
            if any(re.match(r"https://(outlook\.(office|office365|live)\.com|outlook\.cloud\.microsoft)/mail", t.get("url", "")) for t in tabs): ok = True; break
        except Exception: pass
        time.sleep(2)
    if ok:
        time.sleep(8)
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as pw:
                b = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{port}")
                try: b.new_browser_cdp_session().send("Browser.close")
                except Exception: pass
        except Exception: pass
    try: proc.wait(timeout=15)
    except Exception: pass
    return ok

def mail_drafts(pool, pw=None):
    """Every approval email in the last N days -> drafts matched to a client (or None). `pool` = all clients that post."""
    cfg = mail_cfg(); cutoff = dt.datetime.now() - dt.timedelta(days=int(cfg["days"]))
    if source_name() == "outlook":
        if pw is None:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p: msgs = read_outlook(p, cfg)
        else: msgs = read_outlook(pw, cfg)
    else: msgs = _eml_messages()
    best = {}
    for m in msgs:
        if m.get("date") and m["date"] < cutoff: continue
        pe = parse_email(m["text"], m.get("sender", ""), m.get("subject", ""))
        if not pe: continue
        prof, why = match_client(pool, pe["hints"]); hold = []
        if pe["verdict"] != "approved": hold.append(pe["why"])
        if not prof: hold.append("Choose which client this is for (" + why + ").")
        if (pe["has_image"] or m.get("has_attachment")) and not m.get("images"): hold.append("The email has a picture the agent could not get. Add it by hand, or approve to post the text only.")
        key = hashlib.md5(re.sub(r"\W+", " ", pe["post"]).lower().strip().encode()).hexdigest()[:16]
        d = {"source_id": "mail:" + key, "subject": (m.get("subject") or "Suggested post")[:100], "raw": pe["post"], "image": (m.get("images") or [None])[0], "profile": prof,
             "from": ", ".join(n or e for n, e in pe["hints"][:1]), "reply": pe["reply"], "hold": " ".join(hold), "mail_date": (m["date"] or dt.datetime.now()).isoformat(timespec="minutes")}
        if key not in best or (not best[key]["hold"] and d["hold"] == "") or (best[key]["hold"] and not d["hold"]): best[key] = d
    return list(best.values())

def fresh_for_auto(p):
    """Auto-approve (when 'Ask me before posting' is off) only for emails that arrived after the mailbox was connected."""
    if not p.get("mail_date"): return True
    try: return dt.datetime.fromisoformat(p["mail_date"]) >= dt.datetime.fromisoformat(agent.load_state().get("mail_start") or "9999-01-01T00:00:00")
    except Exception: return False

def client_tags(profile):
    f = TAGS / f"{profile}.txt"
    own = [t for t in re.findall(r"#\w+", f.read_text(encoding="utf-8", errors="ignore"))] if f.exists() else []
    for t in existing(profile).get("traits", {}).get("top_hashtags", []):      # hashtags the client already uses on LinkedIn
        if t.lower() not in [o.lower() for o in own]: own.append(t)
    return own

# ---------- storage ----------
def jload(f, default):
    try: return json.loads(Path(f).read_text(encoding="utf-8"))
    except Exception: return default
def load_posts(): return jload(POSTS, [])
def save_posts(p): LOGS.mkdir(exist_ok=True); POSTS.write_text(json.dumps(p, indent=1), encoding="utf-8")
def approval_required(): return agent.load_state().get("post_approval_required", True)

# ---------- learning ----------
def _lf(profile): LEARN.mkdir(parents=True, exist_ok=True); return LEARN / f"{profile}.jsonl"
def history(profile):
    f = _lf(profile)
    return [json.loads(l) for l in f.read_text(encoding="utf-8").splitlines() if l.strip()] if f.exists() else []

def learn(item, decision, final_text, note=""):
    """Save the draft, what we proposed and what the human did with it. This is the corpus the agent learns from."""
    rec = {"ts": dt.datetime.now().isoformat(timespec="seconds"), "decision": decision, "subject": item["subject"], "raw": item["raw"],
           "proposed": item["proposed"], "final": final_text, "when": item["when"], "note": note,
           "edited": final_text.strip() != item["proposed"].strip()}
    with _lf(item["profile"]).open("a", encoding="utf-8") as fh: fh.write(json.dumps(rec) + "\n")
    with _lf("_sharemedia").open("a", encoding="utf-8") as fh: fh.write(json.dumps(dict(rec, client=item["profile"])) + "\n")

def _words(t): return re.findall(r"\S+", t)
def replacements(profile):
    """Wording the team changed the same way 2+ times (e.g. 'utilize' -> 'use'): applied automatically next time."""
    cnt = collections.Counter()
    for h in history(profile):
        if h["decision"] != "approved" or not h["edited"]: continue
        a, b = _words(h["proposed"]), _words(h["final"])
        for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b).get_opcodes():
            if op == "replace" and i2 - i1 <= 3 and j2 - j1 <= 3: cnt[(" ".join(a[i1:i2]), " ".join(b[j1:j2]))] += 1
    return {k: v for k, v in cnt.items() if v >= 2}

def style(profile):
    """What it has learned for this client (falls back to ShareMedia-wide habits, then defaults)."""
    def stats(rows):
        ok = [r for r in rows if r["decision"] == "approved"]
        tags = [len(re.findall(r"#\w+", r["final"])) for r in ok]; times = [r["when"][11:16] for r in ok if r.get("when")]
        days = [dt.datetime.fromisoformat(r["when"]).weekday() for r in ok if r.get("when")]
        return ok, tags, times, days
    own = history(profile); ok, tags, times, days = stats(own)
    if len(ok) < 3: ok2, tags2, times2, days2 = stats(history("_sharemedia")); tags, times, days = (tags or tags2), (times or times2), (days or days2)
    ex = existing(profile).get("traits", {})
    if len(ok) < 3 and ex.get("posts"): tags = [ex["hashtags"]]      # own approvals first, then what the client already posts, then ShareMedia-wide habits
    med = sorted(tags)[len(tags) // 2] if tags else DEFAULT_TAGS
    return {"approved": sum(1 for r in own if r["decision"] == "approved"), "rejected": sum(1 for r in own if r["decision"] == "rejected"),
            "edited": sum(1 for r in own if r["decision"] == "approved" and r["edited"]),
            "hashtags": med, "time": collections.Counter(times).most_common(1)[0][0] if times else DEFAULT_TIME,
            "days": sorted({d for d, _ in collections.Counter(days).most_common(3)}) if days else [0, 1, 2],
            "replacements": [{"from": a, "to": b, "times": n} for (a, b), n in replacements(profile).items()],
            "reject_notes": [r["note"] for r in own if r["decision"] == "rejected" and r["note"]][-5:],
            "existing": dict(ex, read_at=existing(profile).get("read_at", ""), source=existing(profile).get("source", ""))}

# ---------- learning from the client's own recent LinkedIn posts ----------
EXISTING = LEARN / "existing"
EMOJI = re.compile("[\U0001F300-\U0001FAFF\u2600-\u27BF]")

def existing(profile):
    """The last posts read from the client's own LinkedIn (company page or profile) + the style traits taken from them."""
    return jload(EXISTING / f"{profile}.json", {})

def _traits(posts):
    texts = [p["text"] for p in posts if p.get("text")]
    if not texts: return {}
    words = sorted(len(t.split()) for t in texts); tags = [re.findall(r"#\w+", t) for t in texts]; counts = sorted(len(x) for x in tags)
    paras = sorted(len([x for x in re.split(r"\n\s*\n", t) if x.strip()]) for t in texts)
    freq = collections.Counter(t.lower() for x in tags for t in set(x))
    last = collections.Counter(re.sub(r"\s+", " ", [l for l in t.strip().split("\n") if l.strip() and not l.strip().startswith("#")][-1]).strip().lower() for t in texts if [l for l in t.split("\n") if l.strip() and not l.strip().startswith("#")])
    sig = next((l for l, n in last.most_common(1) if n >= 3 and len(texts) >= 5), "")
    m = len(texts) // 2
    return {"posts": len(texts), "words": words[m], "paragraphs": paras[m], "hashtags": counts[m], "emoji_share": round(sum(1 for t in texts if EMOJI.search(t)) / len(texts), 2),
            "question_share": round(sum(1 for t in texts if "?" in t) / len(texts), 2), "top_hashtags": [t for t, n in freq.most_common(8) if n >= 2], "signature_line": sig}

EXTRACT_JS = r"""async () => {
  for (let i = 0; i < 6; i++) { window.scrollTo(0, document.body.scrollHeight); await new Promise(r => setTimeout(r, 1200)); }
  for (const b of document.querySelectorAll('button, span[role=button], a')) { if (/^(…|\.\.\.)?\s*(show|see)?\s*more$/i.test((b.innerText || '').trim())) { try { b.click() } catch (e) {} } }
  await new Promise(r => setTimeout(r, 1200));
  const parts = document.body.innerText.split(/\nFeed post(?: number \d+)?\n/).slice(1), out = [];
  for (const raw of parts) {
    const lines = raw.split('\n').map(l => l.trim());
    if (/reposted this|commented on|likes this|celebrates this|supports this|loves this|insightful/i.test(lines.slice(0, 6).join(' '))) continue;
    let a = lines.findIndex(l => /^\d+\s?(s|m|h|d|w|mo|yr)\b/i.test(l)); if (a < 0) continue;
    const age = lines[a].split(/[ •]/)[0]; let body = [];
    for (let i = a + 1; i < lines.length; i++) {
      const l = lines[i];
      if (/^(\d[\d,]*\s+(reactions?|comments?|reposts?|likes?|views?|impressions?)|like|comment|repost|send|boost|promoted|…\s?more|…\s?show more|get up to)/i.test(l)) break;
      body.push(l);
    }
    const text = body.join('\n').replace(/\n{3,}/g, '\n\n').trim(); if (text.length > 20) out.push({ text, age });
  }
  return out;
}"""

def learn_existing(page, c, n=10):
    """Read the client's last n posts from their own LinkedIn and keep them (with style traits) as what this client's posts usually look like. Returns a note."""
    t = target(c)
    if not t: return NEEDS_ADDRESS
    kind, ident, url = t
    page.goto(url if kind == "company" else f"https://www.linkedin.com/in/{ident}/recent-activity/shares/"); page.wait_for_timeout(4500)
    try: rows = page.evaluate(EXTRACT_JS)
    except Exception as e: return f"Could not read recent posts ({str(e).splitlines()[0][:100]})"
    rows = (rows or [])[:n]
    EXISTING.mkdir(parents=True, exist_ok=True)
    (EXISTING / f"{c['profile']}.json").write_text(json.dumps({"read_at": dt.datetime.now().isoformat(timespec="seconds"), "source": "company page" if kind == "company" else "profile", "posts": rows, "traits": _traits(rows)}, indent=1), encoding="utf-8")
    return f"Learned from {len(rows)} recent posts" if rows else "No posts found yet (a new page has none to learn from)"

# ---------- formatting ----------
JUNK = re.compile(r"^(sent from my .*|approved\.?|excellent\.?|it will be uploaded.*|from:.*|date:.*|to:.*|cc:.*|subject:.*|-+ ?forwarded message ?-+)$", re.I)

def clean_text(raw):
    t = raw
    for _ in range(3): t = html.unescape(t)                       # &amp; -> &   (fixes "D&O" arriving as "Damp;O")
    t = re.sub(r"(?<=\w)amp;(?=\w)", "&", t)
    t = t.replace("\r\n", "\n").replace("\r", "\n").replace(" ", " ")
    lines = [l.rstrip() for l in t.split("\n") if not JUNK.match(l.strip())]
    t = "\n".join(lines).strip()
    t = re.sub(r"\n{3,}", "\n\n", t)
    if "\n" not in t and len(t) > 280:                              # one giant block: put paragraph breaks back (2 sentences each)
        s = re.split(r"(?<=[.!?])\s+(?=[A-Z])", t); t = "\n\n".join(" ".join(s[i:i + 2]) for i in range(0, len(s), 2))
    elif "\n\n" not in t and t.count("\n") >= 2: t = t.replace("\n", "\n\n")
    return t

def pick_tags(text, profile, n):
    have = re.findall(r"#\w+", text)
    if have: return []
    words = set(w.lower() for w in re.findall(r"[A-Za-z]{4,}", text)); tags = client_tags(profile)
    rel = [t for t in tags if t[1:].lower() in words or any(w.startswith(t[1:].lower()[:6]) for w in words if len(t) > 6)]
    out = []
    for t in rel + tags:
        if t.lower() not in [o.lower() for o in out]: out.append(t)
    return out[:n]

def format_post(raw, profile):
    s = style(profile); t = clean_text(raw)
    for (a, b), _ in replacements(profile).items(): t = re.sub(r"\b" + re.escape(a) + r"\b", b, t)
    tags = pick_tags(t, profile, s["hashtags"])
    return t + ("\n\n" + " ".join(tags) if tags else "")

def next_slot(profile, taken=None):
    """First chosen weekday from tomorrow that has no post for this client yet, at the chosen time (explicit schedule; the video habit Mon-Wed 8:30 AM unless changed)."""
    sc = sched_for(_client(profile)); taken = taken or {i["when"][:10] for i in load_posts() if i["profile"] == profile and i["status"] in ("pending", "approved", "scheduled")}
    hh, mm = map(int, sc["time"].split(":")); d = dt.date.today() + dt.timedelta(days=1)
    for _ in range(60):
        if d.weekday() in sc["days"] and d.isoformat() not in taken: return dt.datetime(d.year, d.month, d.day, hh, mm).isoformat(timespec="minutes")
        d += dt.timedelta(days=1)
    return dt.datetime(d.year, d.month, d.day, hh, mm).isoformat(timespec="minutes")

def reslot():
    """After the schedule changes: give every post that is still waiting for review a new date/time on the new schedule."""
    posts = load_posts(); changed = False
    for prof in {p["profile"] for p in posts if p["status"] == "pending"}:
        taken = {p["when"][:10] for p in posts if p["profile"] == prof and p["status"] in ("approved", "scheduled")}
        for p in sorted([p for p in posts if p["profile"] == prof and p["status"] == "pending"], key=lambda p: p.get("added", "")):
            w = next_slot(prof, taken); taken.add(w[:10]); changed |= (w != p["when"]); p["when"] = w
    if changed: save_posts(posts)

def pid(src): return hashlib.md5(src.encode()).hexdigest()[:10]

def scan(clients):
    """Collect new suggested posts into the review list. Nothing is posted."""
    posts = load_posts(); known = {p["source_id"] for p in posts}; added = 0
    pool = [c for c in agent.load_cfg()[1] if "posts" in agent.uses(c) and not agent.is_paused(c, "posts")]
    mine = {c["profile"] for c in clients}; full = {c["profile"] for c in pool} <= mine
    if source_name() in ("outlook", "emails"):
        if not agent.load_state().get("mail_start"): agent.save_state(mail_start=dt.datetime.now().isoformat(timespec="seconds"))
        nm = {c["profile"]: c["name"] for c in pool}
        for dr in mail_drafts(pool):
            if dr["source_id"] in known: continue
            prof = dr["profile"] or "_unassigned"
            if prof == "_unassigned" and not full: continue            # a one-client run never grabs mail that could belong to someone else
            if prof != "_unassigned" and prof not in mine: continue
            when = next_slot(prof, {p["when"][:10] for p in posts if p["profile"] == prof and p["status"] in ("pending", "approved", "scheduled")}) if prof != "_unassigned" else next_slot(pool[0]["profile"]) if pool else ""
            fp = prof if prof != "_unassigned" else (pool[0]["profile"] if pool else "")
            posts.append({"id": pid(dr["source_id"]), "profile": prof, "client": nm.get(prof, "Not matched yet"), "source_id": dr["source_id"], "subject": dr["subject"],
                          "raw": dr["raw"], "proposed": format_post(dr["raw"], fp) if fp else dr["raw"], "text": format_post(dr["raw"], fp) if fp else dr["raw"], "image": dr["image"],
                          "when": when, "status": "pending", "note": "", "from": dr["from"], "reply": dr["reply"], "hold": dr["hold"], "mail_date": dr["mail_date"],
                          "added": dt.datetime.now().isoformat(timespec="seconds")}); added += 1
        save_posts(posts); return added
    for c in [c for c in clients if c["profile"] in {x["profile"] for x in pool}]:
        for dr in fetch_drafts(c["profile"]):
            if dr["source_id"] in known: continue
            when = next_slot(c["profile"], {p["when"][:10] for p in posts if p["profile"] == c["profile"] and p["status"] in ("pending", "approved", "scheduled")})
            posts.append({"id": pid(dr["source_id"]), "profile": c["profile"], "client": c["name"], "source_id": dr["source_id"], "subject": dr["subject"],
                          "raw": dr["raw"], "proposed": format_post(dr["raw"], c["profile"]), "text": format_post(dr["raw"], c["profile"]), "image": dr["image"],
                          "when": when, "status": "pending", "note": "", "added": dt.datetime.now().isoformat(timespec="seconds")}); added += 1
    save_posts(posts); return added

def assign(pid_, profile):
    """A post the agent could not match to a client: the team chooses the client."""
    posts = load_posts(); c = _client(profile)
    if "name" not in c: return "Choose a client"
    for p in posts:
        if p["id"] == pid_ and p["status"] == "pending":
            p["profile"] = profile; p["client"] = c["name"]; p["proposed"] = p["text"] = format_post(p["raw"], profile); p["when"] = next_slot(profile)
            p["hold"] = re.sub(r"Choose which client this is for \([^)]*\)\.?\s*", "", p.get("hold", "")).strip()
    save_posts(posts); return None

LI_ADDR = re.compile(r"^https?://([a-z]{2,3}\.)?linkedin\.com/(company|in)/([^/?#\s]+)", re.I)

def target(c):
    """Where this client's posts go: ('company'|'personal', id_or_slug, url) or None when no valid address is saved.
    A saved company page address wins; otherwise the person's saved profile address. No address = None = nothing is ever posted
    (it used to fall back to the feed of whoever was logged in)."""
    raw = (c.get("page_url") or "").strip()
    if re.match(r"^(www\.)?linkedin\.com/", raw, re.I): raw = "https://" + raw
    m = LI_ADDR.match(raw)
    if m and m.group(2).lower() == "company":
        return "company", urllib.parse.unquote(m.group(3)).lower(), f"https://www.linkedin.com/company/{m.group(3)}/admin/page-posts/published/"
    if c.get("company_only"): return None          # "never post to a personal profile" switch - the profile address is then used for Connections only
    slug = agent.profile_slug(c)
    if slug: return "personal", slug, f"https://www.linkedin.com/in/{slug}/"
    return None

NEEDS_ADDRESS = "This client has no LinkedIn address yet. Click Log in for this client (it fills in the profile address automatically), or add the company page address in Edit client. Posts are never scheduled without it."

def decide(pid_, action, text=None, when=None, note=""):
    posts = load_posts()
    for p in posts:
        if p["id"] != pid_ or p["status"] != "pending": continue
        if text is not None: p["text"] = text
        if when: p["when"] = when
        if action == "approve":
            if p["profile"] == "_unassigned": return "Choose which client this post is for first."
            if not target(_client(p["profile"])): return NEEDS_ADDRESS       # nothing is approved (or later scheduled) for a client without a saved LinkedIn address
            p["status"] = "approved"; learn(p, "approved", p["text"])
        else: p["status"] = "rejected"; p["note"] = note; learn(p, "rejected", p["text"], note)
    save_posts(posts)
    return None

# ---------- LinkedIn ----------
def _first(page, *locs, timeout=6000):
    last = None
    for n, loc in enumerate(locs):
        try: loc.first.wait_for(state="visible", timeout=timeout if n == len(locs) - 1 else min(timeout, 2500)); return loc.first      # earlier choices fail fast so the layout that exists is found quickly
        except Exception as e: last = e
    raise last or RuntimeError("not found")

def _slug(url):
    m = re.search(r"/in/([^/?#]+)", url or ""); return urllib.parse.unquote(m.group(1)).lower() if m else ""

def verify_account(page, c):
    """Runs before ANY post for a client: confirms the logged-in LinkedIn account is the one this client's posts belong to. Returns None when correct, else the reason."""
    t = target(c)
    if not t: return NEEDS_ADDRESS
    kind, ident, url = t
    if agent.profile_slug(c):
        wrong = agent.verify_person(page, c)          # the logged-in person must be the saved profile (also for company pages: that person is the page admin)
        if wrong: return wrong
    if kind == "company":
        page.goto(url); page.wait_for_timeout(3500)
        if "/company/" not in page.url or "/admin" not in page.url: return "The logged-in LinkedIn account is not an admin of this client's company page (or the page address is wrong). Click Re-login and sign in with the admin account"
    return None

def schedule_on_linkedin(page, p, stop_before_final=False):
    """Open the composer, type the post, attach the image, pick the date/time, schedule it. Returns None or an error text."""
    t = target(p)                # the saved client address decides the account; there is no "whoever is logged in" fallback
    if not t: return NEEDS_ADDRESS
    pu = t[2] if t[0] == "company" else None      # a company page is posted from its admin view; a personal profile from the feed (only after verify_account proved it is the right person)
    page.goto(pu or "https://www.linkedin.com/feed/"); page.wait_for_timeout(3500)
    why = agent.blocked(page)
    if why: return why
    if pu and ("/company/" not in page.url or "/admin" not in page.url): return "Not on the client's company page admin view: refusing to post"
    comp_name = re.sub(r"^\(\d+\)\s*", "", page.title()).split(": Company Page Admin")[0].strip() if pu else ""
    agent.close_popups(page)
    if pu:
        _first(page, page.get_by_role("button", name=re.compile(r"^create$|start a post", re.I)), page.locator("[aria-label='Start a post']"), page.locator("button:has-text('Create')")).click(); page.wait_for_timeout(800)
        try: page.get_by_role("menuitem", name=re.compile(r"start a post", re.I)).first.click(timeout=4000)
        except Exception: pass
    else:
        # LinkedIn's 2026 feed: "Start a post" is a plain div with aria-label (not a button); older layouts used a button
        _first(page, page.locator("[aria-label='Start a post']"), page.get_by_role("button", name=re.compile(r"start a post", re.I)), page.locator("button:has-text('Start a post')"), page.get_by_text(re.compile(r"^start a post$", re.I))).click()
    ed = _first(page, page.locator("dialog [role='textbox']"), page.get_by_role("textbox", name=re.compile(r"text editor|share your thoughts|what do you want", re.I)), page.locator("div.ql-editor[contenteditable='true']"), page.locator("[contenteditable='true']"), timeout=12000)
    if pu and comp_name:
        who = page.locator("[role='dialog'] button").filter(has_text=re.compile(re.escape(comp_name[:12]), re.I))
        if not who.count(): return f"The composer is not set to post as {comp_name}: refusing to post"
    ed.click(); paras = p["text"].split("\n\n")
    for i, para in enumerate(paras):
        for j, line in enumerate(para.split("\n")):
            if j: page.keyboard.press("Shift+Enter")
            page.keyboard.insert_text(line)
        if i < len(paras) - 1: page.keyboard.press("Enter"); page.keyboard.press("Enter")
    page.keyboard.press("Escape") if page.locator("[role='listbox']").count() else None   # close a hashtag suggestion list
    page.wait_for_timeout(600)
    if p.get("image"):
        with page.expect_file_chooser(timeout=10000) as fc:
            _first(page, page.locator("dialog button[aria-label='Media']"), page.get_by_role("button", name=re.compile(r"add (a )?(photo|media)|^media$", re.I)), page.locator("button[aria-label*='photo' i]")).click()
        fc.value.set_files(p["image"]); page.wait_for_timeout(2500)
        _first(page, page.get_by_role("button", name=re.compile(r"^next$", re.I))).click(); page.wait_for_timeout(1000)
    # the clock next to Post is a link with aria-label "Scheduled" (it opens the date/time screen)
    _first(page, page.locator("dialog a[aria-label='Scheduled']"), page.get_by_role("button", name=re.compile(r"schedule post", re.I)), page.locator("[aria-label*='Schedule' i]")).click()
    when = dt.datetime.fromisoformat(p["when"])
    d = _first(page, page.locator("dialog input[placeholder*='mm/dd' i]"), page.get_by_label(re.compile(r"^date", re.I)), page.locator("input[type='date'], input[placeholder*='date' i]"))
    DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]; MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    want = f"{DAYS[when.weekday()]}, {MONTHS[when.month - 1]} {when.day}, {when.year}."
    d.click(); picked = False
    for _ in range(14):      # the company page opens a calendar that covers the time box: choose the day in it (this also closes it)
        day = page.get_by_role("button", name=want)
        if day.count():
            day.first.click(); picked = True; break
        nxt = page.get_by_role("button", name=re.compile(r"^next month$", re.I))
        if not nxt.count(): break
        nxt.first.click(); page.wait_for_timeout(250)
    if not picked:
        d.fill(when.strftime("%m/%d/%Y")); page.keyboard.press("Tab")
    page.wait_for_timeout(500)
    t = _first(page, page.locator("#share-post__scheduled-time"), page.locator("dialog input[type='text']").nth(1), page.get_by_label(re.compile(r"^time", re.I)), page.locator("input[type='time'], input[placeholder*='time' i]"))
    tt = when.strftime("%I:%M %p").lstrip("0")
    t.click(); t.fill(tt); page.keyboard.press("Tab"); page.wait_for_timeout(500)
    _first(page, page.get_by_role("button", name=re.compile(r"^(confirm|next)$", re.I))).click(); page.wait_for_timeout(1500)
    if tt not in page.inner_text("body"):      # the chosen time must show on screen before the final click, otherwise it would go out at the wrong time
        return f"LinkedIn did not accept the time {tt}"
    if stop_before_final:
        page.keyboard.press("Escape"); return None
    _first(page, page.get_by_role("button", name=re.compile(r"^schedule$", re.I))).click()
    page.wait_for_timeout(1500)
    try: page.screenshot(path=str(LOGS / "last_schedule_result.png"))       # proof of what LinkedIn showed right after Schedule was clicked
    except Exception: pass
    try: page.get_by_text(re.compile(r"post scheduled|scheduled for", re.I)).first.wait_for(state="visible", timeout=15000)
    except Exception: return "LinkedIn did not confirm that the post was scheduled"      # LinkedIn shows the banner \"Post scheduled\" (seen 2026-10-26); no banner = not scheduled
    return None

def send_approved(pw, clients, d, dry=False):
    posts = load_posts(); todo = [p for p in posts if p["status"] == "approved"]
    for c in [c for c in clients if "posts" in agent.uses(c) and not agent.is_paused(c, "posts")]:
        mine = [p for p in todo if p["profile"] == c["profile"]]
        if not mine or agent.RESULT["stopped"]: continue
        if not target(c):
            agent.halt(f"{c['name']}: {NEEDS_ADDRESS}"); continue
        ctx = agent.launch(pw, c, False); page = ctx.pages[0] if ctx.pages else ctx.new_page()
        try:
            wrong = verify_account(page, c)          # check the account BEFORE touching any post
            if wrong:
                agent.halt(f"{c['name']}: {wrong}"); continue
            try:
                if (dt.datetime.now() - dt.datetime.fromisoformat(existing(c["profile"]).get("read_at", "2000-01-01T00:00:00"))).days >= 7: learn_existing(page, c)     # keep the style fresh
            except Exception: pass
            for p in mine:
                try: err = schedule_on_linkedin(page, dict(p, page_url=c.get("page_url", "")), stop_before_final=dry)
                except Exception as e: err = f"Could not use the LinkedIn composer ({str(e).splitlines()[0][:140]})"
                if err:
                    try: page.screenshot(path=str(LOGS / "last_post_error.png"))      # what LinkedIn showed at the moment it failed, so a changed layout can be fixed fast
                    except Exception: pass
                    p["status"] = "approved"; agent.halt(f"{c['name']}: {err}"); break
                if not dry: p["status"] = "scheduled"; p["done"] = dt.datetime.now().isoformat(timespec="seconds")
                print(f"  {'previewed' if dry else 'scheduled'} -> {p['subject']}"); agent.RESULT["sent"] += 0 if dry else 1
                agent.nap((6, 14))
        finally:
            try: ctx.close()
            except Exception: pass
            save_posts(posts)
    save_posts(posts)
