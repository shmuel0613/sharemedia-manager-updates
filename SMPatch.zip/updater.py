"""Safe self-update. The app looks at a fixed public address for a signed update, checks the signature with the public key below (only the owner of the private key can publish), and then applies it like a patch file. Nothing is installed."""
import hashlib, json, urllib.request
from pathlib import Path

PUBKEY = bytes.fromhex("7b4850b3dc4e4c2435d9e622dee20721dbfd2e369df0b4c669335e45611cc2e3")
ROOT = Path(__file__).resolve().parent

# ---- Ed25519 signature check (RFC 8032 reference method, standard library only) ----
_p = 2**255 - 19; _q = 2**252 + 27742317777372353535851937790883648493
def _inv(x): return pow(x, _p - 2, _p)
_d = -121665 * _inv(121666) % _p; _I = pow(2, (_p - 1) // 4, _p)
def _xrec(y):
    xx = (y * y - 1) * _inv(_d * y * y + 1); x = pow(xx, (_p + 3) // 8, _p)
    if (x * x - xx) % _p: x = x * _I % _p
    return _p - x if x % 2 else x
_By = 4 * _inv(5); _B = (_xrec(_By) % _p, _By % _p)
def _add(P, Q):
    x1, y1 = P; x2, y2 = Q; t = _d * x1 * x2 * y1 * y2
    return ((x1 * y2 + x2 * y1) * _inv(1 + t) % _p, (y1 * y2 + x1 * x2) * _inv(1 - t) % _p)
def _mul(P, e):
    R = (0, 1)
    while e:
        if e & 1: R = _add(R, P)
        P = _add(P, P); e >>= 1
    return R
def _dec(s):
    y = int.from_bytes(s, "little") & ((1 << 255) - 1); x = _xrec(y)
    if (x & 1) != (s[31] >> 7): x = _p - x
    P = (x, y)
    if (-P[0] * P[0] + P[1] * P[1] - 1 - _d * P[0] * P[0] * P[1] * P[1]) % _p: raise ValueError("bad point")
    return P
def verify(pub, msg, sig):
    try:
        if len(sig) != 64 or len(pub) != 32: return False
        R = _dec(sig[:32]); A = _dec(pub); S = int.from_bytes(sig[32:], "little")
        if S >= _q: return False
        h = int.from_bytes(hashlib.sha512(sig[:32] + pub + msg).digest(), "little") % _q
        return _mul(_B, S) == _add(R, _mul(A, h))
    except Exception: return False

def signed_text(version, sha256_hex): return f"SMPATCH1:{int(version)}:{sha256_hex}".encode()

# ---- update check ----
def source():
    for f in (ROOT / "config" / "update_source.txt", ROOT / "update_source.txt"):
        try:
            t = f.read_text().strip()
            if t.startswith("https://") or t.startswith("http://127.0.0.1"): return t.rstrip("/")
        except Exception: pass
    return ""

def current_version():
    try: return int((ROOT / "version.txt").read_text().strip())
    except Exception: return 0

def _get(url, limit=8_000_000):
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "ShareMediaManager"}), timeout=15) as r: return r.read(limit + 1)[:limit]

def check():
    """-> {available, version, notes, current, error}"""
    base = source(); cur = current_version()
    if not base: return {"available": False, "current": cur, "configured": False}
    try:
        info = json.loads(_get(base + "/latest.json", 100_000)); v = int(info["version"])
        return {"available": v > cur, "version": v, "notes": str(info.get("notes", ""))[:400], "current": cur, "configured": True, "info": info}
    except Exception as e: return {"available": False, "current": cur, "configured": True, "error": "Could not reach the update address"}

def fetch_verified(info):
    """Download the patch named in latest.json and check hash + signature. Returns the zip bytes or raises."""
    raw = _get(source() + "/" + info["patch"]); h = hashlib.sha256(raw).hexdigest()
    if h != info["sha256"]: raise ValueError("The download is damaged")
    if not verify(PUBKEY, signed_text(info["version"], h), bytes.fromhex(info["sig"])): raise ValueError("This update is not signed by the owner and was refused")
    return raw
