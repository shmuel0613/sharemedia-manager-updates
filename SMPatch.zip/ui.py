#!/usr/bin/env python3
"""ShareMedia control panel: a small local web app (nothing leaves this computer)."""
import csv, json, os, re, shutil, socket, subprocess, sys, threading, time, webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import agent, importer, brand, alerts, base64, io, datetime as dt

ROOT = agent.ROOT; PORT = 8765; URL = f"http://127.0.0.1:{PORT}"
LAST_HIT = [time.time()]; REV = [0]; COND = threading.Condition(); RUN = {"proc": None, "what": ""}; LOGIN = {"proc": None, "profile": ""}
PY = sys.executable.replace("pythonw", "python") if agent.WIN else sys.executable
_cache = {"t": 0, "exists": False, "pexists": False}

def spawn(args, logname):
    agent.LOGS.mkdir(exist_ok=True)
    f = open(agent.LOGS / logname, "w", buffering=1, encoding="utf-8")
    return subprocess.Popen([PY, str(ROOT / "agent.py")] + args, cwd=str(ROOT), stdout=f, stderr=subprocess.STDOUT, creationflags=agent.NOWIN)

CFGD = ROOT / "config"
MIME = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "webp": "image/webp", "svg": "image/svg+xml", "gif": "image/gif"}
def logo_file():
    for ext in MIME:
        p = CFGD / f"logo.{ext}"
        if p.exists(): return p
    return None

def custom_icon():
    """The uploaded logo if it is a roughly square PNG that can serve as the app icon, else None."""
    p = logo_file()
    if p and p.suffix == ".png":
        data = p.read_bytes(); w, h = brand.png_size(data)
        if w and 0.8 <= w / h <= 1.25 and w <= 512: return data
    return None

def icon_png(size=256): return custom_icon() or brand.sized_png(size)

def icon_ico(): return brand.png_to_ico(custom_icon()) if custom_icon() else brand.default_ico()

def alive(p): return p is not None and p.poll() is None

# ---- approved posts are scheduled on LinkedIn automatically (no extra click) ----
_SEND = {"flag": False, "busy": False}
def kick_send():
    """Called whenever a post is approved (and once at start-up if approved posts are waiting). Waits a few seconds so several approvals go out in one LinkedIn session,
    then runs `agent.py posts-send`; LinkedIn itself publishes each post at the time it was scheduled for. One automatic try per approval; a failed one stays 'approved' and shows a Retry button."""
    _SEND["flag"] = True
    if _SEND["busy"]: return
    _SEND["busy"] = True
    def work():
        try:
            while _SEND["flag"]:
                _SEND["flag"] = False; time.sleep(8)
                while alive(RUN["proc"]): time.sleep(3)
                import poster
                if not any(p["status"] == "approved" for p in poster.load_posts()) or agent.load_state().get("paused"): continue
                RUN["proc"] = spawn(["posts-send"], "manual_run.log")
                while alive(RUN["proc"]): time.sleep(3)
        finally: _SEND["busy"] = False
    threading.Thread(target=work, daemon=True).start()

def all_rows():
    f = agent.LOGS / "connections_log.csv"
    if not f.exists(): return []
    with f.open(newline="", encoding="utf-8") as fh: return list(csv.DictReader(fh))

def nice(res):
    if res == "sent": return "Sent"
    if res.startswith("DRY"): return "Preview only"
    return res.split("\n")[0][:120]

def export_xlsx():
    rows = all_rows()
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill
    except ImportError:
        buf = io.StringIO(); w = csv.writer(buf); w.writerow(["Time", "Client", "Keyword", "Page", "Person", "Headline", "Result"])
        for r in rows: w.writerow([r["timestamp"], r["client"], r["keyword"], r["page"], r["person"], r["headline"], nice(r["result"])])
        return buf.getvalue().encode("utf-8-sig"), "text/csv", "csv"
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Connections log"
    hdr = ["Time", "Client", "Keyword", "Page", "Person", "Headline", "Result"]; ws.append(hdr)
    for r in rows: ws.append([r["timestamp"].replace("T", " "), r["client"], r["keyword"], int(r["page"] or 0), r["person"], r["headline"], nice(r["result"])])
    for c in ws[1]: c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="0071E3")
    for col, wd in zip("ABCDEFG", (19, 30, 30, 6, 26, 60, 40)): ws.column_dimensions[col].width = wd
    ws.freeze_panes = "A2"; ws.auto_filter.ref = ws.dimensions
    s2 = wb.create_sheet("Daily summary"); s2.append(["Date", "Client", "Connections sent"]); tally = {}
    for r in rows:
        if r["result"] == "sent": k = (r["timestamp"][:10], r["client"]); tally[k] = tally.get(k, 0) + 1
    for (d, c), n in sorted(tally.items(), reverse=True): s2.append([d, c, n])
    for c in s2[1]: c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="0071E3")
    for col, wd in zip("ABC", (14, 34, 18)): s2.column_dimensions[col].width = wd
    out = io.BytesIO(); wb.save(out)
    return out.getvalue(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx"

def recent(rows, n=25):
    out = []
    for r in rows[-n:][::-1]:
        res = r["result"]; kind = "ok" if res == "sent" else ("dry" if res.startswith("DRY") else ("skip" if res.startswith("SKIPPED") else "bad"))
        out.append({"t": r["timestamp"], "client": r["client"], "person": r["person"], "kind": kind,
                    "text": "Connection sent" if kind == "ok" else ("Would connect (preview)" if kind == "dry" else ("Skipped: " + res[9:79] if kind == "skip" else res.split("\n")[0][:70]))})
    return out

def agent_target(c):
    import poster; return poster.target(c)

def week_progress(c):
    """Posts lined up this week (approved or scheduled on LinkedIn) vs posting days this week."""
    import poster, datetime as dt
    today = dt.date.today(); mon = today - dt.timedelta(days=today.weekday()); wk = {(mon + dt.timedelta(days=i)).isoformat() for i in range(7)}
    target = len(poster.sched_for(c)["days"])
    done = sum(1 for p in poster.load_posts() if p["profile"] == c["profile"] and p["status"] in ("approved", "scheduled") and p.get("when", "")[:10] in wk)
    return min(done, target), target

def posts_view():
    import poster
    d, clients = agent.load_cfg(); nm = {c["profile"]: c["name"] for c in clients}; off = {c["profile"] for c in clients if agent.is_paused(c, "posts")}; items = [p for p in poster.load_posts() if p["status"] in ("pending", "approved", "scheduled") and p["profile"] not in off]
    items.sort(key=lambda p: ({"pending": 0, "approved": 1, "scheduled": 2}[p["status"]], p["when"]))
    return {"items": [dict(p, image_name=Path(p["image"]).name if p.get("image") else "") for p in items[-60:]],
            "approval": poster.approval_required(), "source": poster.source_name(), "mail": {"signed_in": poster.mail_signed_in(), "busy": alive(LOGIN["proc"]) and LOGIN["profile"] == "_mail", "url": poster.mail_cfg()["url"], "days": poster.mail_cfg()["days"], "senders": ", ".join(poster.mail_cfg()["content_senders"]), "internal": ", ".join(poster.mail_cfg()["internal_domains"]), "start": agent.load_state().get("mail_start", "")}, "checked": agent.load_state().get("posts_checked", ""),
            "recent": [{"t": r["ts"], "client": nm.get(r.get("client"), r.get("client", "")), "decision": r["decision"], "subject": r.get("subject", ""), "note": r.get("note", "")} for r in reversed(poster.history("_sharemedia")[-25:])],
            "learned": [dict(poster.style(c["profile"]), client=c["name"], profile=c["profile"]) for c in clients]}

SAMPLE = [("Why home care costs less than a nursing home", """Families often assume a nursing home is the safe choice. But for most seniors, care at home costs less &amp; keeps them in a place they know. The average private nursing home room runs well over $9,000 a month. Home care is billed by the hour, so you only pay for the support you actually need. It also means one caregiver building a relationship with your parent instead of a rotating staff. If you are weighing options for a parent, start by asking what a typical week would look like at home."""),
 ("Medicaid waiver programs explained", """Subject: FW: Suggested post #2\nFrom: content@sharemedia.co\nDate: Oct 4, 2026\n\nMany families do not know that Medicaid waiver programs can pay for care at home.\n\nPrograms like NHTD and TBI help eligible New Yorkers stay in their communities.\n\nWant to know if you qualify? Message me.\n\nSent from my iPhone"""),
 ("Choosing a caregiver you can trust", """The right caregiver is not just about skills. Ask how they handle a bad day, what they do when a client refuses help, and how they communicate with family.\n\nGood agencies answer these questions without hesitation.""")]

def make_sample():
    import poster, brand
    d, clients = agent.load_cfg()
    clients = [c for c in clients if "posts" in agent.uses(c)]
    if not clients: return {"error": "Add a client for posts first"}
    c = clients[0]; box = poster.INBOX / c["profile"]; box.mkdir(parents=True, exist_ok=True)
    for i, (subj, body) in enumerate(SAMPLE, 1):
        body = body.split("\n\n", 1)[1] if body.startswith("Subject:") and False else body
        head = f"Subject: {subj}\n" + ("Image: sample-image.png\n" if i == 1 else "") + "\n"
        f = box / f"sample-{i}.txt"
        if not f.exists(): f.write_text(head + body.replace("\\n", "\n"), encoding="utf-8")
    (box / "sample-image.png").write_bytes(brand.sized_png(256))
    poster.TAGS.mkdir(parents=True, exist_ok=True)
    tf = poster.TAGS / f"{c['profile']}.txt"
    if not tf.exists(): tf.write_text("#HomeCare #SeniorCare #AgingInPlace #Caregiving #HomeHealth #Medicaid #FamilyCaregivers #ElderCare #NewYork\n", encoding="utf-8")
    return {"ok": True, "client": c["name"]}

def queue_view():
    q = agent.load_queue(); order = {"pending": 0, "approved": 1, "skipped": 2}
    off = {c["profile"] for c in agent.load_cfg()[1] if agent.is_paused(c, "connections")}
    q = [i for i in q if i["status"] in order and i["profile"] not in off]
    q.sort(key=lambda i: (order[i["status"]], i["client"]))
    import safety
    return [dict(i, suggest=safety.suggest_term(i["headline"])) for i in q]

def rules_view():
    import safety; r = safety.load_rules()
    return [dict(k, kind=kind) for kind in ("block", "require") for k in r.get(kind, [])]

def api_state():
    d, clients = agent.load_cfg(); s = agent.load_state(); rows = all_rows()
    if time.time() - _cache["t"] > 20: _cache.update(t=time.time(), exists=agent.task_exists(), pexists=agent.posts_task_exists())
    run_log = ""
    lf = agent.LOGS / "manual_run.log"
    if alive(RUN["proc"]) and lf.exists(): run_log = "\n".join(lf.read_text(encoding="utf-8", errors="ignore").splitlines()[-3:])
    return {"clients": [{"name": c["name"], "profile": c["profile"], "page_url": c.get("page_url", ""), "profile_url": c.get("profile_url", "") or ("" if not agent.profile_slug(c) else c.get("page_url", "")), "conn_ok": bool(agent.profile_slug(c)), "login_note": agent.load_state().get("login_note_" + c["profile"], ""), "company_only": bool(c.get("company_only")), "own_min": c.get("daily_min", ""), "own_max": c.get("daily_max", ""), "sent30": sum(1 for r in rows if r["client"] == c["name"] and r["result"] == "sent" and r["timestamp"][:10] >= (dt.date.today() - dt.timedelta(days=30)).isoformat()), "last_run": next((r["timestamp"] for r in reversed(rows) if r["client"] == c["name"]), ""), "post_kind": (agent_target(c) or ("", "", ""))[0], "paused": bool(c.get("paused")), "pause_conn": agent.is_paused(c, "connections"), "pause_posts": agent.is_paused(c, "posts"), "run_time": agent.client_time(c, "connections", d), "posts_time": agent.client_time(c, "posts", d), "post_done": week_progress(c)[0], "post_target": week_progress(c)[1], "own_run_time": c.get("run_time", ""), "own_posts_time": c.get("posts_time", ""), "uses": sorted(agent.uses(c)), "aliases": c.get("aliases", ""), "post_days": c.get("post_days", []), "post_time": c.get("post_time", ""), "keywords": "\n".join(agent.keywords_of(c)),
                         "sent": agent.sent_today(c), "target": agent.target_for(c, d),
                         "logged_in": bool(s.get("login_" + c["profile"])), "login_pending": s.get("login_pending_" + c["profile"], "")} for c in clients],
            "paused": bool(s.get("paused")), "reason": s.get("pause_reason", ""),
            "automation": bool(s.get("automation")) and _cache["exists"], "run_time": d["daily_run_time"],
            "same_schedule": agent.same_schedule(), "posts_automation": bool(s.get("posts_automation")) and _cache["pexists"], "posts_time": s.get("posts_time", agent.DEFAULT_POSTS_TIME), "build": BUILD, "rev": REV[0], "update": agent.load_state().get("update_seen", {}), "auto_update": agent.load_state().get("auto_update", True),
            "running": alive(RUN["proc"]), "run_log": run_log, "login_busy": LOGIN["profile"] if alive(LOGIN["proc"]) else "",
            "sleep_off": bool(s.get("sleep_off")), "sound": not s.get("sound_off"), "logo": (str(int(logo_file().stat().st_mtime)) if logo_file() else ""), "range": [d["daily_min"], d["daily_max"]], "alerts": {"signed_in": alerts.gmail_signed_in(), "busy": alive(LOGIN["proc"]) and LOGIN["profile"] == "_alerts", "enabled": alerts.load()["enabled"], "configured": alerts.configured(), "error": s.get("alert_error", ""), "last": s.get("alert_at", "")}, "approval": agent.approval_required(), "post_sched": __import__("poster").default_sched(), "posts": posts_view(), "queue": queue_view(), "rules": rules_view(), "recent": recent(rows), "log_total": len(rows), "setup_done": bool(s.get("setup_done")) or any(r["result"] == "sent" for r in rows)}

def slug(name, taken):
    b = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "client"; s, i = b, 2
    while s in taken: s = f"{b}-{i}"; i += 1
    return s

def _own_times(c, body):
    """This client's own start times (used only when 'same schedule for all clients' is off)."""
    for k in ("run_time", "posts_time"):
        v = (body.get(k) or "").strip()
        if v: c[k] = v
        elif k in body: c.pop(k, None)
    for k in ("daily_min", "daily_max"):          # this client's own connections-per-day range
        try: v = int(body.get(k) or 0)
        except (TypeError, ValueError): v = 0
        if 1 <= v <= 40: c[k] = v
        elif k in body: c.pop(k, None)

def _resync():
    s = agent.load_state()
    if s.get("automation") or s.get("posts_automation"): threading.Thread(target=agent.sync_schedules).start()

def apply_patch_bytes(raw):
    import zipfile
    OK = {"agent.py", "ui.py", "ui.html", "poster.py", "brand.py", "alerts.py", "dashboard.py", "growth.py", "importer.py", "safety.py", "updater.py", "version.txt", "update_source.txt"}
    try:
        if not raw or len(raw) > 8_000_000: return {"error": "That is not a patch file"}
        z = zipfile.ZipFile(io.BytesIO(raw)); names = [n for n in z.namelist() if not n.endswith("/")]
    except Exception: return {"error": "That is not a patch file"}
    if not names or any(n not in OK for n in names): return {"error": "This patch has files the app does not accept: " + ", ".join(n for n in names if n not in OK)[:120]}
    data = {n: z.read(n) for n in names}
    for n, b in data.items():
        if n.endswith(".py"):
            try: compile(b, n, "exec")
            except Exception: return {"error": f"The patch file {n} is damaged. Nothing was changed"}
    bk = CFGD / "update-backup" / dt.datetime.now().strftime("%Y%m%d-%H%M%S"); bk.mkdir(parents=True, exist_ok=True)
    for n in data:
        if (ROOT / n).exists(): shutil.copy2(ROOT / n, bk / n)
    for n, b in data.items(): (ROOT / n).write_bytes(b)
    agent.save_state(last_update=dt.datetime.now().isoformat(timespec="seconds"), last_update_files=sorted(names))
    return {"ok": True, "files": sorted(names)}      # the app restarts itself within seconds because its files changed

def do_update_now():
    """Download the signed update and apply it. Returns the apply result or {"error": ...}."""
    import updater; r = updater.check()
    if not r.get("available"): return {"error": r.get("error") or "Already up to date"}
    try: raw = updater.fetch_verified(r["info"])
    except Exception as ex: return {"error": str(ex)[:160]}
    out = apply_patch_bytes(raw)
    if out.get("ok"): agent.save_state(update_seen={"available": False, "current": r["version"]})
    return out

def post(path, body):
    d, clients = agent.load_cfg()
    if path == "/api/client/save":
        name = body["name"].strip()
        if not name: return {"error": "Name required"}
        uses = [x for x in ("connections", "posts") if x in (body.get("uses") or ["connections", "posts"])]
        if not uses: return {"error": "Choose Connections, Posts or both."}
        import poster
        addr = body.get("page_url", "").strip()
        if addr:
            import re as _re
            m = _re.search(r"linkedin\.com/company/([^/?#\s]+)", addr, _re.I)
            if not m: return {"error": "The company page address must contain /company/ (open the company page on LinkedIn and copy its address). Leave it empty to post on the person's own profile."}
            addr = f"https://www.linkedin.com/company/{m.group(1)}/"
        old = next((c for c in clients if c["profile"] == body.get("profile")), {})
        prof_url = body["profile_url"].strip() if "profile_url" in body else old.get("profile_url", "")
        if prof_url and not agent.profile_slug({"profile_url": prof_url}): return {"error": "The profile address must look like linkedin.com/in/jane-smith. You can also leave it empty: it is filled in automatically the first time you log in this client."}
        prof = body.get("profile") or slug(name, [c["profile"] for c in clients])
        kf = f"config/keywords/{prof}.txt"; (ROOT / kf).parent.mkdir(parents=True, exist_ok=True)
        (ROOT / kf).write_text(body.get("keywords", "").strip() + "\n", encoding="utf-8")
        al = re.sub(r"\s*[;\n]\s*", ", ", body["aliases"].strip()) if "aliases" in body else None
        for c in clients:
            if c["profile"] == prof and al is not None: c["aliases"] = al
        for c in clients:
            if c["profile"] == prof: c.update(name=name, keywords_file=kf, uses=uses, page_url=addr, profile_url=prof_url, company_only=bool(body["company_only"]) if "company_only" in body else bool(c.get("company_only"))); c.pop("keywords", None); _own_times(c, body); break
        else: nc = {"name": name, "profile": prof, "keywords_file": kf, "uses": uses, "page_url": addr, "profile_url": prof_url, "aliases": al or "", "company_only": bool(body.get("company_only"))}; _own_times(nc, body); clients.append(nc)
        for c in clients:
            if c["profile"] == prof:
                days = [int(x) for x in (body.get("post_days") or [])]
                if days: c["post_days"] = days
                else: c.pop("post_days", None)
                if body.get("post_time"): c["post_time"] = body["post_time"]
                else: c.pop("post_time", None)
        agent.save_cfg(d, clients)
        if "posts" in uses: import poster; poster.reslot()
        _resync()
        return {"ok": True, "profile": prof}
    if path == "/api/posts/schedule":
        import poster; poster.save_default_sched(body.get("days") or [], body.get("time")); poster.reslot(); return {"ok": True}
    if path == "/api/import/preview":
        if body.get("text"): raw, fname = body["text"].encode("utf-8"), "pasted.csv"
        else: raw, fname = base64.b64decode(body["data"]), body.get("filename", "file.xlsx")
        try: found, headers, sheet = importer.parse(fname, raw, body.get("name_col"), body.get("kw_col"), body.get("sheet"))
        except Exception as e: return {"error": "Could not read that file (" + str(e)[:80] + ")"}
        have = {c["name"].lower(): c for c in clients}
        for f in found:
            ex = have.get(f["name"].lower()); f["exists"] = bool(ex)
            f["new_kw"] = len(set(k.lower() for k in f["keywords"]) - set(k.lower() for k in agent.keywords_of(ex))) if ex else len(f["keywords"])
        return {"clients": found, "headers": headers, "sheet": sheet}
    if path == "/api/import/commit":
        added = updated = 0
        for f in body["clients"]:
            name = f["name"].strip(); kws = f.get("keywords", [])
            ex = next((c for c in clients if c["name"].lower() == name.lower()), None)
            if ex:
                cur = agent.keywords_of(ex); seen = set(k.lower() for k in cur)
                kws = cur + [k for k in kws if k.lower() not in seen]; prof = ex["profile"]; updated += 1
            else: prof = slug(name, [c["profile"] for c in clients]); added += 1
            kf = f"config/keywords/{prof}.txt"; (ROOT / kf).parent.mkdir(parents=True, exist_ok=True)
            (ROOT / kf).write_text("\n".join(kws) + "\n", encoding="utf-8")
            if ex: ex.update(keywords_file=kf); ex.pop("keywords", None)
            else: clients.append({"name": name, "profile": prof, "keywords_file": kf})
        agent.save_cfg(d, clients); return {"ok": True, "added": added, "updated": updated}
    if path == "/api/logo":
        ext = body.get("filename", "logo.png").rsplit(".", 1)[-1].lower()
        if ext not in MIME: return {"error": "Use a PNG, JPG, SVG or WebP file"}
        for e in MIME:
            old = CFGD / f"logo.{e}"
            if old.exists(): old.unlink()
        CFGD.mkdir(exist_ok=True); (CFGD / f"logo.{ext}").write_bytes(base64.b64decode(body["data"]))
        (CFGD / "app.ico").write_bytes(icon_ico()); agent.make_shortcut(); return {"ok": True}
    if path == "/api/logo/remove":
        for e in MIME:
            old = CFGD / f"logo.{e}"
            if old.exists(): old.unlink()
        (CFGD / "app.ico").write_bytes(brand.default_ico()); agent.make_shortcut(); return {"ok": True}
    if path == "/api/alerts":
        alerts.save(enabled=bool(body.get("enabled", True)), extra=alerts.parse_to(body.get("extra", ""))); return {"ok": True}
    if path == "/api/alerts/test":
        ok, msg = alerts.send("ShareMedia Manager - test alert",
            "This is a test alert from ShareMedia Manager. If you can read this, pause alerts are working.\n\nYou can reply to this email - your reply goes to everyone on this alert.",
            alerts.html_wrap("Test alert - all good", [("Status", "Alerts are working")], ["Nothing to do - this is just a test."]), only_to=[alerts.ALWAYS])
        agent.save_state(alert_error="" if ok else msg); return {"ok": ok, "msg": msg}
    if path == "/api/client/pause":      # pause / resume a client (contract on hold): nothing runs for them, everything stays and carries on where it left off
        for c in clients:
            if c["profile"] == body["profile"]:
                what = body.get("what") or ("both" if body.get("paused") else "none")   # both | connections | posts | none
                for k in ("paused", "pause_conn", "pause_posts"): c.pop(k, None)
                if what == "both": c["paused"] = True
                elif what == "connections": c["pause_conn"] = True
                elif what == "posts": c["pause_posts"] = True
        agent.save_cfg(d, clients); _resync()
        if (body.get("what") or ("both" if body.get("paused") else "none")) != "both":
            import poster; poster.reslot()       # waiting post drafts get fresh dates on the schedule
        return {"ok": True}
    if path == "/api/client/delete":
        agent.save_cfg(d, [c for c in clients if c["profile"] != body["profile"]]); _resync(); return {"ok": True}
    if path == "/api/login":
        if alive(LOGIN["proc"]): return {"error": "A login window is already open"}
        c = next(c for c in clients if c["profile"] == body["profile"])
        LOGIN.update(proc=spawn(["login", "--client", c["profile"]], "login.log"), profile=c["profile"]); return {"ok": True}
    if path == "/api/login/check":
        if alive(LOGIN["proc"]): return {"error": "A login window is already open"}
        c = next(c for c in clients if c["profile"] == body["profile"])
        LOGIN.update(proc=spawn(["login-check", "--client", c["profile"]], "login.log"), profile=c["profile"]); return {"ok": True}
    if path == "/api/login/adopt":      # the account that signed in is the right person: save its address for this client
        s = agent.load_state(); mine = s.get("login_pending_" + body["profile"], "")
        if not mine: return {"error": "Nothing to confirm. Click Log in first"}
        for c in clients:
            if c["profile"] == body["profile"]: c["profile_url"] = f"https://www.linkedin.com/in/{mine}/"
        agent.save_cfg(d, clients); agent.save_state(**{"login_" + body["profile"]: True, "login_note_" + body["profile"]: f"Profile address set to linkedin.com/in/{mine}", "login_pending_" + body["profile"]: ""}); return {"ok": True}
    if path == "/api/mail/login":
        if alive(LOGIN["proc"]): return {"error": "A login window is already open"}
        LOGIN.update(proc=spawn(["maillogin"], "login.log"), profile="_mail"); return {"ok": True}
    if path == "/api/mail/config":
        import poster
        src = body.get("source")
        if src not in ("outlook", "emails", "folder"): return {"error": "Choose where posts come from"}
        senders = [x.strip().lower() for x in re.split(r"[,;\s]+", body.get("senders", "")) if "@" in x]; internal = [x.strip().lower().lstrip("@") for x in re.split(r"[,;\s]+", body.get("internal", "")) if "." in x]
        url = (body.get("url") or "").strip()
        if url and not re.match(r"^https://[\w.-]+\.(com|net|cloud\.microsoft)(/|$)", url): return {"error": "The Outlook address must start with https://"}
        poster.save_mail_cfg(url=url or None, days=max(1, min(60, int(body.get("days") or 7))), content_senders=senders or None, internal_domains=internal or None); poster.set_source(src); return {"ok": True}
    if path == "/api/posts/assign":
        import poster; err = poster.assign(body["id"], body["profile"])
        return {"error": err} if err else {"ok": True}
    if path == "/api/alerts/login":
        if alive(LOGIN["proc"]): return {"error": "A login window is already open"}
        LOGIN.update(proc=spawn(["alertlogin"], "login.log"), profile="_alerts"); return {"ok": True}
    if path == "/api/run":
        if alive(RUN["proc"]): return {"error": "Already running"}
        args = ["run"] + (["--client", body["profile"]] if body.get("profile") else []) + (["--dry-run"] if body.get("dry") else [])
        RUN["proc"] = spawn(args, "manual_run.log"); return {"ok": True}
    if path == "/api/stop":
        if alive(RUN["proc"]):
            if agent.WIN: subprocess.run(["taskkill", "/PID", str(RUN["proc"].pid), "/T", "/F"], capture_output=True, creationflags=agent.NOWIN)   # also closes its Chrome
            else: RUN["proc"].terminate()
        return {"ok": True}
    if path == "/api/growth/check":
        if alive(RUN["proc"]): return {"error": "Something is already running"}
        RUN["proc"] = spawn(["growth"] + (["--client", body["profile"]] if body.get("profile") else []), "manual_run.log"); return {"ok": True}
    if path == "/api/growth/record":
        import growth
        def n(x):
            try: return int(str(x).replace(",", "").strip())
            except Exception: return None
        c_, f_ = n(body.get("connections")), n(body.get("followers"))
        if c_ is None and f_ is None: return {"error": "Type at least one number."}
        growth.record(body["profile"], c_, f_, "manual"); return {"ok": True}
    if path == "/api/pin_taskbar":
        _logon_task(True); r = agent.pin_taskbar()
        if agent.WIN and r.get("how") != "pinned":
            try: subprocess.Popen(["powershell", "-NoProfile", "-Command", "$d=[Environment]::GetFolderPath('Desktop');Start-Process explorer.exe -ArgumentList ('/select,' + (Join-Path $d 'ShareMedia Manager.lnk'))"], creationflags=agent.NOWIN)   # shows the icon so one right-click finishes it
            except Exception: pass
        return r
    if path == "/api/client/run":      # Clients tab: run just posts, just connections, or both for one client
        if alive(RUN["proc"]): return {"error": "Already running"}
        cmd = {"posts": "posts-scan", "connections": "run", "both": "client-both"}.get(body.get("what"))
        if not cmd or not body.get("profile"): return {"error": "Choose what to run"}
        RUN["proc"] = spawn([cmd, "--client", body["profile"]], "manual_run.log"); return {"ok": True}
    if path == "/api/posts/learn":
        if alive(RUN["proc"]): return {"error": "Already running"}
        RUN["proc"] = spawn(["posts-learn"] + (["--client", body["profile"]] if body.get("profile") else []), "manual_run.log"); return {"ok": True}
    if path == "/api/posts/scan":
        if alive(RUN["proc"]): return {"error": "Already running"}
        RUN["proc"] = spawn(["posts-scan"] + (["--client", body["profile"]] if body.get("profile") else []), "manual_run.log"); return {"ok": True}
    if path == "/api/posts/sample": return make_sample()
    if path == "/api/posts/approval": agent.save_state(post_approval_required=bool(body["on"])); return {"ok": True}
    if path == "/api/posts/decide":
        import poster; err = poster.decide(body["id"], body["action"], body.get("text"), body.get("when"), body.get("note", ""))
        if err: return {"error": err}
        if body["action"] == "approve": kick_send()
        return {"ok": True}
    if path == "/api/posts/send":
        if alive(RUN["proc"]): return {"error": "Already running"}
        RUN["proc"] = spawn(["posts-send"] + (["--dry-run"] if body.get("dry") else []), "manual_run.log"); return {"ok": True}
    if path == "/api/tracker/mark":
        import dashboard; dashboard.set_manual(body["profile"], body["date"], body.get("kind", ""), body.get("note", "")); return {"ok": True}
    if path == "/api/approval":
        agent.save_state(approval_required=bool(body["on"])); return {"ok": True}
    if path == "/api/queue/decide":
        # body: ids[], action approve|reject ; optional teach {kind, term, client}
        import safety
        ids = set(body.get("ids", [])); q = agent.load_queue()
        for i in q:
            if i["id"] in ids and i["status"] in ("pending", "approved", "skipped"):
                i["status"] = "approved" if body["action"] == "approve" else "rejected"
                if body["action"] == "approve": i["reason"] = ""
        agent.save_queue(q)
        t = body.get("teach")
        if t and t.get("term", "").strip(): safety.add_rule(t.get("kind", "block"), t["term"].strip(), t.get("client", "*"), t.get("note", ""))
        return {"ok": True}
    if path == "/api/queue/send":
        if alive(RUN["proc"]): return {"error": "Already running"}
        RUN["proc"] = spawn(["send"], "manual_run.log"); return {"ok": True}
    if path == "/api/rules/add":
        import safety
        if not body.get("term", "").strip(): return {"error": "Type a word or company"}
        safety.add_rule(body.get("kind", "block"), body["term"].strip(), body.get("client", "*"), body.get("note", "")); return {"ok": True}
    if path == "/api/rules/remove":
        import safety; safety.remove_rule(body["kind"], body["term"], body.get("client", "*")); return {"ok": True}
    if path == "/api/automation":
        def go():
            if body["on"]: agent.sleep_off(); agent.schedule_daily()
            else: agent.unschedule()
            _cache["t"] = 0
        threading.Thread(target=go).start(); return {"ok": True}
    if path == "/api/update/apply":      # update the app from a patch file (SMPatch.zip): no installer, nothing new is installed on the computer
        try: raw = base64.b64decode(body.get("data", ""))
        except Exception: return {"error": "That is not a patch file"}
        return apply_patch_bytes(raw)
    if path == "/api/update/check":
        import updater; r = updater.check(); r.pop("info", None); agent.save_state(update_seen=r); return r
    if path == "/api/update/now": return do_update_now()      # signed update from the public update address
    if path == "/api/update/auto": agent.save_state(auto_update=bool(body.get("on"))); return {"ok": True}
    if path == "/api/sound":
        if "on" in body: agent.save_state(sound_off=not body["on"])
        if body.get("test"): threading.Thread(target=agent.error_sound, args=(2,)).start()
        return {"ok": True}
    if path == "/api/resume":
        agent.save_state(paused=False, pause_reason=""); return {"ok": True}
    if path == "/api/settings":
        if "same_schedule" in body:
            agent.save_state(same_schedule=bool(body["same_schedule"])); threading.Thread(target=agent.sync_schedules).start()
        if body.get("run_time"):
            d["daily_run_time"] = body["run_time"]; agent.save_cfg(d, clients)
            if agent.load_state().get("automation"): threading.Thread(target=agent.schedule_daily).start()
        if body.get("posts_time"):
            agent.save_state(posts_time=body["posts_time"])
            if agent.load_state().get("posts_automation"): threading.Thread(target=agent.schedule_posts).start()
        return {"ok": True}
    if path == "/api/posts/automation":
        def gop():
            if body["on"]: agent.sleep_off(); agent.schedule_posts()
            else: agent.unschedule_posts()
            _cache["t"] = 0
        threading.Thread(target=gop).start(); return {"ok": True}
    return {"error": "unknown"}


# ---------------- phone access (PIN protected, off by default) ----------------
import hashlib, secrets
PHONEF = ROOT / "config" / "phone.json"; SESSF = ROOT / "logs" / "phone_sessions.json"
LOGON_TASK = "ShareMedia Manager (phone access)"
SESSIONS, FAILS, SRV = set(), {}, [None]
try: SESSIONS = set(json.loads(SESSF.read_text()))
except Exception: pass

def phone_cfg():
    c = {"enabled": False, "salt": "", "hash": ""}
    try: c.update(json.loads(PHONEF.read_text()))
    except Exception: pass
    return c
def _pinhash(pin, salt): return hashlib.pbkdf2_hmac("sha256", pin.encode(), bytes.fromhex(salt), 200000).hex()
def _save_sessions():
    try: SESSF.parent.mkdir(exist_ok=True); SESSF.write_text(json.dumps(sorted(SESSIONS)))
    except Exception: pass
def lan_addresses():
    ips = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(("10.255.255.255", 1)); ips.append(s.getsockname()[0]); s.close()
    except Exception: pass
    try:
        for i in socket.gethostbyname_ex(socket.gethostname())[2]:
            if i not in ips and not i.startswith("127."): ips.append(i)
    except Exception: pass
    out = []
    for i in ips:
        kind = "Tailscale (works anywhere)" if i.startswith("100.") else "Home Wi-Fi"
        out.append({"url": f"http://{i}:{PORT}", "kind": kind})
    return out
def phone_status():
    c = phone_cfg(); return {"enabled": c["enabled"], "has_pin": bool(c["hash"]), "addresses": lan_addresses() if c["enabled"] else [], "devices": len(SESSIONS)}

def _logon_task(on):
    try:
        if agent.WIN:
            if on:
                ps = (f"$a=New-ScheduledTaskAction -Execute '{agent._pyexe()}' -Argument 'ui.py --background' -WorkingDirectory '{ROOT}';"
                      "$t=New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME;"
                      "$s=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Seconds 0);"
                      f"Register-ScheduledTask -TaskName '{LOGON_TASK}' -Action $a -Trigger $t -Settings $s -Force | Out-Null")
            else: ps = f"Unregister-ScheduledTask -TaskName '{LOGON_TASK}' -Confirm:$false -ErrorAction SilentlyContinue"
            subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, creationflags=agent.NOWIN)
        elif agent.MAC:
            pl = Path.home() / "Library/LaunchAgents/com.sharemedia.manager.plist"
            if on:
                pl.parent.mkdir(exist_ok=True)
                pl.write_text(f'<?xml version="1.0" encoding="UTF-8"?><plist version="1.0"><dict><key>Label</key><string>com.sharemedia.manager</string><key>WorkingDirectory</key><string>{ROOT}</string><key>ProgramArguments</key><array><string>{agent._pyexe()}</string><string>ui.py</string><string>--background</string></array><key>RunAtLoad</key><true/></dict></plist>')
                subprocess.run(["launchctl", "load", str(pl)], capture_output=True)
            elif pl.exists(): subprocess.run(["launchctl", "unload", str(pl)], capture_output=True); pl.unlink()
    except Exception as e: print("logon task skipped:", e)

def bind_server(host):
    """(Re)start the web server on loopback only, or on all interfaces when phone access is on."""
    old = SRV[0]
    if old:
        try: old.shutdown(); old.server_close()
        except Exception: pass
    srv = ThreadingHTTPServer((host, PORT), H); SRV[0] = srv
    threading.Thread(target=srv.serve_forever, daemon=True).start()

def phone_save(body):
    c = phone_cfg(); pin = str(body.get("pin") or "").strip()
    if pin:
        if not (pin.isdigit() and 6 <= len(pin) <= 12): return {"error": "The PIN must be 6 to 12 digits."}
        c["salt"] = secrets.token_hex(16); c["hash"] = _pinhash(pin, c["salt"]); SESSIONS.clear(); _save_sessions()   # a new PIN signs every phone out
    on = bool(body.get("enabled"))
    if on and not c["hash"]: return {"error": "Choose a PIN first (6 to 12 digits)."}
    changed = on != bool(c["enabled"]); c["enabled"] = on
    PHONEF.parent.mkdir(exist_ok=True); PHONEF.write_text(json.dumps(c))
    if not on: SESSIONS.clear(); _save_sessions()
    if changed:
        threading.Thread(target=lambda: (time.sleep(0.6), bind_server("0.0.0.0" if on else "127.0.0.1")), daemon=True).start()
        threading.Thread(target=_logon_task, args=(on,), daemon=True).start()
    return {"ok": True}

PIN_PAGE = """<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>ShareMedia Manager</title>
<style>body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif;background:#f5f5f7;color:#1d1d1f;display:grid;place-items:center;min-height:100vh}
.c{background:#fff;border-radius:24px;padding:34px 28px;width:min(340px,90vw);text-align:center;box-shadow:0 8px 30px rgba(0,0,0,.08)}img{width:68px;height:68px;border-radius:16px}h1{font-size:21px;margin:14px 0 4px}p{color:#6e6e73;font-size:14px;margin:0 0 18px}
input{width:100%;box-sizing:border-box;font-size:22px;letter-spacing:.3em;text-align:center;padding:12px;border:1px solid rgba(0,0,0,.12);border-radius:12px;background:#f2f2f4;outline:0}
button{margin-top:14px;width:100%;border:0;border-radius:980px;background:#1a6bf0;color:#fff;font-size:16px;font-weight:600;padding:13px}#e{color:#d70015;font-size:13.5px;min-height:18px;margin-top:10px}</style>
<div class=c><img src="/icon-128.png"><h1>ShareMedia Manager</h1><p>Enter your PIN</p><input id=p type=password inputmode=numeric autocomplete=current-password autofocus><div id=e></div><button onclick=go()>Open</button></div>
<script>document.getElementById('p').addEventListener('keydown',e=>{if(e.key=='Enter')go()});
async function go(){const r=await fetch('/pin',{method:'POST',headers:{'X-ShareMedia':'1'},body:JSON.stringify({pin:document.getElementById('p').value})}).then(r=>r.json());if(r.ok)location.reload();else document.getElementById('e').textContent=r.error||'Wrong PIN'}</script>"""

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, code, data, ctype="application/json"):
        b = data if isinstance(data, bytes) else json.dumps(data).encode()
        self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(b))); self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(b)
    def _ok_host(self): return self.headers.get("Host", "") in (f"127.0.0.1:{PORT}", f"localhost:{PORT}")
    def _local(self): return self.client_address[0] in ("127.0.0.1", "::1")
    def _authed(self):
        ck = self.headers.get("Cookie", "")
        m = re.search(r"smsid=([0-9a-f]{64})", ck)
        return bool(m and m.group(1) in SESSIONS)
    def _gate(self, post=False):
        """True = request may continue. Computer itself: as before. Phone/other device: phone access must be on and the PIN entered."""
        if self._local(): return self._ok_host() and (not post or self.headers.get("X-ShareMedia") == "1")
        if not phone_cfg()["enabled"]: self._send(403, {"error": "forbidden"}); return False
        if post and self.headers.get("X-ShareMedia") != "1": self._send(403, {"error": "forbidden"}); return False
        return True
    def _pin_login(self):
        ip = self.client_address[0]; f = FAILS.get(ip, [0, 0])
        if time.time() < f[1]: return self._send(429, {"error": "Too many tries. Wait 5 minutes."})
        try: pin = str(json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}").get("pin", ""))
        except Exception: pin = ""
        c = phone_cfg()
        if c["hash"] and secrets.compare_digest(_pinhash(pin, c["salt"]), c["hash"]):
            FAILS.pop(ip, None); tok = secrets.token_hex(32); SESSIONS.add(tok); _save_sessions()
            b = json.dumps({"ok": True}).encode()
            self.send_response(200); self.send_header("Set-Cookie", f"smsid={tok}; Path=/; HttpOnly; SameSite=Strict; Max-Age=2592000")
            self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b); return
        f[0] += 1
        if f[0] >= 5: f = [0, time.time() + 300]
        FAILS[ip] = f; self._send(200, {"error": "Wrong PIN"})
    def do_GET(self):
        LAST_HIT[0] = time.time()
        if self.path == "/api/version": return self._send(200, {"build": BUILD, "rev": REV[0]})   # build number only, safe without the PIN
        if not self._gate(): return self._send(403, {"error": "forbidden"}) if self._local() else None   # blocks DNS-rebinding from other sites; other devices need phone access + PIN
        if not self._local() and not self._authed():
            if re.match(r"/icon-\d+\.png", self.path): return self._send(200, icon_png(min(max(int(re.match(r"/icon-(\d+)", self.path).group(1)), 16), 512)), "image/png")
            return self._send(200, PIN_PAGE.encode(), "text/html; charset=utf-8")
        if self.path == "/api/phone":
            if not self._local(): return self._send(403, {"error": "forbidden"})
            return self._send(200, phone_status())
        if self.path.startswith("/api/wait"):      # live mirror: every screen waits here and is told the moment anything changes
            try: since = int(self.path.split("rev=")[1].split("&")[0])
            except Exception: since = -1
            with COND: COND.wait_for(lambda: REV[0] != since, 25)
            return self._send(200, {"rev": REV[0], "build": BUILD})
        if self.path == "/api/version": return self._send(200, {"build": BUILD, "rev": REV[0]})
        if self.path == "/api/state": return self._send(200, api_state())
        if self.path == "/api/activity":      # every connection and post event, for the sortable Activity log
            import poster; d, cl = agent.load_cfg(); nm = {c["profile"]: c["name"] for c in cl}; out = []
            for r in all_rows()[-4000:]:
                res = r["result"]; k = "Sent" if res == "sent" else ("Preview" if res.startswith("DRY") else ("Skipped" if res.startswith("SKIPPED") else "Failed"))
                out.append({"t": r["timestamp"], "client": r["client"], "type": "Connection", "result": k, "detail": (r["person"] + (" · " + r["headline"] if r.get("headline") else "")) if k in ("Sent", "Preview") else (res.replace("SKIPPED: ", "").split("\n")[0][:120] + (" · " + r["person"] if r.get("person") else ""))})
            for r in poster.history("_sharemedia")[-2000:]:
                out.append({"t": r["ts"], "client": nm.get(r.get("client"), r.get("client", "")), "type": "Post", "result": "Approved" if r["decision"] == "approved" else "Rejected", "detail": r.get("subject", "") + (" · " + r["note"] if r.get("note") else "")})
            return self._send(200, {"rows": out, "clients": sorted({c["name"] for c in cl})})
        if self.path.startswith("/api/dashboard"):
            import dashboard; return self._send(200, dashboard.dashboard("demo=1" in self.path))
        if self.path.startswith("/api/tracker"):
            import dashboard, urllib.parse as up; q = up.parse_qs(up.urlparse(self.path).query)
            return self._send(200, dashboard.tracker((q.get("week") or [None])[0], "demo=1" in self.path))
        if self.path == "/api/alerts":
            c = alerts.load(); return self._send(200, {"enabled": c["enabled"], "sender": c["sender"], "extra": ", ".join(c["extra"])})
        if self.path == "/api/starter":
            f = ROOT / "config" / "starter-keywords.txt"; return self._send(200, {"text": f.read_text(encoding="utf-8") if f.exists() else ""})
        if self.path.startswith("/logo"):
            p = logo_file()
            if not p: return self._send(404, b"", "text/plain")
            return self._send(200, p.read_bytes(), MIME[p.suffix[1:]])
        m = re.match(r"/icon-(\d+)\.png", self.path)
        if m and "a=posts" in self.path: return self._send(200, brand.sized_png(min(max(int(m.group(1)), 16), 512), "posts"), "image/png")
        if m: return self._send(200, icon_png(min(max(int(m.group(1)), 16), 512)), "image/png")
        if self.path.startswith("/icon.png"): return self._send(200, icon_png(256), "image/png")
        if self.path.startswith("/api/export"):
            data, ctype, ext = export_xlsx(); b = data
            self.send_response(200); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(b)))
            self.send_header("Content-Disposition", f'attachment; filename="ShareMedia-Connections-log-{dt.date.today()}.{ext}"'); self.end_headers(); self.wfile.write(b); return
        if self.path == "/api/template.csv":
            b = "Client name,Keywords\nJane Smith - Acme Capital,\"Family office, Private equity, Fintech investor\"\nJohn Doe - Example Co,Home care agency owner\n".encode()
            self.send_response(200); self.send_header("Content-Type", "text/csv"); self.send_header("Content-Disposition", 'attachment; filename="client-import-template.csv"'); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b); return
        self._send(200, (ROOT / "ui.html").read_bytes(), "text/html; charset=utf-8")   # always fresh from disk
    def do_POST(self):
        LAST_HIT[0] = time.time()
        if not self._gate(True): return self._send(403, {"error": "forbidden"}) if self._local() else None   # other websites cannot send the header
        if not self._local() and self.path == "/pin": return self._pin_login()
        if not self._local() and not self._authed(): return self._send(401, {"error": "PIN needed"})
        if self.path == "/api/phone/save":
            if not self._local(): return self._send(403, {"error": "Phone access can only be changed on the computer."})
            return self._send(200, phone_save(json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")))
        try: body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}"); r = post(self.path, body); bump_rev(); self._send(200, r)
        except Exception as e: self._send(500, {"error": str(e)[:200]})

def open_window(which=""):
    url = URL
    cands = []
    if agent.WIN:
        for base in (os.environ.get("PROGRAMFILES", ""), os.environ.get("PROGRAMFILES(X86)", ""), os.environ.get("LOCALAPPDATA", "")):
            cands += [Path(base) / "Google/Chrome/Application/chrome.exe", Path(base) / "Microsoft/Edge/Application/msedge.exe"]
    elif agent.MAC: cands = [Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"), Path("/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge")]
    for c in cands:
        if c.exists():
            subprocess.Popen([str(c), f"--app={url}", "--window-size=1040,820", f"--user-data-dir={ROOT / 'ui-window-profile'}"]); return
    webbrowser.open(url)

def _startup_fixups():
    agent.fix_root()      # folder moved? re-point the Desktop icon and the daily schedule
    if phone_cfg()["enabled"] and agent.load_state().get("logon_root") != str(ROOT):
        _logon_task(True); agent.save_state(logon_root=str(ROOT))

def bump_rev():
    with COND: REV[0] += 1; COND.notify_all()

def _signature():
    """Cheap fingerprint of every file that holds clients, settings, posts and logs: changes made by the scheduled agents or by another screen show up everywhere."""
    sig = []
    for sub in ("config", "logs", "posting"):
        base = ROOT / sub
        if not base.exists(): continue
        for f in base.rglob("*"):
            try:
                if f.is_file() and f.name not in ("phone_sessions.json",): st = f.stat(); sig.append((str(f), st.st_mtime_ns, st.st_size))
            except Exception: pass
    return hash(tuple(sorted(sig)))

def restart_self():
    """Program files changed on disk (an update was copied in): restart this server with the new code so every screen gets it with no clicks."""
    try:
        old = SRV[0]
        if old: old.shutdown(); old.server_close()
        subprocess.Popen([sys.executable, str(ROOT / "ui.py"), "--background"], cwd=str(ROOT), creationflags=agent.NOWIN)
    except Exception as e: print("restart failed:", e)
    os._exit(0)

def _watch():
    last = _signature(); n = 0
    while True:
        time.sleep(0.8); n += 1
        try:
            cur = _signature()
            if cur != last: last = cur; bump_rev()
            if n == 40 or n % 1100 == 0:      # a little after start, then about every 15 minutes: look for a signed update
                try:
                    import updater; r = updater.check(); r.pop("info", None); agent.save_state(update_seen=r)
                    if r.get("available") and agent.load_state().get("auto_update", True) and not alive(RUN["proc"]) and not alive(LOGIN["proc"]): do_update_now()      # forced update, only when nothing is running by hand
                except Exception: pass
            if n % 6 == 0 and agent.build_id() != BUILD: time.sleep(2); restart_self()      # wait 2 s so a multi-file update finishes copying
        except Exception: pass

BUILD = agent.build_id()

def running_build():
    try:
        import urllib.request
        return json.loads(urllib.request.urlopen(URL + "/api/version", timeout=3).read()).get("build")
    except Exception: return None      # an older version has no /api/version

def kill_port(port):
    """Stop whatever program is listening on our port (an older ShareMedia Manager left running in the background)."""
    try:
        if agent.WIN:
            out = subprocess.run(["netstat", "-ano", "-p", "tcp"], capture_output=True, text=True, creationflags=agent.NOWIN).stdout
            pids = {l.split()[-1] for l in out.splitlines() if f":{port} " in l and "LISTENING" in l}
            for p in pids: subprocess.run(["taskkill", "/F", "/PID", p], capture_output=True, creationflags=agent.NOWIN)
        else:
            for p in subprocess.run(["lsof", "-ti", f"tcp:{port}", "-sTCP:LISTEN"], capture_output=True, text=True).stdout.split(): os.kill(int(p), 9)
        time.sleep(1.5)
    except Exception as e: print("could not stop the old server:", e)

def main():
    bg = "--background" in sys.argv[1:]
    s = socket.socket()
    if s.connect_ex(("127.0.0.1", PORT)) == 0:
        s.close()
        if running_build() == BUILD:        # same version already running -> just show it
            if not bg: open_window()
            return
        kill_port(PORT)                     # older version still running in the background -> replace it so updates always take effect
    else: s.close()
    agent.restore_if_empty(); agent.ensure_defaults()
    try:
        import poster
        if any(p['status'] == 'approved' for p in poster.load_posts()): kick_send()      # approved before a restart: schedule them now
    except Exception: pass
    threading.Thread(target=_watch, daemon=True).start()
    threading.Thread(target=agent.backup_settings, daemon=True).start()
    if agent.WIN and not agent.load_state().get("shortcut_manager"):
        threading.Thread(target=lambda: (agent.make_shortcut(), agent.save_state(shortcut_manager=True)), daemon=True).start()   # one "ShareMedia Manager" icon; removes the earlier two
    threading.Thread(target=_startup_fixups, daemon=True).start()
    bind_server("0.0.0.0" if phone_cfg()["enabled"] else "127.0.0.1")
    if not bg: open_window()
    while phone_cfg()["enabled"] or time.time() - LAST_HIT[0] < 90: time.sleep(2)   # with phone access on it keeps running; otherwise it closes when the window is closed
    os._exit(0)

if __name__ == "__main__": main()
