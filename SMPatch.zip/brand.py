"""Brand assets: default app icon (original design in ShareMedia blue) + PNG->ICO helper. Pure stdlib."""
import math, struct, zlib

def _png(w, h, rgba):
    raw = b"".join(b"\x00" + bytes(rgba[y * w * 4:(y + 1) * w * 4]) for y in range(h))
    def ck(t, d): c = struct.pack(">I", len(d)) + t + d; return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    return b"\x89PNG\r\n\x1a\n" + ck(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)) + ck(b"IDAT", zlib.compress(raw, 9)) + ck(b"IEND", b"")

def default_png(size=256, kind="connections"):
    """Connections = blue square with three linked nodes. Posts = green square with a speech bubble. Different color AND shape so they are easy to tell apart."""
    nodes = [(.30, .66), (.70, .66), (.50, .30)]; segs = [(0, 1), (0, 2), (1, 2)]
    out = bytearray(size * size * 4)
    cl = lambda v: 0.0 if v < 0 else 1.0 if v > 1 else v
    def seg_d(px, py, a, b):
        ax, ay = a; bx, by = b; dx, dy = bx - ax, by - ay
        t = cl(((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)); return math.hypot(px - ax - t * dx, py - ay - t * dy)
    for y in range(size):
        for x in range(size):
            px, py = (x + .5) / size, (y + .5) / size
            qx, qy = abs(px - .5) - (.5 - .22), abs(py - .5) - (.5 - .22)
            d = math.hypot(max(qx, 0), max(qy, 0)) + min(max(qx, qy), 0) - .22
            a = cl(.5 - d * size)
            if a <= 0: continue
            t = (px + py) / 2
            if kind == "posts":
                r, g, b = int(12 + 30 * t), int(120 + 60 * t), int(86 + 40 * t)
                qx2, qy2 = abs(px - .5) - .25, abs(py - .43) - .17; bd = math.hypot(max(qx2, 0), max(qy2, 0)) + min(max(qx2, qy2), 0) - .07
                glyph = cl(.5 - bd * size)
                tx, ty = px - .36, py - .60        # tail under the bubble, pointing down-left
                if 0 <= ty <= .17 and 0 <= tx <= .20 - ty * 1.1: glyph = 1.0
                for k in range(3):                  # text lines inside the bubble (cut out in the background color)
                    ly = .34 + k * .09; lw = (.30, .30, .18)[k]
                    if abs(py - ly) < .018 and .31 <= px <= .31 + lw: glyph = 0.0
            else:
                r, g, b = int(20 + 40 * t), int(86 + 54 * t), int(217 + 38 * t)
                glyph = 0.0
                for n in nodes: glyph = max(glyph, cl(.5 - (math.hypot(px - n[0], py - n[1]) - .105) * size))
                for i, j in segs: glyph = max(glyph, cl(.5 - (seg_d(px, py, nodes[i], nodes[j]) - .018) * size))
            r, g, b = [int(c + (255 - c) * glyph) for c in (r, g, b)]
            o = (y * size + x) * 4; out[o:o + 4] = bytes((r, g, b, int(a * 255)))
    return _png(size, size, out)

def png_size(data):
    return struct.unpack(">II", data[16:24]) if data[:8] == b"\x89PNG\r\n\x1a\n" else (0, 0)

_cache = {}
def sized_png(size, kind="connections"):
    """Default icon drawn natively at this size (sharp at every size, not scaled down)."""
    if (size, kind) not in _cache: _cache[(size, kind)] = default_png(size, kind)
    return _cache[(size, kind)]

SIZES = (16, 24, 32, 48, 64, 128, 256)

def png_to_ico(pngs):
    """One .ico holding several PNG sizes so Windows picks a crisp one for the taskbar, desktop and title bar."""
    if isinstance(pngs, (bytes, bytearray)): pngs = [bytes(pngs)]
    head = struct.pack("<HHH", 0, 1, len(pngs)); off = 6 + 16 * len(pngs); ents = b""; body = b""
    for p in pngs:
        w, h = png_size(p); ents += struct.pack("<BBBBHHII", w % 256, h % 256, 0, 0, 1, 32, len(p), off + len(body)); body += p
    return head + ents + body

def default_ico(kind="connections"): return png_to_ico([sized_png(s, kind) for s in SIZES])
