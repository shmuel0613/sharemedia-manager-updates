"""Bulk client import: reads whatever spreadsheet the team already uses (xlsx / csv / pasted text) and works out
who the clients are and what their search keywords are. Passwords/logins in the file are NEVER read."""
import csv, io, re

IGN = re.compile(r"pass|pwd|e-?mail|login|user ?name|phone|status|date|note|url|link|2fa|code|^#|\bp/?c\b|schedul|posted|sugg|twitter|facebook|follow|\bid$", re.I)
NAME_H = re.compile(r"^(client( name)?|name|full name|account( name)?|person|customer|profile( name)?)$", re.I)
KW_H = re.compile(r"keyword|search( term| phrase)?s?$|terms?$|quer(y|ies)|phrases?", re.I)

def read_tables(filename, raw):
    n = filename.lower(); tables = []
    if n.endswith((".xlsx", ".xlsm")):
        import openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(raw), read_only=True, data_only=True)
        for ws in wb.worksheets:
            tables.append((ws.title, [["" if v is None else str(v).strip() for v in r] for r in ws.iter_rows(values_only=True)]))
    else:
        text = raw.decode("utf-8-sig", errors="replace")
        try: dialect = csv.Sniffer().sniff(text[:4000], delimiters=",\t;|")
        except Exception: dialect = csv.excel
        rows = [[c.strip() for c in r] for r in csv.reader(io.StringIO(text), dialect)]
        tables.append(("Pasted/CSV", rows))
    return tables

def _clean(rows):
    w = max((len(r) for r in rows), default=0)
    rows = [r + [""] * (w - len(r)) for r in rows if any(c for c in r)]
    keep = [i for i in range(w) if any(r[i] for r in rows)]
    return [[r[i] for i in keep] for r in rows]

def split_kw(cell):
    out = []
    for p in re.split(r"[\n;|,]", cell or ""):
        p = re.sub(r"^[\s•\-\*·–\d\.\)]+", "", p).strip()
        if p: out.append(p)
    return out

def _add(res, name, kws):
    name = re.sub(r"\s+", " ", name).strip()
    if not name: return
    lst = res.setdefault(name, [])
    for k in kws:
        if k.lower() not in (x.lower() for x in lst): lst.append(k)

def extract(rows_raw, name_col=None, kw_col=None):
    """Returns ({client: [keywords]}, headers) for ONE table."""
    res = {}
    rows_raw = [r if r else [""] for r in rows_raw]
    # single column, blank-line separated blocks (e.g. pasted from a doc): first line = client, rest = keywords
    if rows_raw and max(len(r) for r in rows_raw) == 1 and name_col is None:
        if NAME_H.match(rows_raw[0][0].strip()) or re.match(r"^clients?$", rows_raw[0][0].strip(), re.I):   # a plain list of names under a header
            for r in rows_raw[1:]: _add(res, r[0], [])
            return res, []
        blocks, cur = [], []
        for r in rows_raw:
            if r[0].strip(): cur.append(r[0].strip())
            elif cur: blocks.append(cur); cur = []
        if cur: blocks.append(cur)
        if any(len(b) >= 2 for b in blocks):
            for b in blocks: _add(res, b[0], [k for line in b[1:] for k in split_kw(line)])
            return res, []
        for b in blocks:
            for line in b: _add(res, line, [])
        return res, []
    rows = _clean(rows_raw)
    if not rows: return res, []
    header, body = rows[0], rows[1:]
    ncol = name_col if name_col is not None else next((i for i, h in enumerate(header) if NAME_H.match(h)), None)
    kcols = [kw_col] if kw_col is not None else [i for i, h in enumerate(header) if i != ncol and KW_H.search(h)]
    if ncol is not None:
        cur = ""
        for r in body:
            if r[ncol].strip(): cur = r[ncol]
            kws = [k for i in kcols for k in split_kw(r[i])]
            if cur: _add(res, cur, kws)
        return res, header
    # no 'name' column: columns are clients, cells under them are keywords
    for i, h in enumerate(header):
        if h and not IGN.search(h) and not KW_H.search(h):
            kws = [k for r in body for k in split_kw(r[i])]
            if kws: _add(res, h, kws)
    return res, header

def parse(filename, raw, name_col=None, kw_col=None, sheet=None):
    tables = read_tables(filename, raw); merged = {}; headers = []; biggest = (0, [], "")
    for title, rows in tables:
        if sheet is not None and title != sheet: continue
        res, hdr = extract(rows, name_col, kw_col)
        if len(rows) > biggest[0]: biggest = (len(rows), hdr or (rows[0] if rows else []), title)
        for n, k in res.items(): _add(merged, n, k)
    return [{"name": n, "keywords": k} for n, k in merged.items()], biggest[1], biggest[2]
